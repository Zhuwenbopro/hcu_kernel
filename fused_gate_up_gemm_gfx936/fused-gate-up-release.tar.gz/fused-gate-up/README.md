# Fused packed gate/up GEMM

Fixed gfx936 N=17408, K=5120, M=1..256. Output BF16 [M,8704].
W source: [K,N], stride=(1,K), ordinary concatenation [gate | up].
prepare_weight packs G16/U16, with PI16 inside each block. Static preparation is once per W.
INT8 uses per-row/per-column FP32 scales and INT32 accumulation.
BF16 uses native BF16 MMAC with FP32 accumulation.
Both round gate/up to BF16 in registers before FP32 SiLU*up and final BF16 RNE.

```python
from fused_gemm import prepare_weight, silu_mul
p = prepare_weight(w16)
y = silu_mul(x16, p)
p = prepare_weight(w8, scale_b=sw)
y = silu_mul(xq, p, scale_a=sx)
```

All calls include online A packing. Re-prepare after changing W or sw.
No bias, clipping, arbitrary N/K, autograd or model-dispatch integration.
Warm up required M before Graph capture.
Standalone activations are AITER(limit=0) and a single-kernel Triton implementation.
Full validation, tiny-value numerical limits, independent formal timing and same-tile control are in REPORT.md / RESULT.json.
Tests and benchmarks select physical GPU5 on BW47; the runtime inherits the caller's GPU mapping.
Old packages and source hashes are independently preserved in PRESERVED.json.
