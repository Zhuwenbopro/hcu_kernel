from validate import *
import time,random,gc
COPIES=72
ROUNDS=5
def capture(fn):
    g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):ys=fn()
    return g,ys
def measure(g):
    a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
    a.record();g.replay();b.record();b.synchronize()
    return a.elapsed_time(b)*1000/COPIES

def pool(seed):
    torch.manual_seed(seed)
    x=torch.randn((256,bg.K),device='cuda',dtype=torch.bfloat16)
    weights=[];prepared=[]
    for i in range(COPIES):
        w=torch.randn((bg.N,bg.K),device='cuda',dtype=torch.bfloat16)
        b=w.t();pw=bg.prepare_weight(b)
        weights.append(b);prepared.append(pw)
    ref64=x.double()@weights[-1].double()
    torch.cuda.synchronize()
    return x,weights,prepared,ref64

def eligible(eng,f,m):
    if f=='E030':return m<=64
    k=eng.kernel(m,family=f)
    return k.bm==128 or m<=k.bm

def main():
    assert json.loads((R/'validation.json').read_text())['status']=='complete'
    eng=bg.engine()
    eng.routes=json.loads((R/'initial-policy.json').read_text())['by_M']
    x,weights,prepared,ref64=pool(202611149921)
    fs=sorted(set(rec['base_family'] for rec in eng.records))
    groups=[];policy={}
    orderM=list(range(1,257));random.Random(202611149921).shuffle(orderM)
    save('tuning-status.json',{'status':'running','groups':0})
    with (R/'tuning-raw.jsonl').open('w') as out:
        for mi,m in enumerate(orderM):
            a=x[:m]
            families=[f for f in fs if eligible(eng,f,m)]
            graphs={};ys={}
            for f in families:
                def call(f=f):return [eng.mm(a,pw,out_dtype=torch.bfloat16,family=f) for pw in prepared]
                graphs[f],ys[f]=capture(call)
            for g in graphs.values():g.replay()
            torch.cuda.synchronize()
            for f in families:close_bf16(ys[f][-1],ref64[:m])
            group={'M':m,'families':families,'samples':[]}
            rng=random.Random(m+202611149921)
            for rnd in range(ROUNDS):
                order=list(families);rng.shuffle(order)
                row={'round':rnd,'order':order,'us':{}}
                for f in order:
                    row['us'][f]=measure(graphs[f])
                    close_bf16(ys[f][-1],ref64[:m])
                group['samples'].append(row)
            times={f:statistics.median(s['us'][f] for s in group['samples']) for f in families}
            winner=min(times,key=times.get)
            prior=eng.routes[str(m)]
            # Retain the prior route when the measured alternative saves <0.5us.
            if times[prior]-times[winner]<.5:winner=prior
            policy[str(m)]=winner
            group.update(median_us=times,selected=winner,prior=prior)
            out.write(json.dumps(group,separators=(',',':'))+'\n');out.flush();groups.append(group)
            save('tuning-status.json',{'status':'running','groups':len(groups),'M':m,'selected':winner,'us':times[winner],'prior_us':times[prior]})
            if (mi+1)%16==0 or m in [1,32,64,128,129,192,193,256]:print('TUNE',mi+1,m,winner,round(times[winner],3),'prior',prior,round(times[prior],3),flush=True)
            del graphs,ys,g
            if mi%16==15:gc.collect()
    save('bf16-policy.json',{'scope':{'M':[1,256],'N':bg.N,'K':bg.K},'origin':'BF16 candidate selection, independent tuning seed; includes activation packing','training_seed':202611149921,'rounds':ROUNDS,'copies':COPIES,'by_M':policy})
    save('tuning-result.json',{'status':'complete','groups':groups,'selected_counts':{f:list(policy.values()).count(f) for f in set(policy.values())}})
    save('tuning-status.json',{'status':'complete','groups':len(groups)})
    print('TUNING_DONE',len(groups),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException as e:
        save('tuning-failure.json',{'error':str(e),'traceback':traceback.format_exc()});traceback.print_exc();sys.exit(1)
