; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.M128_SAB_BF16_FP32,#alloc,#execinstr
.protected M128_SAB_BF16_FP32
.globl M128_SAB_BF16_FP32
.p2align 8
.type M128_SAB_BF16_FP32,@function
M128_SAB_BF16_FP32:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v112, 63, v0
v_lshlrev_b32_e32 v112, 4, v112
v_lshrrev_b32_e32 v113, 6, v0
v_lshlrev_b32_e32 v115, 4, v0
v_lshlrev_b32_e32 v116, 10, v113
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_lshl_b32 s22, s7, 7
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_lshl_b32 s21, s7, 13
s_mov_b32 s0, s10
s_add_u32 s1, s11, 0x40800000
s_mov_b32 s18, s16
s_mov_b32 s19, s17
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v114, 11, v113
s_add_u32 s8, s8, s21
s_addc_u32 s9, s9, 0
v_add_u32_e32 v114, v114, v112
v_add_u32_e32 v115, s20, v115
v_mov_b32_e32 v123, s9
v_readfirstlane_b32 s26, v116
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_X_GLOBAL_SADDR_TO_REG v[64:67], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[68:71], v114, s[8:9], 1024
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
s_mov_b32 s24, 80
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
; issue private and shared stage to slot1
GEMM_X_GLOBAL_SADDR_TO_REG v[72:75], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[76:79], v114, s[8:9], 1024
s_add_u32 m0, s26, 8192
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 12288
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
v_add_u32_e32 v121, 0, v112
GEMM_LDS_TO_REG v[80:83], v121, 0
GEMM_LDS_TO_REG v[84:87], v121, 1024
GEMM_LDS_TO_REG v[88:91], v121, 2048
GEMM_LDS_TO_REG v[92:95], v121, 3072
GEMM_LDS_TO_REG v[96:99], v121, 4096
GEMM_LDS_TO_REG v[100:103], v121, 5120
GEMM_LDS_TO_REG v[104:107], v121, 6144
GEMM_LDS_TO_REG v[108:111], v121, 7168
GEMM_WAIT_LGKM 7
GEMM_MMA_BF16 v[0:3], v[64:65], v[80:81], v[0:3]
GEMM_MMA_BF16 v[4:7], v[68:69], v[80:81], v[4:7]
GEMM_MMA_BF16 v[0:3], v[66:67], v[82:83], v[0:3]
GEMM_MMA_BF16 v[4:7], v[70:71], v[82:83], v[4:7]
GEMM_WAIT_LGKM 6
GEMM_MMA_BF16 v[8:11], v[64:65], v[84:85], v[8:11]
GEMM_MMA_BF16 v[12:15], v[68:69], v[84:85], v[12:15]
GEMM_MMA_BF16 v[8:11], v[66:67], v[86:87], v[8:11]
GEMM_MMA_BF16 v[12:15], v[70:71], v[86:87], v[12:15]
GEMM_WAIT_LGKM 5
GEMM_MMA_BF16 v[16:19], v[64:65], v[88:89], v[16:19]
GEMM_MMA_BF16 v[20:23], v[68:69], v[88:89], v[20:23]
GEMM_MMA_BF16 v[16:19], v[66:67], v[90:91], v[16:19]
GEMM_MMA_BF16 v[20:23], v[70:71], v[90:91], v[20:23]
GEMM_WAIT_LGKM 4
GEMM_MMA_BF16 v[24:27], v[64:65], v[92:93], v[24:27]
GEMM_MMA_BF16 v[28:31], v[68:69], v[92:93], v[28:31]
GEMM_MMA_BF16 v[24:27], v[66:67], v[94:95], v[24:27]
GEMM_MMA_BF16 v[28:31], v[70:71], v[94:95], v[28:31]
GEMM_WAIT_LGKM 3
GEMM_MMA_BF16 v[32:35], v[64:65], v[96:97], v[32:35]
GEMM_MMA_BF16 v[36:39], v[68:69], v[96:97], v[36:39]
GEMM_MMA_BF16 v[32:35], v[66:67], v[98:99], v[32:35]
GEMM_MMA_BF16 v[36:39], v[70:71], v[98:99], v[36:39]
GEMM_WAIT_LGKM 2
GEMM_MMA_BF16 v[40:43], v[64:65], v[100:101], v[40:43]
GEMM_MMA_BF16 v[44:47], v[68:69], v[100:101], v[44:47]
GEMM_MMA_BF16 v[40:43], v[66:67], v[102:103], v[40:43]
GEMM_MMA_BF16 v[44:47], v[70:71], v[102:103], v[44:47]
GEMM_WAIT_LGKM 1
GEMM_MMA_BF16 v[48:51], v[64:65], v[104:105], v[48:51]
GEMM_MMA_BF16 v[52:55], v[68:69], v[104:105], v[52:55]
GEMM_MMA_BF16 v[48:51], v[66:67], v[106:107], v[48:51]
GEMM_MMA_BF16 v[52:55], v[70:71], v[106:107], v[52:55]
GEMM_WAIT_LGKM 0
GEMM_MMA_BF16 v[56:59], v[64:65], v[108:109], v[56:59]
GEMM_MMA_BF16 v[60:63], v[68:69], v[108:109], v[60:63]
GEMM_MMA_BF16 v[56:59], v[66:67], v[110:111], v[56:59]
GEMM_MMA_BF16 v[60:63], v[70:71], v[110:111], v[60:63]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_skip_next
; issue private and shared stage to slot0
GEMM_X_GLOBAL_SADDR_TO_REG v[64:67], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[68:71], v114, s[8:9], 1024
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
.L_skip_next:
v_add_u32_e32 v121, 8192, v112
GEMM_LDS_TO_REG v[80:83], v121, 0
GEMM_LDS_TO_REG v[84:87], v121, 1024
GEMM_LDS_TO_REG v[88:91], v121, 2048
GEMM_LDS_TO_REG v[92:95], v121, 3072
GEMM_LDS_TO_REG v[96:99], v121, 4096
GEMM_LDS_TO_REG v[100:103], v121, 5120
GEMM_LDS_TO_REG v[104:107], v121, 6144
GEMM_LDS_TO_REG v[108:111], v121, 7168
GEMM_WAIT_LGKM 7
GEMM_MMA_BF16 v[0:3], v[72:73], v[80:81], v[0:3]
GEMM_MMA_BF16 v[4:7], v[76:77], v[80:81], v[4:7]
GEMM_MMA_BF16 v[0:3], v[74:75], v[82:83], v[0:3]
GEMM_MMA_BF16 v[4:7], v[78:79], v[82:83], v[4:7]
GEMM_WAIT_LGKM 6
GEMM_MMA_BF16 v[8:11], v[72:73], v[84:85], v[8:11]
GEMM_MMA_BF16 v[12:15], v[76:77], v[84:85], v[12:15]
GEMM_MMA_BF16 v[8:11], v[74:75], v[86:87], v[8:11]
GEMM_MMA_BF16 v[12:15], v[78:79], v[86:87], v[12:15]
GEMM_WAIT_LGKM 5
GEMM_MMA_BF16 v[16:19], v[72:73], v[88:89], v[16:19]
GEMM_MMA_BF16 v[20:23], v[76:77], v[88:89], v[20:23]
GEMM_MMA_BF16 v[16:19], v[74:75], v[90:91], v[16:19]
GEMM_MMA_BF16 v[20:23], v[78:79], v[90:91], v[20:23]
GEMM_WAIT_LGKM 4
GEMM_MMA_BF16 v[24:27], v[72:73], v[92:93], v[24:27]
GEMM_MMA_BF16 v[28:31], v[76:77], v[92:93], v[28:31]
GEMM_MMA_BF16 v[24:27], v[74:75], v[94:95], v[24:27]
GEMM_MMA_BF16 v[28:31], v[78:79], v[94:95], v[28:31]
GEMM_WAIT_LGKM 3
GEMM_MMA_BF16 v[32:35], v[72:73], v[96:97], v[32:35]
GEMM_MMA_BF16 v[36:39], v[76:77], v[96:97], v[36:39]
GEMM_MMA_BF16 v[32:35], v[74:75], v[98:99], v[32:35]
GEMM_MMA_BF16 v[36:39], v[78:79], v[98:99], v[36:39]
GEMM_WAIT_LGKM 2
GEMM_MMA_BF16 v[40:43], v[72:73], v[100:101], v[40:43]
GEMM_MMA_BF16 v[44:47], v[76:77], v[100:101], v[44:47]
GEMM_MMA_BF16 v[40:43], v[74:75], v[102:103], v[40:43]
GEMM_MMA_BF16 v[44:47], v[78:79], v[102:103], v[44:47]
GEMM_WAIT_LGKM 1
GEMM_MMA_BF16 v[48:51], v[72:73], v[104:105], v[48:51]
GEMM_MMA_BF16 v[52:55], v[76:77], v[104:105], v[52:55]
GEMM_MMA_BF16 v[48:51], v[74:75], v[106:107], v[48:51]
GEMM_MMA_BF16 v[52:55], v[78:79], v[106:107], v[52:55]
GEMM_WAIT_LGKM 0
GEMM_MMA_BF16 v[56:59], v[72:73], v[108:109], v[56:59]
GEMM_MMA_BF16 v[60:63], v[76:77], v[108:109], v[60:63]
GEMM_MMA_BF16 v[56:59], v[74:75], v[110:111], v[56:59]
GEMM_MMA_BF16 v[60:63], v[78:79], v[110:111], v[60:63]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
GEMM_WAIT_VM 0
v_mov_b32_e32 v123, s13
v_lshrrev_b32_e32 v114, 4, v112
v_and_b32_e32 v114, 15, v114
v_lshrrev_b32_e32 v115, 8, v112
v_lshlrev_b32_e32 v115, 4, v115
v_lshlrev_b32_e32 v116, 5, v113
v_add_u32_e32 v114, v116, v114
v_add_u32_e32 v114, s22, v114
v_add_u32_e32 v115, s23, v115
v_add_u32_e32 v119, 0, v114
v_cmp_gt_u32_e32 vcc, s14, v119
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_mul_u32_u24_e32 v120, 0x11000, v119
v_add_u32_e32 v120, v115, v120
v_add_co_u32_e32 v117, vcc, s12, v120
v_addc_co_u32_e32 v118, vcc, 0, v123, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[0:3], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[8:11], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[16:19], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[24:27], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[32:35], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[40:43], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[48:51], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[56:59], 448
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v119, 16, v114
v_cmp_gt_u32_e32 vcc, s14, v119
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_mul_u32_u24_e32 v120, 0x11000, v119
v_add_u32_e32 v120, v115, v120
v_add_co_u32_e32 v117, vcc, s12, v120
v_addc_co_u32_e32 v118, vcc, 0, v123, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[4:7], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[12:15], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[20:23], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[28:31], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[36:39], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[44:47], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[52:55], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[117:118], v[60:63], 448
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size M128_SAB_BF16_FP32, .L_func_end-M128_SAB_BF16_FP32
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel M128_SAB_BF16_FP32
.amdhsa_group_segment_fixed_size 16384
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 40
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 124
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 16384
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           M128_SAB_BF16_FP32
    .private_segment_fixed_size: 0
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         M128_SAB_BF16_FP32.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     124
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...
.end_amdgpu_metadata
