; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.M128_SAB_BF16_BF16,#alloc,#execinstr
.protected M128_SAB_BF16_BF16
.globl M128_SAB_BF16_BF16
.p2align 8
.type M128_SAB_BF16_BF16,@function
M128_SAB_BF16_BF16:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v112, 63, v0
v_lshlrev_b32_e32 v112, 4, v112
v_lshrrev_b32_e32 v113, 6, v0
v_lshlrev_b32_e32 v115, 4, v0
v_lshlrev_b32_e32 v116, 10, v113
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_lshl_b32 s22, s7, 7
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_lshl_b32 s21, s7, 13
s_mov_b32 s0, s10
s_add_u32 s1, s11, 0x40800000
s_mov_b32 s18, s16
s_mov_b32 s19, s17
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v114, 11, v113
s_add_u32 s8, s8, s21
s_addc_u32 s9, s9, 0
v_add_u32_e32 v114, v114, v112
v_add_u32_e32 v115, s20, v115
v_mov_b32_e32 v123, s9
v_readfirstlane_b32 s26, v116
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_X_GLOBAL_SADDR_TO_REG v[64:67], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[68:71], v114, s[8:9], 1024
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
s_mov_b32 s24, 80
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
; issue private and shared stage to slot1
GEMM_X_GLOBAL_SADDR_TO_REG v[72:75], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[76:79], v114, s[8:9], 1024
s_add_u32 m0, s26, 8192
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 12288
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
v_add_u32_e32 v121, 0, v112
GEMM_LDS_TO_REG v[80:83], v121, 0
GEMM_LDS_TO_REG v[84:87], v121, 1024
GEMM_LDS_TO_REG v[88:91], v121, 2048
GEMM_LDS_TO_REG v[92:95], v121, 3072
GEMM_LDS_TO_REG v[96:99], v121, 4096
GEMM_LDS_TO_REG v[100:103], v121, 5120
GEMM_LDS_TO_REG v[104:107], v121, 6144
GEMM_LDS_TO_REG v[108:111], v121, 7168
GEMM_WAIT_LGKM 7
GEMM_MMA_BF16 v[0:3], v[64:65], v[80:81], v[0:3]
GEMM_MMA_BF16 v[4:7], v[68:69], v[80:81], v[4:7]
GEMM_MMA_BF16 v[0:3], v[66:67], v[82:83], v[0:3]
GEMM_MMA_BF16 v[4:7], v[70:71], v[82:83], v[4:7]
GEMM_WAIT_LGKM 6
GEMM_MMA_BF16 v[8:11], v[64:65], v[84:85], v[8:11]
GEMM_MMA_BF16 v[12:15], v[68:69], v[84:85], v[12:15]
GEMM_MMA_BF16 v[8:11], v[66:67], v[86:87], v[8:11]
GEMM_MMA_BF16 v[12:15], v[70:71], v[86:87], v[12:15]
GEMM_WAIT_LGKM 5
GEMM_MMA_BF16 v[16:19], v[64:65], v[88:89], v[16:19]
GEMM_MMA_BF16 v[20:23], v[68:69], v[88:89], v[20:23]
GEMM_MMA_BF16 v[16:19], v[66:67], v[90:91], v[16:19]
GEMM_MMA_BF16 v[20:23], v[70:71], v[90:91], v[20:23]
GEMM_WAIT_LGKM 4
GEMM_MMA_BF16 v[24:27], v[64:65], v[92:93], v[24:27]
GEMM_MMA_BF16 v[28:31], v[68:69], v[92:93], v[28:31]
GEMM_MMA_BF16 v[24:27], v[66:67], v[94:95], v[24:27]
GEMM_MMA_BF16 v[28:31], v[70:71], v[94:95], v[28:31]
GEMM_WAIT_LGKM 3
GEMM_MMA_BF16 v[32:35], v[64:65], v[96:97], v[32:35]
GEMM_MMA_BF16 v[36:39], v[68:69], v[96:97], v[36:39]
GEMM_MMA_BF16 v[32:35], v[66:67], v[98:99], v[32:35]
GEMM_MMA_BF16 v[36:39], v[70:71], v[98:99], v[36:39]
GEMM_WAIT_LGKM 2
GEMM_MMA_BF16 v[40:43], v[64:65], v[100:101], v[40:43]
GEMM_MMA_BF16 v[44:47], v[68:69], v[100:101], v[44:47]
GEMM_MMA_BF16 v[40:43], v[66:67], v[102:103], v[40:43]
GEMM_MMA_BF16 v[44:47], v[70:71], v[102:103], v[44:47]
GEMM_WAIT_LGKM 1
GEMM_MMA_BF16 v[48:51], v[64:65], v[104:105], v[48:51]
GEMM_MMA_BF16 v[52:55], v[68:69], v[104:105], v[52:55]
GEMM_MMA_BF16 v[48:51], v[66:67], v[106:107], v[48:51]
GEMM_MMA_BF16 v[52:55], v[70:71], v[106:107], v[52:55]
GEMM_WAIT_LGKM 0
GEMM_MMA_BF16 v[56:59], v[64:65], v[108:109], v[56:59]
GEMM_MMA_BF16 v[60:63], v[68:69], v[108:109], v[60:63]
GEMM_MMA_BF16 v[56:59], v[66:67], v[110:111], v[56:59]
GEMM_MMA_BF16 v[60:63], v[70:71], v[110:111], v[60:63]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_skip_next
; issue private and shared stage to slot0
GEMM_X_GLOBAL_SADDR_TO_REG v[64:67], v114, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[68:71], v114, s[8:9], 1024
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v115, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v115, s19, v115
.L_skip_next:
v_add_u32_e32 v121, 8192, v112
GEMM_LDS_TO_REG v[80:83], v121, 0
GEMM_LDS_TO_REG v[84:87], v121, 1024
GEMM_LDS_TO_REG v[88:91], v121, 2048
GEMM_LDS_TO_REG v[92:95], v121, 3072
GEMM_LDS_TO_REG v[96:99], v121, 4096
GEMM_LDS_TO_REG v[100:103], v121, 5120
GEMM_LDS_TO_REG v[104:107], v121, 6144
GEMM_LDS_TO_REG v[108:111], v121, 7168
GEMM_WAIT_LGKM 7
GEMM_MMA_BF16 v[0:3], v[72:73], v[80:81], v[0:3]
GEMM_MMA_BF16 v[4:7], v[76:77], v[80:81], v[4:7]
GEMM_MMA_BF16 v[0:3], v[74:75], v[82:83], v[0:3]
GEMM_MMA_BF16 v[4:7], v[78:79], v[82:83], v[4:7]
GEMM_WAIT_LGKM 6
GEMM_MMA_BF16 v[8:11], v[72:73], v[84:85], v[8:11]
GEMM_MMA_BF16 v[12:15], v[76:77], v[84:85], v[12:15]
GEMM_MMA_BF16 v[8:11], v[74:75], v[86:87], v[8:11]
GEMM_MMA_BF16 v[12:15], v[78:79], v[86:87], v[12:15]
GEMM_WAIT_LGKM 5
GEMM_MMA_BF16 v[16:19], v[72:73], v[88:89], v[16:19]
GEMM_MMA_BF16 v[20:23], v[76:77], v[88:89], v[20:23]
GEMM_MMA_BF16 v[16:19], v[74:75], v[90:91], v[16:19]
GEMM_MMA_BF16 v[20:23], v[78:79], v[90:91], v[20:23]
GEMM_WAIT_LGKM 4
GEMM_MMA_BF16 v[24:27], v[72:73], v[92:93], v[24:27]
GEMM_MMA_BF16 v[28:31], v[76:77], v[92:93], v[28:31]
GEMM_MMA_BF16 v[24:27], v[74:75], v[94:95], v[24:27]
GEMM_MMA_BF16 v[28:31], v[78:79], v[94:95], v[28:31]
GEMM_WAIT_LGKM 3
GEMM_MMA_BF16 v[32:35], v[72:73], v[96:97], v[32:35]
GEMM_MMA_BF16 v[36:39], v[76:77], v[96:97], v[36:39]
GEMM_MMA_BF16 v[32:35], v[74:75], v[98:99], v[32:35]
GEMM_MMA_BF16 v[36:39], v[78:79], v[98:99], v[36:39]
GEMM_WAIT_LGKM 2
GEMM_MMA_BF16 v[40:43], v[72:73], v[100:101], v[40:43]
GEMM_MMA_BF16 v[44:47], v[76:77], v[100:101], v[44:47]
GEMM_MMA_BF16 v[40:43], v[74:75], v[102:103], v[40:43]
GEMM_MMA_BF16 v[44:47], v[78:79], v[102:103], v[44:47]
GEMM_WAIT_LGKM 1
GEMM_MMA_BF16 v[48:51], v[72:73], v[104:105], v[48:51]
GEMM_MMA_BF16 v[52:55], v[76:77], v[104:105], v[52:55]
GEMM_MMA_BF16 v[48:51], v[74:75], v[106:107], v[48:51]
GEMM_MMA_BF16 v[52:55], v[78:79], v[106:107], v[52:55]
GEMM_WAIT_LGKM 0
GEMM_MMA_BF16 v[56:59], v[72:73], v[108:109], v[56:59]
GEMM_MMA_BF16 v[60:63], v[76:77], v[108:109], v[60:63]
GEMM_MMA_BF16 v[56:59], v[74:75], v[110:111], v[56:59]
GEMM_MMA_BF16 v[60:63], v[78:79], v[110:111], v[60:63]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
GEMM_WAIT_VM 0
v_mov_b32_e32 v123, s13
v_lshrrev_b32_e32 v114, 4, v112
v_and_b32_e32 v114, 15, v114
v_lshrrev_b32_e32 v115, 8, v112
v_lshlrev_b32_e32 v115, 4, v115
v_lshlrev_b32_e32 v116, 5, v113
v_add_u32_e32 v114, v116, v114
v_add_u32_e32 v114, s22, v114
v_add_u32_e32 v115, s23, v115
v_add_u32_e32 v119, 0, v114
v_cmp_gt_u32_e32 vcc, s14, v119
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_mul_u32_u24_e32 v120, 0x11000, v119
v_add_u32_e32 v120, v115, v120
v_lshrrev_b32_e32 v120, 1, v120
v_add_co_u32_e32 v117, vcc, s12, v120
v_addc_co_u32_e32 v118, vcc, 0, v123, vcc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v0, v0
v_lshrrev_b32_e32 v64, 16, v0
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v0, 0x7fff, v0
v_add_u32_e32 v0, v64, v0
v_cndmask_b32_e32 v0, v0, v65, vcc
v_cmp_u_f32_e32 vcc, v1, v1
v_lshrrev_b32_e32 v64, 16, v1
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v1, 0x7fff, v1
v_add_u32_e32 v1, v64, v1
v_cndmask_b32_e32 v1, v1, v65, vcc
v_cmp_u_f32_e32 vcc, v2, v2
v_lshrrev_b32_e32 v64, 16, v2
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v2, 0x7fff, v2
v_add_u32_e32 v2, v64, v2
v_cndmask_b32_e32 v2, v2, v65, vcc
v_cmp_u_f32_e32 vcc, v3, v3
v_lshrrev_b32_e32 v64, 16, v3
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v3, 0x7fff, v3
v_add_u32_e32 v3, v64, v3
v_cndmask_b32_e32 v3, v3, v65, vcc
v_lshrrev_b32_e32 v0, 16, v0
v_and_b32_e32 v1, 0xffff0000, v1
v_or_b32_e32 v0, v0, v1
v_lshrrev_b32_e32 v2, 16, v2
v_and_b32_e32 v3, 0xffff0000, v3
v_or_b32_e32 v1, v2, v3
global_store_dwordx2 v[117:118], v[0:1], off offset:0 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v8, v8
v_lshrrev_b32_e32 v64, 16, v8
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v8, 0x7fff, v8
v_add_u32_e32 v8, v64, v8
v_cndmask_b32_e32 v8, v8, v65, vcc
v_cmp_u_f32_e32 vcc, v9, v9
v_lshrrev_b32_e32 v64, 16, v9
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v9, 0x7fff, v9
v_add_u32_e32 v9, v64, v9
v_cndmask_b32_e32 v9, v9, v65, vcc
v_cmp_u_f32_e32 vcc, v10, v10
v_lshrrev_b32_e32 v64, 16, v10
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v10, 0x7fff, v10
v_add_u32_e32 v10, v64, v10
v_cndmask_b32_e32 v10, v10, v65, vcc
v_cmp_u_f32_e32 vcc, v11, v11
v_lshrrev_b32_e32 v64, 16, v11
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v11, 0x7fff, v11
v_add_u32_e32 v11, v64, v11
v_cndmask_b32_e32 v11, v11, v65, vcc
v_lshrrev_b32_e32 v8, 16, v8
v_and_b32_e32 v9, 0xffff0000, v9
v_or_b32_e32 v8, v8, v9
v_lshrrev_b32_e32 v10, 16, v10
v_and_b32_e32 v11, 0xffff0000, v11
v_or_b32_e32 v9, v10, v11
global_store_dwordx2 v[117:118], v[8:9], off offset:32 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v16, v16
v_lshrrev_b32_e32 v64, 16, v16
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v16, 0x7fff, v16
v_add_u32_e32 v16, v64, v16
v_cndmask_b32_e32 v16, v16, v65, vcc
v_cmp_u_f32_e32 vcc, v17, v17
v_lshrrev_b32_e32 v64, 16, v17
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v17, 0x7fff, v17
v_add_u32_e32 v17, v64, v17
v_cndmask_b32_e32 v17, v17, v65, vcc
v_cmp_u_f32_e32 vcc, v18, v18
v_lshrrev_b32_e32 v64, 16, v18
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v18, 0x7fff, v18
v_add_u32_e32 v18, v64, v18
v_cndmask_b32_e32 v18, v18, v65, vcc
v_cmp_u_f32_e32 vcc, v19, v19
v_lshrrev_b32_e32 v64, 16, v19
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v19, 0x7fff, v19
v_add_u32_e32 v19, v64, v19
v_cndmask_b32_e32 v19, v19, v65, vcc
v_lshrrev_b32_e32 v16, 16, v16
v_and_b32_e32 v17, 0xffff0000, v17
v_or_b32_e32 v16, v16, v17
v_lshrrev_b32_e32 v18, 16, v18
v_and_b32_e32 v19, 0xffff0000, v19
v_or_b32_e32 v17, v18, v19
global_store_dwordx2 v[117:118], v[16:17], off offset:64 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v24, v24
v_lshrrev_b32_e32 v64, 16, v24
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v24, 0x7fff, v24
v_add_u32_e32 v24, v64, v24
v_cndmask_b32_e32 v24, v24, v65, vcc
v_cmp_u_f32_e32 vcc, v25, v25
v_lshrrev_b32_e32 v64, 16, v25
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v25, 0x7fff, v25
v_add_u32_e32 v25, v64, v25
v_cndmask_b32_e32 v25, v25, v65, vcc
v_cmp_u_f32_e32 vcc, v26, v26
v_lshrrev_b32_e32 v64, 16, v26
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v26, 0x7fff, v26
v_add_u32_e32 v26, v64, v26
v_cndmask_b32_e32 v26, v26, v65, vcc
v_cmp_u_f32_e32 vcc, v27, v27
v_lshrrev_b32_e32 v64, 16, v27
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v27, 0x7fff, v27
v_add_u32_e32 v27, v64, v27
v_cndmask_b32_e32 v27, v27, v65, vcc
v_lshrrev_b32_e32 v24, 16, v24
v_and_b32_e32 v25, 0xffff0000, v25
v_or_b32_e32 v24, v24, v25
v_lshrrev_b32_e32 v26, 16, v26
v_and_b32_e32 v27, 0xffff0000, v27
v_or_b32_e32 v25, v26, v27
global_store_dwordx2 v[117:118], v[24:25], off offset:96 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v32, v32
v_lshrrev_b32_e32 v64, 16, v32
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v32, 0x7fff, v32
v_add_u32_e32 v32, v64, v32
v_cndmask_b32_e32 v32, v32, v65, vcc
v_cmp_u_f32_e32 vcc, v33, v33
v_lshrrev_b32_e32 v64, 16, v33
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v33, 0x7fff, v33
v_add_u32_e32 v33, v64, v33
v_cndmask_b32_e32 v33, v33, v65, vcc
v_cmp_u_f32_e32 vcc, v34, v34
v_lshrrev_b32_e32 v64, 16, v34
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v34, 0x7fff, v34
v_add_u32_e32 v34, v64, v34
v_cndmask_b32_e32 v34, v34, v65, vcc
v_cmp_u_f32_e32 vcc, v35, v35
v_lshrrev_b32_e32 v64, 16, v35
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v35, 0x7fff, v35
v_add_u32_e32 v35, v64, v35
v_cndmask_b32_e32 v35, v35, v65, vcc
v_lshrrev_b32_e32 v32, 16, v32
v_and_b32_e32 v33, 0xffff0000, v33
v_or_b32_e32 v32, v32, v33
v_lshrrev_b32_e32 v34, 16, v34
v_and_b32_e32 v35, 0xffff0000, v35
v_or_b32_e32 v33, v34, v35
global_store_dwordx2 v[117:118], v[32:33], off offset:128 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v40, v40
v_lshrrev_b32_e32 v64, 16, v40
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v40, 0x7fff, v40
v_add_u32_e32 v40, v64, v40
v_cndmask_b32_e32 v40, v40, v65, vcc
v_cmp_u_f32_e32 vcc, v41, v41
v_lshrrev_b32_e32 v64, 16, v41
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v41, 0x7fff, v41
v_add_u32_e32 v41, v64, v41
v_cndmask_b32_e32 v41, v41, v65, vcc
v_cmp_u_f32_e32 vcc, v42, v42
v_lshrrev_b32_e32 v64, 16, v42
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v42, 0x7fff, v42
v_add_u32_e32 v42, v64, v42
v_cndmask_b32_e32 v42, v42, v65, vcc
v_cmp_u_f32_e32 vcc, v43, v43
v_lshrrev_b32_e32 v64, 16, v43
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v43, 0x7fff, v43
v_add_u32_e32 v43, v64, v43
v_cndmask_b32_e32 v43, v43, v65, vcc
v_lshrrev_b32_e32 v40, 16, v40
v_and_b32_e32 v41, 0xffff0000, v41
v_or_b32_e32 v40, v40, v41
v_lshrrev_b32_e32 v42, 16, v42
v_and_b32_e32 v43, 0xffff0000, v43
v_or_b32_e32 v41, v42, v43
global_store_dwordx2 v[117:118], v[40:41], off offset:160 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v48, v48
v_lshrrev_b32_e32 v64, 16, v48
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v48, 0x7fff, v48
v_add_u32_e32 v48, v64, v48
v_cndmask_b32_e32 v48, v48, v65, vcc
v_cmp_u_f32_e32 vcc, v49, v49
v_lshrrev_b32_e32 v64, 16, v49
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v49, 0x7fff, v49
v_add_u32_e32 v49, v64, v49
v_cndmask_b32_e32 v49, v49, v65, vcc
v_cmp_u_f32_e32 vcc, v50, v50
v_lshrrev_b32_e32 v64, 16, v50
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v50, 0x7fff, v50
v_add_u32_e32 v50, v64, v50
v_cndmask_b32_e32 v50, v50, v65, vcc
v_cmp_u_f32_e32 vcc, v51, v51
v_lshrrev_b32_e32 v64, 16, v51
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v51, 0x7fff, v51
v_add_u32_e32 v51, v64, v51
v_cndmask_b32_e32 v51, v51, v65, vcc
v_lshrrev_b32_e32 v48, 16, v48
v_and_b32_e32 v49, 0xffff0000, v49
v_or_b32_e32 v48, v48, v49
v_lshrrev_b32_e32 v50, 16, v50
v_and_b32_e32 v51, 0xffff0000, v51
v_or_b32_e32 v49, v50, v51
global_store_dwordx2 v[117:118], v[48:49], off offset:192 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v56, v56
v_lshrrev_b32_e32 v64, 16, v56
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v56, 0x7fff, v56
v_add_u32_e32 v56, v64, v56
v_cndmask_b32_e32 v56, v56, v65, vcc
v_cmp_u_f32_e32 vcc, v57, v57
v_lshrrev_b32_e32 v64, 16, v57
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v57, 0x7fff, v57
v_add_u32_e32 v57, v64, v57
v_cndmask_b32_e32 v57, v57, v65, vcc
v_cmp_u_f32_e32 vcc, v58, v58
v_lshrrev_b32_e32 v64, 16, v58
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v58, 0x7fff, v58
v_add_u32_e32 v58, v64, v58
v_cndmask_b32_e32 v58, v58, v65, vcc
v_cmp_u_f32_e32 vcc, v59, v59
v_lshrrev_b32_e32 v64, 16, v59
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v59, 0x7fff, v59
v_add_u32_e32 v59, v64, v59
v_cndmask_b32_e32 v59, v59, v65, vcc
v_lshrrev_b32_e32 v56, 16, v56
v_and_b32_e32 v57, 0xffff0000, v57
v_or_b32_e32 v56, v56, v57
v_lshrrev_b32_e32 v58, 16, v58
v_and_b32_e32 v59, 0xffff0000, v59
v_or_b32_e32 v57, v58, v59
global_store_dwordx2 v[117:118], v[56:57], off offset:224 glc slc
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v119, 16, v114
v_cmp_gt_u32_e32 vcc, s14, v119
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_mul_u32_u24_e32 v120, 0x11000, v119
v_add_u32_e32 v120, v115, v120
v_lshrrev_b32_e32 v120, 1, v120
v_add_co_u32_e32 v117, vcc, s12, v120
v_addc_co_u32_e32 v118, vcc, 0, v123, vcc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v4, v4
v_lshrrev_b32_e32 v64, 16, v4
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v4, 0x7fff, v4
v_add_u32_e32 v4, v64, v4
v_cndmask_b32_e32 v4, v4, v65, vcc
v_cmp_u_f32_e32 vcc, v5, v5
v_lshrrev_b32_e32 v64, 16, v5
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v5, 0x7fff, v5
v_add_u32_e32 v5, v64, v5
v_cndmask_b32_e32 v5, v5, v65, vcc
v_cmp_u_f32_e32 vcc, v6, v6
v_lshrrev_b32_e32 v64, 16, v6
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v6, 0x7fff, v6
v_add_u32_e32 v6, v64, v6
v_cndmask_b32_e32 v6, v6, v65, vcc
v_cmp_u_f32_e32 vcc, v7, v7
v_lshrrev_b32_e32 v64, 16, v7
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v7, 0x7fff, v7
v_add_u32_e32 v7, v64, v7
v_cndmask_b32_e32 v7, v7, v65, vcc
v_lshrrev_b32_e32 v4, 16, v4
v_and_b32_e32 v5, 0xffff0000, v5
v_or_b32_e32 v4, v4, v5
v_lshrrev_b32_e32 v6, 16, v6
v_and_b32_e32 v7, 0xffff0000, v7
v_or_b32_e32 v5, v6, v7
global_store_dwordx2 v[117:118], v[4:5], off offset:0 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v12, v12
v_lshrrev_b32_e32 v64, 16, v12
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v12, 0x7fff, v12
v_add_u32_e32 v12, v64, v12
v_cndmask_b32_e32 v12, v12, v65, vcc
v_cmp_u_f32_e32 vcc, v13, v13
v_lshrrev_b32_e32 v64, 16, v13
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v13, 0x7fff, v13
v_add_u32_e32 v13, v64, v13
v_cndmask_b32_e32 v13, v13, v65, vcc
v_cmp_u_f32_e32 vcc, v14, v14
v_lshrrev_b32_e32 v64, 16, v14
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v14, 0x7fff, v14
v_add_u32_e32 v14, v64, v14
v_cndmask_b32_e32 v14, v14, v65, vcc
v_cmp_u_f32_e32 vcc, v15, v15
v_lshrrev_b32_e32 v64, 16, v15
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v15, 0x7fff, v15
v_add_u32_e32 v15, v64, v15
v_cndmask_b32_e32 v15, v15, v65, vcc
v_lshrrev_b32_e32 v12, 16, v12
v_and_b32_e32 v13, 0xffff0000, v13
v_or_b32_e32 v12, v12, v13
v_lshrrev_b32_e32 v14, 16, v14
v_and_b32_e32 v15, 0xffff0000, v15
v_or_b32_e32 v13, v14, v15
global_store_dwordx2 v[117:118], v[12:13], off offset:32 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v20, v20
v_lshrrev_b32_e32 v64, 16, v20
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v20, 0x7fff, v20
v_add_u32_e32 v20, v64, v20
v_cndmask_b32_e32 v20, v20, v65, vcc
v_cmp_u_f32_e32 vcc, v21, v21
v_lshrrev_b32_e32 v64, 16, v21
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v21, 0x7fff, v21
v_add_u32_e32 v21, v64, v21
v_cndmask_b32_e32 v21, v21, v65, vcc
v_cmp_u_f32_e32 vcc, v22, v22
v_lshrrev_b32_e32 v64, 16, v22
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v22, 0x7fff, v22
v_add_u32_e32 v22, v64, v22
v_cndmask_b32_e32 v22, v22, v65, vcc
v_cmp_u_f32_e32 vcc, v23, v23
v_lshrrev_b32_e32 v64, 16, v23
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v23, 0x7fff, v23
v_add_u32_e32 v23, v64, v23
v_cndmask_b32_e32 v23, v23, v65, vcc
v_lshrrev_b32_e32 v20, 16, v20
v_and_b32_e32 v21, 0xffff0000, v21
v_or_b32_e32 v20, v20, v21
v_lshrrev_b32_e32 v22, 16, v22
v_and_b32_e32 v23, 0xffff0000, v23
v_or_b32_e32 v21, v22, v23
global_store_dwordx2 v[117:118], v[20:21], off offset:64 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v28, v28
v_lshrrev_b32_e32 v64, 16, v28
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v28, 0x7fff, v28
v_add_u32_e32 v28, v64, v28
v_cndmask_b32_e32 v28, v28, v65, vcc
v_cmp_u_f32_e32 vcc, v29, v29
v_lshrrev_b32_e32 v64, 16, v29
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v29, 0x7fff, v29
v_add_u32_e32 v29, v64, v29
v_cndmask_b32_e32 v29, v29, v65, vcc
v_cmp_u_f32_e32 vcc, v30, v30
v_lshrrev_b32_e32 v64, 16, v30
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v30, 0x7fff, v30
v_add_u32_e32 v30, v64, v30
v_cndmask_b32_e32 v30, v30, v65, vcc
v_cmp_u_f32_e32 vcc, v31, v31
v_lshrrev_b32_e32 v64, 16, v31
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v31, 0x7fff, v31
v_add_u32_e32 v31, v64, v31
v_cndmask_b32_e32 v31, v31, v65, vcc
v_lshrrev_b32_e32 v28, 16, v28
v_and_b32_e32 v29, 0xffff0000, v29
v_or_b32_e32 v28, v28, v29
v_lshrrev_b32_e32 v30, 16, v30
v_and_b32_e32 v31, 0xffff0000, v31
v_or_b32_e32 v29, v30, v31
global_store_dwordx2 v[117:118], v[28:29], off offset:96 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v36, v36
v_lshrrev_b32_e32 v64, 16, v36
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v36, 0x7fff, v36
v_add_u32_e32 v36, v64, v36
v_cndmask_b32_e32 v36, v36, v65, vcc
v_cmp_u_f32_e32 vcc, v37, v37
v_lshrrev_b32_e32 v64, 16, v37
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v37, 0x7fff, v37
v_add_u32_e32 v37, v64, v37
v_cndmask_b32_e32 v37, v37, v65, vcc
v_cmp_u_f32_e32 vcc, v38, v38
v_lshrrev_b32_e32 v64, 16, v38
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v38, 0x7fff, v38
v_add_u32_e32 v38, v64, v38
v_cndmask_b32_e32 v38, v38, v65, vcc
v_cmp_u_f32_e32 vcc, v39, v39
v_lshrrev_b32_e32 v64, 16, v39
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v39, 0x7fff, v39
v_add_u32_e32 v39, v64, v39
v_cndmask_b32_e32 v39, v39, v65, vcc
v_lshrrev_b32_e32 v36, 16, v36
v_and_b32_e32 v37, 0xffff0000, v37
v_or_b32_e32 v36, v36, v37
v_lshrrev_b32_e32 v38, 16, v38
v_and_b32_e32 v39, 0xffff0000, v39
v_or_b32_e32 v37, v38, v39
global_store_dwordx2 v[117:118], v[36:37], off offset:128 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v44, v44
v_lshrrev_b32_e32 v64, 16, v44
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v44, 0x7fff, v44
v_add_u32_e32 v44, v64, v44
v_cndmask_b32_e32 v44, v44, v65, vcc
v_cmp_u_f32_e32 vcc, v45, v45
v_lshrrev_b32_e32 v64, 16, v45
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v45, 0x7fff, v45
v_add_u32_e32 v45, v64, v45
v_cndmask_b32_e32 v45, v45, v65, vcc
v_cmp_u_f32_e32 vcc, v46, v46
v_lshrrev_b32_e32 v64, 16, v46
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v46, 0x7fff, v46
v_add_u32_e32 v46, v64, v46
v_cndmask_b32_e32 v46, v46, v65, vcc
v_cmp_u_f32_e32 vcc, v47, v47
v_lshrrev_b32_e32 v64, 16, v47
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v47, 0x7fff, v47
v_add_u32_e32 v47, v64, v47
v_cndmask_b32_e32 v47, v47, v65, vcc
v_lshrrev_b32_e32 v44, 16, v44
v_and_b32_e32 v45, 0xffff0000, v45
v_or_b32_e32 v44, v44, v45
v_lshrrev_b32_e32 v46, 16, v46
v_and_b32_e32 v47, 0xffff0000, v47
v_or_b32_e32 v45, v46, v47
global_store_dwordx2 v[117:118], v[44:45], off offset:160 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v52, v52
v_lshrrev_b32_e32 v64, 16, v52
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v52, 0x7fff, v52
v_add_u32_e32 v52, v64, v52
v_cndmask_b32_e32 v52, v52, v65, vcc
v_cmp_u_f32_e32 vcc, v53, v53
v_lshrrev_b32_e32 v64, 16, v53
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v53, 0x7fff, v53
v_add_u32_e32 v53, v64, v53
v_cndmask_b32_e32 v53, v53, v65, vcc
v_cmp_u_f32_e32 vcc, v54, v54
v_lshrrev_b32_e32 v64, 16, v54
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v54, 0x7fff, v54
v_add_u32_e32 v54, v64, v54
v_cndmask_b32_e32 v54, v54, v65, vcc
v_cmp_u_f32_e32 vcc, v55, v55
v_lshrrev_b32_e32 v64, 16, v55
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v55, 0x7fff, v55
v_add_u32_e32 v55, v64, v55
v_cndmask_b32_e32 v55, v55, v65, vcc
v_lshrrev_b32_e32 v52, 16, v52
v_and_b32_e32 v53, 0xffff0000, v53
v_or_b32_e32 v52, v52, v53
v_lshrrev_b32_e32 v54, 16, v54
v_and_b32_e32 v55, 0xffff0000, v55
v_or_b32_e32 v53, v54, v55
global_store_dwordx2 v[117:118], v[52:53], off offset:192 glc slc
v_mov_b32_e32 v65, 0x7fff0000
v_cmp_u_f32_e32 vcc, v60, v60
v_lshrrev_b32_e32 v64, 16, v60
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v60, 0x7fff, v60
v_add_u32_e32 v60, v64, v60
v_cndmask_b32_e32 v60, v60, v65, vcc
v_cmp_u_f32_e32 vcc, v61, v61
v_lshrrev_b32_e32 v64, 16, v61
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v61, 0x7fff, v61
v_add_u32_e32 v61, v64, v61
v_cndmask_b32_e32 v61, v61, v65, vcc
v_cmp_u_f32_e32 vcc, v62, v62
v_lshrrev_b32_e32 v64, 16, v62
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v62, 0x7fff, v62
v_add_u32_e32 v62, v64, v62
v_cndmask_b32_e32 v62, v62, v65, vcc
v_cmp_u_f32_e32 vcc, v63, v63
v_lshrrev_b32_e32 v64, 16, v63
v_and_b32_e32 v64, 1, v64
v_add_u32_e32 v63, 0x7fff, v63
v_add_u32_e32 v63, v64, v63
v_cndmask_b32_e32 v63, v63, v65, vcc
v_lshrrev_b32_e32 v60, 16, v60
v_and_b32_e32 v61, 0xffff0000, v61
v_or_b32_e32 v60, v60, v61
v_lshrrev_b32_e32 v62, 16, v62
v_and_b32_e32 v63, 0xffff0000, v63
v_or_b32_e32 v61, v62, v63
global_store_dwordx2 v[117:118], v[60:61], off offset:224 glc slc
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size M128_SAB_BF16_BF16, .L_func_end-M128_SAB_BF16_BF16
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel M128_SAB_BF16_BF16
.amdhsa_group_segment_fixed_size 16384
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 40
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 124
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 16384
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           M128_SAB_BF16_BF16
    .private_segment_fixed_size: 0
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         M128_SAB_BF16_BF16.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     124
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...
.end_amdgpu_metadata
