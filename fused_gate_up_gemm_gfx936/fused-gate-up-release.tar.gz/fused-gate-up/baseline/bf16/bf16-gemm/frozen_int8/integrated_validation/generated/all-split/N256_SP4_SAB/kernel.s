; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.N256_SP4_SAB,#alloc,#execinstr
.protected N256_SP4_SAB
.globl N256_SP4_SAB
.p2align 8
.type N256_SP4_SAB,@function
N256_SP4_SAB:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v208, 63, v0
v_lshlrev_b32_e32 v208, 4, v208
v_lshrrev_b32_e32 v209, 6, v0
v_lshlrev_b32_e32 v211, 4, v0
v_lshlrev_b32_e32 v212, 10, v209
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_lshl_b32 s22, s7, 8
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_lshl_b32 s21, s7, 14
s_mov_b32 s0, s8
s_add_u32 s1, s9, 0x40800000
s_mov_b32 s18, s17
s_mov_b32 s19, s16
s_mov_b32 s26, s20
s_mov_b32 s20, s21
s_mov_b32 s21, s26
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v210, 11, v209
s_add_u32 s10, s10, s21
s_addc_u32 s11, s11, 0
v_add_u32_e32 v210, v210, v208
v_add_u32_e32 v211, s20, v211
v_mov_b32_e32 v219, s11
v_readfirstlane_b32 s26, v212
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[128:131], v210, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[132:135], v210, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s27
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s28
s_add_u32 m0, s26, 12288
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s29
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v211, s19, v211
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
v_mov_b32_e32 v64, 0
v_mov_b32_e32 v65, 0
v_mov_b32_e32 v66, 0
v_mov_b32_e32 v67, 0
v_mov_b32_e32 v68, 0
v_mov_b32_e32 v69, 0
v_mov_b32_e32 v70, 0
v_mov_b32_e32 v71, 0
v_mov_b32_e32 v72, 0
v_mov_b32_e32 v73, 0
v_mov_b32_e32 v74, 0
v_mov_b32_e32 v75, 0
v_mov_b32_e32 v76, 0
v_mov_b32_e32 v77, 0
v_mov_b32_e32 v78, 0
v_mov_b32_e32 v79, 0
v_mov_b32_e32 v80, 0
v_mov_b32_e32 v81, 0
v_mov_b32_e32 v82, 0
v_mov_b32_e32 v83, 0
v_mov_b32_e32 v84, 0
v_mov_b32_e32 v85, 0
v_mov_b32_e32 v86, 0
v_mov_b32_e32 v87, 0
v_mov_b32_e32 v88, 0
v_mov_b32_e32 v89, 0
v_mov_b32_e32 v90, 0
v_mov_b32_e32 v91, 0
v_mov_b32_e32 v92, 0
v_mov_b32_e32 v93, 0
v_mov_b32_e32 v94, 0
v_mov_b32_e32 v95, 0
v_mov_b32_e32 v96, 0
v_mov_b32_e32 v97, 0
v_mov_b32_e32 v98, 0
v_mov_b32_e32 v99, 0
v_mov_b32_e32 v100, 0
v_mov_b32_e32 v101, 0
v_mov_b32_e32 v102, 0
v_mov_b32_e32 v103, 0
v_mov_b32_e32 v104, 0
v_mov_b32_e32 v105, 0
v_mov_b32_e32 v106, 0
v_mov_b32_e32 v107, 0
v_mov_b32_e32 v108, 0
v_mov_b32_e32 v109, 0
v_mov_b32_e32 v110, 0
v_mov_b32_e32 v111, 0
v_mov_b32_e32 v112, 0
v_mov_b32_e32 v113, 0
v_mov_b32_e32 v114, 0
v_mov_b32_e32 v115, 0
v_mov_b32_e32 v116, 0
v_mov_b32_e32 v117, 0
v_mov_b32_e32 v118, 0
v_mov_b32_e32 v119, 0
v_mov_b32_e32 v120, 0
v_mov_b32_e32 v121, 0
v_mov_b32_e32 v122, 0
v_mov_b32_e32 v123, 0
v_mov_b32_e32 v124, 0
v_mov_b32_e32 v125, 0
v_mov_b32_e32 v126, 0
v_mov_b32_e32 v127, 0
s_mov_b32 s24, 40
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
v_add_u32_e32 v217, 0, v208
GEMM_LDS_TO_REG v[144:147], v217, 0
GEMM_LDS_TO_REG v[148:151], v217, 1024
GEMM_LDS_TO_REG v[152:155], v217, 2048
GEMM_LDS_TO_REG v[156:159], v217, 3072
GEMM_W_GLOBAL_SADDR_TO_REG v[136:139], v210, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[140:143], v210, s[10:11], 1024
GEMM_LDS_TO_REG v[160:163], v217, 4096
GEMM_LDS_TO_REG v[164:167], v217, 5120
GEMM_LDS_TO_REG v[168:171], v217, 6144
GEMM_LDS_TO_REG v[172:175], v217, 7168
GEMM_LDS_TO_REG v[176:179], v217, 8192
GEMM_LDS_TO_REG v[180:183], v217, 9216
GEMM_LDS_TO_REG v[184:187], v217, 10240
GEMM_LDS_TO_REG v[188:191], v217, 11264
GEMM_LDS_TO_REG v[192:195], v217, 12288
GEMM_LDS_TO_REG v[196:199], v217, 13312
GEMM_LDS_TO_REG v[200:203], v217, 14336
GEMM_LDS_TO_REG v[204:207], v217, 15360
s_add_u32 m0, s26, 16384
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], 0
s_add_u32 m0, s26, 20480
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s27
s_add_u32 m0, s26, 24576
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s28
s_add_u32 m0, s26, 28672
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s29
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v211, s19, v211
GEMM_WAIT_LGKM 15
GEMM_MMA_I8 v[0:3], v[144:145], v[128:129], v[0:3]
GEMM_MMA_I8 v[4:7], v[144:145], v[132:133], v[4:7]
GEMM_MMA_I8 v[0:3], v[146:147], v[130:131], v[0:3]
GEMM_MMA_I8 v[4:7], v[146:147], v[134:135], v[4:7]
GEMM_WAIT_LGKM 14
GEMM_MMA_I8 v[8:11], v[148:149], v[128:129], v[8:11]
GEMM_MMA_I8 v[12:15], v[148:149], v[132:133], v[12:15]
GEMM_MMA_I8 v[8:11], v[150:151], v[130:131], v[8:11]
GEMM_MMA_I8 v[12:15], v[150:151], v[134:135], v[12:15]
GEMM_WAIT_LGKM 13
GEMM_MMA_I8 v[16:19], v[152:153], v[128:129], v[16:19]
GEMM_MMA_I8 v[20:23], v[152:153], v[132:133], v[20:23]
GEMM_MMA_I8 v[16:19], v[154:155], v[130:131], v[16:19]
GEMM_MMA_I8 v[20:23], v[154:155], v[134:135], v[20:23]
GEMM_WAIT_LGKM 12
GEMM_MMA_I8 v[24:27], v[156:157], v[128:129], v[24:27]
GEMM_MMA_I8 v[28:31], v[156:157], v[132:133], v[28:31]
GEMM_MMA_I8 v[24:27], v[158:159], v[130:131], v[24:27]
GEMM_MMA_I8 v[28:31], v[158:159], v[134:135], v[28:31]
GEMM_WAIT_LGKM 11
GEMM_MMA_I8 v[32:35], v[160:161], v[128:129], v[32:35]
GEMM_MMA_I8 v[36:39], v[160:161], v[132:133], v[36:39]
GEMM_MMA_I8 v[32:35], v[162:163], v[130:131], v[32:35]
GEMM_MMA_I8 v[36:39], v[162:163], v[134:135], v[36:39]
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[40:43], v[164:165], v[128:129], v[40:43]
GEMM_MMA_I8 v[44:47], v[164:165], v[132:133], v[44:47]
GEMM_MMA_I8 v[40:43], v[166:167], v[130:131], v[40:43]
GEMM_MMA_I8 v[44:47], v[166:167], v[134:135], v[44:47]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[48:51], v[168:169], v[128:129], v[48:51]
GEMM_MMA_I8 v[52:55], v[168:169], v[132:133], v[52:55]
GEMM_MMA_I8 v[48:51], v[170:171], v[130:131], v[48:51]
GEMM_MMA_I8 v[52:55], v[170:171], v[134:135], v[52:55]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[56:59], v[172:173], v[128:129], v[56:59]
GEMM_MMA_I8 v[60:63], v[172:173], v[132:133], v[60:63]
GEMM_MMA_I8 v[56:59], v[174:175], v[130:131], v[56:59]
GEMM_MMA_I8 v[60:63], v[174:175], v[134:135], v[60:63]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[64:67], v[176:177], v[128:129], v[64:67]
GEMM_MMA_I8 v[68:71], v[176:177], v[132:133], v[68:71]
GEMM_MMA_I8 v[64:67], v[178:179], v[130:131], v[64:67]
GEMM_MMA_I8 v[68:71], v[178:179], v[134:135], v[68:71]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[72:75], v[180:181], v[128:129], v[72:75]
GEMM_MMA_I8 v[76:79], v[180:181], v[132:133], v[76:79]
GEMM_MMA_I8 v[72:75], v[182:183], v[130:131], v[72:75]
GEMM_MMA_I8 v[76:79], v[182:183], v[134:135], v[76:79]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[80:83], v[184:185], v[128:129], v[80:83]
GEMM_MMA_I8 v[84:87], v[184:185], v[132:133], v[84:87]
GEMM_MMA_I8 v[80:83], v[186:187], v[130:131], v[80:83]
GEMM_MMA_I8 v[84:87], v[186:187], v[134:135], v[84:87]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[88:91], v[188:189], v[128:129], v[88:91]
GEMM_MMA_I8 v[92:95], v[188:189], v[132:133], v[92:95]
GEMM_MMA_I8 v[88:91], v[190:191], v[130:131], v[88:91]
GEMM_MMA_I8 v[92:95], v[190:191], v[134:135], v[92:95]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[96:99], v[192:193], v[128:129], v[96:99]
GEMM_MMA_I8 v[100:103], v[192:193], v[132:133], v[100:103]
GEMM_MMA_I8 v[96:99], v[194:195], v[130:131], v[96:99]
GEMM_MMA_I8 v[100:103], v[194:195], v[134:135], v[100:103]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[104:107], v[196:197], v[128:129], v[104:107]
GEMM_MMA_I8 v[108:111], v[196:197], v[132:133], v[108:111]
GEMM_MMA_I8 v[104:107], v[198:199], v[130:131], v[104:107]
GEMM_MMA_I8 v[108:111], v[198:199], v[134:135], v[108:111]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[112:115], v[200:201], v[128:129], v[112:115]
GEMM_MMA_I8 v[116:119], v[200:201], v[132:133], v[116:119]
GEMM_MMA_I8 v[112:115], v[202:203], v[130:131], v[112:115]
GEMM_MMA_I8 v[116:119], v[202:203], v[134:135], v[116:119]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[120:123], v[204:205], v[128:129], v[120:123]
GEMM_MMA_I8 v[124:127], v[204:205], v[132:133], v[124:127]
GEMM_MMA_I8 v[120:123], v[206:207], v[130:131], v[120:123]
GEMM_MMA_I8 v[124:127], v[206:207], v[134:135], v[124:127]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
v_add_u32_e32 v217, 16384, v208
GEMM_LDS_TO_REG v[144:147], v217, 0
GEMM_LDS_TO_REG v[148:151], v217, 1024
GEMM_LDS_TO_REG v[152:155], v217, 2048
GEMM_LDS_TO_REG v[156:159], v217, 3072
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_P
GEMM_W_GLOBAL_SADDR_TO_REG v[128:131], v210, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[132:135], v210, s[10:11], 1024
.L_custom_skip_P:
GEMM_LDS_TO_REG v[160:163], v217, 4096
GEMM_LDS_TO_REG v[164:167], v217, 5120
GEMM_LDS_TO_REG v[168:171], v217, 6144
GEMM_LDS_TO_REG v[172:175], v217, 7168
GEMM_LDS_TO_REG v[176:179], v217, 8192
GEMM_LDS_TO_REG v[180:183], v217, 9216
GEMM_LDS_TO_REG v[184:187], v217, 10240
GEMM_LDS_TO_REG v[188:191], v217, 11264
GEMM_LDS_TO_REG v[192:195], v217, 12288
GEMM_LDS_TO_REG v[196:199], v217, 13312
GEMM_LDS_TO_REG v[200:203], v217, 14336
GEMM_LDS_TO_REG v[204:207], v217, 15360
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_S
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s27
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s28
s_add_u32 m0, s26, 12288
GEMM_X_GLOBAL_TO_LDS v211, s[0:3], s29
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v211, s19, v211
.L_custom_skip_S:
GEMM_WAIT_LGKM 15
GEMM_MMA_I8 v[0:3], v[144:145], v[136:137], v[0:3]
GEMM_MMA_I8 v[4:7], v[144:145], v[140:141], v[4:7]
GEMM_MMA_I8 v[0:3], v[146:147], v[138:139], v[0:3]
GEMM_MMA_I8 v[4:7], v[146:147], v[142:143], v[4:7]
GEMM_WAIT_LGKM 14
GEMM_MMA_I8 v[8:11], v[148:149], v[136:137], v[8:11]
GEMM_MMA_I8 v[12:15], v[148:149], v[140:141], v[12:15]
GEMM_MMA_I8 v[8:11], v[150:151], v[138:139], v[8:11]
GEMM_MMA_I8 v[12:15], v[150:151], v[142:143], v[12:15]
GEMM_WAIT_LGKM 13
GEMM_MMA_I8 v[16:19], v[152:153], v[136:137], v[16:19]
GEMM_MMA_I8 v[20:23], v[152:153], v[140:141], v[20:23]
GEMM_MMA_I8 v[16:19], v[154:155], v[138:139], v[16:19]
GEMM_MMA_I8 v[20:23], v[154:155], v[142:143], v[20:23]
GEMM_WAIT_LGKM 12
GEMM_MMA_I8 v[24:27], v[156:157], v[136:137], v[24:27]
GEMM_MMA_I8 v[28:31], v[156:157], v[140:141], v[28:31]
GEMM_MMA_I8 v[24:27], v[158:159], v[138:139], v[24:27]
GEMM_MMA_I8 v[28:31], v[158:159], v[142:143], v[28:31]
GEMM_WAIT_LGKM 11
GEMM_MMA_I8 v[32:35], v[160:161], v[136:137], v[32:35]
GEMM_MMA_I8 v[36:39], v[160:161], v[140:141], v[36:39]
GEMM_MMA_I8 v[32:35], v[162:163], v[138:139], v[32:35]
GEMM_MMA_I8 v[36:39], v[162:163], v[142:143], v[36:39]
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[40:43], v[164:165], v[136:137], v[40:43]
GEMM_MMA_I8 v[44:47], v[164:165], v[140:141], v[44:47]
GEMM_MMA_I8 v[40:43], v[166:167], v[138:139], v[40:43]
GEMM_MMA_I8 v[44:47], v[166:167], v[142:143], v[44:47]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[48:51], v[168:169], v[136:137], v[48:51]
GEMM_MMA_I8 v[52:55], v[168:169], v[140:141], v[52:55]
GEMM_MMA_I8 v[48:51], v[170:171], v[138:139], v[48:51]
GEMM_MMA_I8 v[52:55], v[170:171], v[142:143], v[52:55]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[56:59], v[172:173], v[136:137], v[56:59]
GEMM_MMA_I8 v[60:63], v[172:173], v[140:141], v[60:63]
GEMM_MMA_I8 v[56:59], v[174:175], v[138:139], v[56:59]
GEMM_MMA_I8 v[60:63], v[174:175], v[142:143], v[60:63]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[64:67], v[176:177], v[136:137], v[64:67]
GEMM_MMA_I8 v[68:71], v[176:177], v[140:141], v[68:71]
GEMM_MMA_I8 v[64:67], v[178:179], v[138:139], v[64:67]
GEMM_MMA_I8 v[68:71], v[178:179], v[142:143], v[68:71]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[72:75], v[180:181], v[136:137], v[72:75]
GEMM_MMA_I8 v[76:79], v[180:181], v[140:141], v[76:79]
GEMM_MMA_I8 v[72:75], v[182:183], v[138:139], v[72:75]
GEMM_MMA_I8 v[76:79], v[182:183], v[142:143], v[76:79]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[80:83], v[184:185], v[136:137], v[80:83]
GEMM_MMA_I8 v[84:87], v[184:185], v[140:141], v[84:87]
GEMM_MMA_I8 v[80:83], v[186:187], v[138:139], v[80:83]
GEMM_MMA_I8 v[84:87], v[186:187], v[142:143], v[84:87]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[88:91], v[188:189], v[136:137], v[88:91]
GEMM_MMA_I8 v[92:95], v[188:189], v[140:141], v[92:95]
GEMM_MMA_I8 v[88:91], v[190:191], v[138:139], v[88:91]
GEMM_MMA_I8 v[92:95], v[190:191], v[142:143], v[92:95]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[96:99], v[192:193], v[136:137], v[96:99]
GEMM_MMA_I8 v[100:103], v[192:193], v[140:141], v[100:103]
GEMM_MMA_I8 v[96:99], v[194:195], v[138:139], v[96:99]
GEMM_MMA_I8 v[100:103], v[194:195], v[142:143], v[100:103]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[104:107], v[196:197], v[136:137], v[104:107]
GEMM_MMA_I8 v[108:111], v[196:197], v[140:141], v[108:111]
GEMM_MMA_I8 v[104:107], v[198:199], v[138:139], v[104:107]
GEMM_MMA_I8 v[108:111], v[198:199], v[142:143], v[108:111]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[112:115], v[200:201], v[136:137], v[112:115]
GEMM_MMA_I8 v[116:119], v[200:201], v[140:141], v[116:119]
GEMM_MMA_I8 v[112:115], v[202:203], v[138:139], v[112:115]
GEMM_MMA_I8 v[116:119], v[202:203], v[142:143], v[116:119]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[120:123], v[204:205], v[136:137], v[120:123]
GEMM_MMA_I8 v[124:127], v[204:205], v[140:141], v[124:127]
GEMM_MMA_I8 v[120:123], v[206:207], v[138:139], v[120:123]
GEMM_MMA_I8 v[124:127], v[206:207], v[142:143], v[124:127]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
GEMM_WAIT_VM 0
v_mov_b32_e32 v219, s13
v_lshrrev_b32_e32 v210, 4, v208
v_and_b32_e32 v210, 15, v210
v_lshrrev_b32_e32 v211, 8, v208
v_lshlrev_b32_e32 v211, 4, v211
v_lshlrev_b32_e32 v212, 5, v209
v_lshlrev_b32_e32 v212, 2, v212
v_add_u32_e32 v211, v212, v211
v_add_u32_e32 v210, s22, v210
v_add_u32_e32 v211, s23, v211
v_add_u32_e32 v215, 0, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[0:3], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[4:7], 64
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 16, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[8:11], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[12:15], 64
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 32, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_2
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[16:19], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[20:23], 64
.L_store_skip_2:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 48, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_3
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[24:27], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[28:31], 64
.L_store_skip_3:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 64, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_4
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[32:35], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[36:39], 64
.L_store_skip_4:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 80, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_5
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[40:43], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[44:47], 64
.L_store_skip_5:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 96, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_6
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[48:51], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[52:55], 64
.L_store_skip_6:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 112, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_7
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[56:59], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[60:63], 64
.L_store_skip_7:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 128, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_8
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[64:67], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[68:71], 64
.L_store_skip_8:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 144, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_9
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[72:75], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[76:79], 64
.L_store_skip_9:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 160, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_10
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[80:83], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[84:87], 64
.L_store_skip_10:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 176, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_11
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[88:91], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[92:95], 64
.L_store_skip_11:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 192, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_12
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[96:99], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[100:103], 64
.L_store_skip_12:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 208, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_13
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[104:107], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[108:111], 64
.L_store_skip_13:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 224, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_14
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[112:115], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[116:119], 64
.L_store_skip_14:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v215, 240, v210
v_cmp_gt_u32_e32 vcc, s14, v215
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_15
v_mul_u32_u24_e32 v216, 0x11000, v215
v_add_u32_e32 v216, v211, v216
v_add_co_u32_e32 v213, vcc, s12, v216
v_addc_co_u32_e32 v214, vcc, 0, v219, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[120:123], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[213:214], v[124:127], 64
.L_store_skip_15:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size N256_SP4_SAB, .L_func_end-N256_SP4_SAB
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel N256_SP4_SAB
.amdhsa_group_segment_fixed_size 32768
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 40
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 220
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 32768
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           N256_SP4_SAB
    .private_segment_fixed_size: 0
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         N256_SP4_SAB.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     220
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...
.end_amdgpu_metadata
