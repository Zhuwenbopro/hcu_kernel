拆分预取已集成到模块化汇编生成器，按 M 更新最优选择

已更新 /home/zmoe/src/gemm_asm/tile_generator.py 和 tile_schedule_policy.json。新增 split_private_then_shared 顺序、--M 实际 M 选择入口和 select_for_m Python API。原先 --schedule-policy 仅按 tile 读取默认排法；现在 --M 精确读取 best_by_M，重复传入多个 M 时按完整排法去重生成 kernel，并写 selection_by_M.json。

只替换 M193–256；M129–192 的原策略条目保持原 JSON 值，M1–128 沿用此前 E030/E047 路由。其他无收益 tile 的默认排法保持不变。N17408、K5120、MP256 的 tile 策略不外推到其他 shape；小 M 不由该 MP256 策略重新分流。

沿 N 分工的顺序为：当前 X 先发 k 条 LDS→REG，随后发下一 K64 的 W→私有寄存器，再发剩余当前 X LDS 读，最后发下一 K64 的 X→LDS 并执行当前 MMAC。当前槽先经过 ready 等待和 CTA barrier。末段分别跳过两类下一段预取，当前 X 的两段读取均保留。沿 M 时私有/共享操作数对称。

本轮用已集成生成器新编译的实际路由进行独立复测，固定核心1500 MHz（所有采样1499）、显存1800 MHz。三组全新随机输入，各七轮，每图72组独立随机权重；先取每 seed 中位数，再取三 seed 中位数。新旧路由按同一输入、地址和同轮随机顺序比较；M≤192 复用同一函数的计时，避免将噪声画成收益。此轮不重新搜索 k。

| 实际 M | 原路由平均 µs | 更新后平均 µs | 平均节省 µs | 平均下降 |
| --- | --- | --- | --- | --- |
| 1–128 | 71.402 | 71.402 | 0.000 | 0.00% |
| 129–192 | 78.149 | 78.149 | 0.000 | 0.00% |
| 193–208 | 87.452 | 83.477 | 3.975 | 4.55% |
| 209–224 | 90.049 | 85.911 | 4.139 | 4.60% |
| 225–240 | 93.627 | 91.829 | 1.799 | 1.92% |
| 241–256 | 94.917 | 93.182 | 1.735 | 1.83% |

| 实际 M 范围 | 方向 / CTA tile | 逐 M 选择的 k |
| --- | --- | --- |
| 193–208 | 沿 N / 208×128 | 5或7 |
| 209–224 | 沿 N / 224×128 | 9或10 |
| 225–240 | 沿 N / 240×128 | 12 |
| 241–256 | 沿 N / 256×128 | 11 |

192→193 跳变为 5.9400→1.9689 µs，缩小 66.85%。全部64个被替换的 M 在每个新 seed 上均有正收益，中位数改善至少0.2 µs。

HBM/L2 图沿用此前定义：

- HBM 有效输入首次读取 U=(M+N)×K，以1.35×10^12 B/s归一化。
- 软件请求 Qx=grid_N×covered_M×K，Qw=grid_M×N×K。
- 严格重复读取 R=Qx+Qw−(covered_M+N)×K，以4.5×10^12 B/s归一化；首次读取的填充 X 单列。
- L2 全部输入请求按(Qx+Qw)/t归一化；INT32 输出写入单列，不计入主曲线。

这些是软件字节模型除以测得时间，不是硬件计数器测得的物理 HBM/L2 链路占用率。当前新旧选择的逐 M 输入请求字节数完全一致；所有选中路由 grid_M=1，W无跨CTA重复，严格重复来自X跨N方向CTA的读取。

| M | 旧→新 µs | HBM 旧→新 | L2重复 旧→新 | L2全请求 旧→新 |
| --- | --- | --- | --- | --- |
| 1 | 66.71→66.71 | 98.98%→98.98% | 14.79%→14.79% | 44.54%→44.54% |
| 128 | 74.63→74.63 | 89.12%→89.12% | 26.35%→26.35% | 53.08%→53.08% |
| 129 | 75.09→75.09 | 88.57%→88.57% | 29.46%→29.46% | 56.05%→56.05% |
| 192 | 81.03→81.03 | 82.37%→82.37% | 36.39%→36.39% | 61.11%→61.11% |
| 193 | 86.97→83.00 | 76.75%→80.42% | 36.73%→38.49% | 59.78%→62.64% |
| 208 | 87.92→83.95 | 75.99%→79.58% | 36.34%→38.06% | 59.13%→61.93% |
| 224 | 90.61→86.34 | 73.80%→77.45% | 37.97%→39.85% | 60.11%→63.09% |
| 240 | 94.12→92.26 | 71.11%→72.55% | 39.17%→39.96% | 60.50%→61.72% |
| 256 | 95.34→93.53 | 70.27%→71.62% | 41.24%→42.04% | 62.32%→63.53% |

验证结果：

- 624 个旧地址/调度组合的汇编源码与修改前逐字一致。
- 576 个新拆分预取组合与独立实验生成规则一致；其中153个已验证候选与集成版的GPU函数指令字节相同。
- 全部128个大M选择入口核对通过；生成策略中的10个唯一函数，并逐字节核对相应实验/原实现；发布后命令行再次构建5个代表函数，与本轮GPU验收模块逐字节一致。
- 错误 M、错误资源/family、重复 M、手工覆盖冲突等11个非法请求均拒绝。
- 正确性池检查6912次，捕获后检查960次，计时后检查6720次，CPU INT64点积核对912点。每次检查全部有效输出、无效输出行及前后guard。
- 所有894个时钟采样均为manual、1499/1800 MHz；目标GPU开始/结束时无其他owner。

所有无收益区间的实现保持原值。common_gfx936.inc、E023/E047源文件、current.json及已登记二进制保持原哈希，模型服务未切换。新的逐M策略可以由--M/select_for_m实际读取，不是只追加实验结果。原始对照、源代码备份及source.diff均保留。

使用示例：

~~~sh
python3 /home/zmoe/src/gemm_asm/tile_generator.py --M 193 --check-only
python3 /home/zmoe/src/gemm_asm/tile_generator.py --M 193 --M 194 --M 256 --output-dir /home/metic/my-current-tiles
~~~

主要产物：

- /home/metic/gemm-split-prefetch-integrated-locked-20261114/bandwidth-M1-256.png：全范围三联图：HBM/L2利用率模型、字节账、新旧延时
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/before-after-M128-256.png：大M的新旧延时及三种带宽模型对比
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/bandwidth-M1-256.csv：更新后M1–256全部模型数值和形状信息
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/before-bandwidth-M1-256.csv：同轮原路由模型值
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/before-after-M1-256.csv：逐M新旧函数、延时、收益和每seed计时
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/RESULT.json：完整数值和逐轮原始时间
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/integration-proof.json：源码/函数字节/路由等价证明
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/source.diff：生成器、策略和文档修改
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/published.json：发布文件的新旧哈希
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/generated/policy/selection_by_M.json：实际生成的逐M函数选择清单
- /home/metic/gemm-split-prefetch-integrated-locked-20261114/timing-sequence-status.json：目标GPU时钟和所有权采样
