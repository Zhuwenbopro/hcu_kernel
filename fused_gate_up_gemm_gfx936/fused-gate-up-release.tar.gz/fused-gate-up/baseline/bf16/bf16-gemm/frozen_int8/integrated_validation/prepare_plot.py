from pathlib import Path
import re
I=Path(__file__).resolve().parent
T=Path('/home/metic/gemm-hbm-l2-util-locked-20261114')
s=(T/'plot.py').read_text()
s=s.replace("str(R/'fonts/","str(Path('/home/metic/gemm-hbm-l2-util-locked-20261114')/'fonts/")
s=s.replace("\u5f53\u524d\u65b9\u6848\uff1aHBM / L2 \u8f93\u5165\u8bfb\u53d6\u5e26\u5bbd\u5229\u7528\u7387\uff08\u6a21\u578b\uff09","\u62c6\u5206\u9884\u53d6\u63a5\u5165\u540e\uff1aHBM / L2 \u8f93\u5165\u8bfb\u53d6\u5e26\u5bbd\u5229\u7528\u7387\uff08\u6a21\u578b\uff09")
s=s.replace("c.plot(x,arr('latency_us'),color=ink,lw=1.7)","c.plot(x,[r['latency_us'] for r in j['before_rows']],color='#9da6b3',lw=1.4,ls='--',label='\u66f4\u65b0\u524d')\nc.plot(x,arr('latency_us'),color=ink,lw=1.8,label='\u66f4\u65b0\u540e')")
s=s.replace("\u540c\u8f6e\u9501\u9891\u590d\u6d4b\uff1aM\u2264128 \u4f7f\u7528\u65e2\u6709\u5019\u9009\uff0cM\u2265129 \u4f7f\u7528\u672c\u8f6e\u4f18\u5316\u540e\u7684 tile","\u540c\u8f6e\u9501\u9891\u590d\u6d4b\uff1aM\u2264192 \u4fdd\u7559\u539f\u5b9e\u73b0\uff0cM\u2265193 \u542f\u7528\u62c6\u5206\u9884\u53d6")
s=s.replace("jump=d[192]['latency_us']-d[191]['latency_us']","c.legend(loc='upper left',frameon=False,ncol=2,fontsize=9)\njump=d[192]['latency_us']-d[191]['latency_us']\noldjump=j['before_rows'][192]['latency_us']-j['before_rows'][191]['latency_us']")
s=re.sub(r"c.annotate\(f'192.*?\n(?=jump128=)","c.annotate(f'192 \u2192 193\uff1a+{oldjump:.2f} \u2192 +{jump:.2f} \u00b5s',xy=(193,d[192]['latency_us']),xytext=(146,96),fontsize=9,color='#a34d3b',arrowprops=dict(arrowstyle='->',color='#a34d3b',lw=1.0))\n",s,flags=re.S)
lines=[]
for line in s.splitlines():
 if line.startswith('a.text(154,8'):
  line="a.text(154,8,f\"M193\uff1aHBM {j['before_rows'][192]['HBM_input_util_pct']:.1f}% \u2192 {d[192]['HBM_input_util_pct']:.1f}%\\nL2 \u5168\u8bf7\u6c42 {j['before_rows'][192]['L2_all_input_util_pct']:.1f}% \u2192 {d[192]['L2_all_input_util_pct']:.1f}%\",fontsize=9,color='#546272',ha='left',bbox=dict(boxstyle='round,pad=.4',facecolor='#f6f8fa',edgecolor='none'))"
 if line.startswith("fig.text(.075,.025"):
  line="fig.text(.075,.025,'\u6bcf\u70b9\uff1a3 seed \u00d7 7 \u8f6e \u00d7 \u6bcf\u56fe 72 \u7ec4\u72ec\u7acb\u6743\u91cd\uff1b\u65b0\u65e7\u540c\u8f6e\u6d4b\u91cf\u3002M\u2264192 \u6cbf\u7528\u539f\u5b9e\u73b0\uff0c\u6570\u636e\u672a\u5e73\u6ed1\u3001\u672a\u63d2\u503c\u3002TB/s = 10\u00b9\u00b2 B/s\u3002',fontsize=8.8,color='#586574')"
 lines.append(line)
s='\n'.join(lines)+'\n'
s+=r'''
# Separate zoomed comparison keeps all three modeled bandwidth definitions.
old=j['before_rows']
def oldarr(k):return np.array([r[k] for r in old],dtype=float)
fig2,aa=plt.subplots(2,1,figsize=(13.5,7.4),sharex=True,gridspec_kw={'height_ratios':[1,1.1]})
fig2.subplots_adjust(left=.075,right=.975,top=.87,bottom=.13,hspace=.23)
fig2.suptitle('\u62c6\u5206\u9884\u53d6\uff1a\u6309 M \u66f4\u65b0\u524d\u540e\uff08\u540c\u8f6e\u9501\u9891\u590d\u6d4b\uff09',y=.985,fontsize=18,fontweight='bold',color=ink)
fig2.text(.5,.932,'N = 17408  \u00b7  K = 5120  \u00b7  \u6838\u5fc3 1499 MHz / \u663e\u5b58 1800 MHz  \u00b7  M\u2264192 \u4fdd\u7559\u539f\u5b9e\u73b0',ha='center',fontsize=10.5,color='#586574')
a=aa[0]
a.plot(x,oldarr('latency_us'),color='#7c8795',ls='--',lw=1.8,label='\u66f4\u65b0\u524d\u539f\u8def\u7531')
a.plot(x,arr('latency_us'),color=blue,lw=2.0,label='\u66f4\u65b0\u540e\u8def\u7531')
a.set_ylim(73,98);a.set_yticks([75,80,85,90,95]);a.set_ylabel('kernel \u5ef6\u65f6 / \u00b5s')
a.legend(loc='upper left',ncol=2,frameon=False,fontsize=9.5)
a.annotate(f"M193\uff1a{old[192]['latency_us']:.2f} \u2192 {d[192]['latency_us']:.2f} \u00b5s",xy=(193,d[192]['latency_us']),xytext=(148,94),color=blue,fontsize=10,arrowprops=dict(arrowstyle='->',color=blue))
a.text(252,75.4,f"192\u2192193 \u8df3\u53d8\uff1a{j['jump_192_193']['before_us']:.2f} \u2192 {j['jump_192_193']['after_us']:.2f} \u00b5s",ha='right',fontsize=10,color=ink)
b=aa[1]
for key,color,label in [('HBM_input_util_pct',blue,'HBM'),('L2_all_input_util_pct',orange,'L2 \u5168\u8bf7\u6c42'),('L2_repeat_util_pct',green,'L2 \u91cd\u590d')]:
 b.plot(x,oldarr(key),color=color,alpha=.45,lw=1.4,ls='--',label=label+'\uff1a\u66f4\u65b0\u524d')
 b.plot(x,arr(key),color=color,lw=1.9,label=label+'\uff1a\u66f4\u65b0\u540e')
b.set_ylim(24,94);b.set_yticks([30,40,50,60,70,80,90]);b.set_ylabel('\u5229\u7528\u7387\u6a21\u578b / %');b.set_xlabel('M')
b.legend(loc='lower right',bbox_to_anchor=(.995,.025),ncol=3,frameon=False,fontsize=8.5,columnspacing=1.4)
for a in aa:
 a.set_xlim(128,256);a.set_xticks([128,144,160,176,192,208,224,240,256]);a.grid(axis='y',color='#dce1e7',lw=.65);a.set_axisbelow(True);a.tick_params(colors='#52606f')
 for boundary in [144.5,160.5,176.5,192.5,208.5,224.5,240.5]:
  a.axvline(boundary,color='#d2d8df' if boundary!=192.5 else '#b58a80',lw=.65,ls='--',zorder=0)
fig2.text(.075,.057,'HBM \u4e0a\u9650 1.35 TB/s\uff0cL2 \u4e0a\u9650 4.5 TB/s\uff1b\u5747\u6309\u8f6f\u4ef6\u8f93\u5165\u8bfb\u53d6\u5b57\u8282 \u00f7 \u5b9e\u6d4b\u5ef6\u65f6\u6298\u7b97\uff0c\u975e\u786c\u4ef6\u8ba1\u6570\u5668\u5360\u7528\u7387\u3002',fontsize=9,color='#586574')
fig2.text(.075,.027,'\u672c\u6b21\u66f4\u65b0\u524d\u540e\u8f93\u5165\u8bf7\u6c42\u5b57\u8282\u6570\u76f8\u540c\uff1b\u53ea\u66ff\u6362 M193\u2013256 \u7684\u6709\u6536\u76ca\u65b9\u6848\u3002INT32 \u8f93\u51fa\u5199\u5165\u4e0d\u8ba1\u5165\u5e26\u5bbd\u4e3b\u66f2\u7ebf\u3002',fontsize=9,color='#586574')
fig2.savefig(R/'before-after-M128-256.png',dpi=160)
fig2.savefig(R/'before-after-M128-256.svg')
plt.close(fig2)
print('COMPARISON_PLOTTED')
'''
(I/'plot.py').write_text(s)
print('PLOT_SCRIPT_READY',len(s))
