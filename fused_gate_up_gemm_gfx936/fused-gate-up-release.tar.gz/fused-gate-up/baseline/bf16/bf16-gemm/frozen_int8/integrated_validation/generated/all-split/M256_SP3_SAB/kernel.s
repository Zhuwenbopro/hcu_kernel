; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.M256_SP3_SAB,#alloc,#execinstr
.protected M256_SP3_SAB
.globl M256_SP3_SAB
.p2align 8
.type M256_SP3_SAB,@function
M256_SP3_SAB:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v192, 63, v0
v_lshlrev_b32_e32 v192, 4, v192
v_lshrrev_b32_e32 v193, 6, v0
v_lshlrev_b32_e32 v195, 4, v0
v_lshlrev_b32_e32 v196, 10, v193
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_lshl_b32 s22, s7, 8
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_lshl_b32 s21, s7, 14
s_mov_b32 s0, s10
s_add_u32 s1, s11, 0x40800000
s_mov_b32 s18, s16
s_mov_b32 s19, s17
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v194, 12, v193
s_add_u32 s8, s8, s21
s_addc_u32 s9, s9, 0
v_add_u32_e32 v194, v194, v192
v_add_u32_e32 v195, s20, v195
v_mov_b32_e32 v203, s9
v_readfirstlane_b32 s26, v196
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_X_GLOBAL_SADDR_TO_REG v[128:131], v194, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[132:135], v194, s[8:9], 1024
GEMM_X_GLOBAL_SADDR_TO_REG v[136:139], v194, s[8:9], 2048
GEMM_X_GLOBAL_SADDR_TO_REG v[140:143], v194, s[8:9], 3072
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v195, s19, v195
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
v_mov_b32_e32 v64, 0
v_mov_b32_e32 v65, 0
v_mov_b32_e32 v66, 0
v_mov_b32_e32 v67, 0
v_mov_b32_e32 v68, 0
v_mov_b32_e32 v69, 0
v_mov_b32_e32 v70, 0
v_mov_b32_e32 v71, 0
v_mov_b32_e32 v72, 0
v_mov_b32_e32 v73, 0
v_mov_b32_e32 v74, 0
v_mov_b32_e32 v75, 0
v_mov_b32_e32 v76, 0
v_mov_b32_e32 v77, 0
v_mov_b32_e32 v78, 0
v_mov_b32_e32 v79, 0
v_mov_b32_e32 v80, 0
v_mov_b32_e32 v81, 0
v_mov_b32_e32 v82, 0
v_mov_b32_e32 v83, 0
v_mov_b32_e32 v84, 0
v_mov_b32_e32 v85, 0
v_mov_b32_e32 v86, 0
v_mov_b32_e32 v87, 0
v_mov_b32_e32 v88, 0
v_mov_b32_e32 v89, 0
v_mov_b32_e32 v90, 0
v_mov_b32_e32 v91, 0
v_mov_b32_e32 v92, 0
v_mov_b32_e32 v93, 0
v_mov_b32_e32 v94, 0
v_mov_b32_e32 v95, 0
v_mov_b32_e32 v96, 0
v_mov_b32_e32 v97, 0
v_mov_b32_e32 v98, 0
v_mov_b32_e32 v99, 0
v_mov_b32_e32 v100, 0
v_mov_b32_e32 v101, 0
v_mov_b32_e32 v102, 0
v_mov_b32_e32 v103, 0
v_mov_b32_e32 v104, 0
v_mov_b32_e32 v105, 0
v_mov_b32_e32 v106, 0
v_mov_b32_e32 v107, 0
v_mov_b32_e32 v108, 0
v_mov_b32_e32 v109, 0
v_mov_b32_e32 v110, 0
v_mov_b32_e32 v111, 0
v_mov_b32_e32 v112, 0
v_mov_b32_e32 v113, 0
v_mov_b32_e32 v114, 0
v_mov_b32_e32 v115, 0
v_mov_b32_e32 v116, 0
v_mov_b32_e32 v117, 0
v_mov_b32_e32 v118, 0
v_mov_b32_e32 v119, 0
v_mov_b32_e32 v120, 0
v_mov_b32_e32 v121, 0
v_mov_b32_e32 v122, 0
v_mov_b32_e32 v123, 0
v_mov_b32_e32 v124, 0
v_mov_b32_e32 v125, 0
v_mov_b32_e32 v126, 0
v_mov_b32_e32 v127, 0
s_mov_b32 s24, 40
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
v_add_u32_e32 v201, 0, v192
GEMM_LDS_TO_REG v[160:163], v201, 0
GEMM_LDS_TO_REG v[164:167], v201, 1024
GEMM_LDS_TO_REG v[168:171], v201, 2048
GEMM_X_GLOBAL_SADDR_TO_REG v[144:147], v194, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[148:151], v194, s[8:9], 1024
GEMM_X_GLOBAL_SADDR_TO_REG v[152:155], v194, s[8:9], 2048
GEMM_X_GLOBAL_SADDR_TO_REG v[156:159], v194, s[8:9], 3072
GEMM_LDS_TO_REG v[172:175], v201, 3072
GEMM_LDS_TO_REG v[176:179], v201, 4096
GEMM_LDS_TO_REG v[180:183], v201, 5120
GEMM_LDS_TO_REG v[184:187], v201, 6144
GEMM_LDS_TO_REG v[188:191], v201, 7168
s_add_u32 m0, s26, 8192
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], 0
s_add_u32 m0, s26, 12288
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v195, s19, v195
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[0:3], v[128:129], v[160:161], v[0:3]
GEMM_MMA_I8 v[4:7], v[132:133], v[160:161], v[4:7]
GEMM_MMA_I8 v[8:11], v[136:137], v[160:161], v[8:11]
GEMM_MMA_I8 v[12:15], v[140:141], v[160:161], v[12:15]
GEMM_MMA_I8 v[0:3], v[130:131], v[162:163], v[0:3]
GEMM_MMA_I8 v[4:7], v[134:135], v[162:163], v[4:7]
GEMM_MMA_I8 v[8:11], v[138:139], v[162:163], v[8:11]
GEMM_MMA_I8 v[12:15], v[142:143], v[162:163], v[12:15]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[16:19], v[128:129], v[164:165], v[16:19]
GEMM_MMA_I8 v[20:23], v[132:133], v[164:165], v[20:23]
GEMM_MMA_I8 v[24:27], v[136:137], v[164:165], v[24:27]
GEMM_MMA_I8 v[28:31], v[140:141], v[164:165], v[28:31]
GEMM_MMA_I8 v[16:19], v[130:131], v[166:167], v[16:19]
GEMM_MMA_I8 v[20:23], v[134:135], v[166:167], v[20:23]
GEMM_MMA_I8 v[24:27], v[138:139], v[166:167], v[24:27]
GEMM_MMA_I8 v[28:31], v[142:143], v[166:167], v[28:31]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[32:35], v[128:129], v[168:169], v[32:35]
GEMM_MMA_I8 v[36:39], v[132:133], v[168:169], v[36:39]
GEMM_MMA_I8 v[40:43], v[136:137], v[168:169], v[40:43]
GEMM_MMA_I8 v[44:47], v[140:141], v[168:169], v[44:47]
GEMM_MMA_I8 v[32:35], v[130:131], v[170:171], v[32:35]
GEMM_MMA_I8 v[36:39], v[134:135], v[170:171], v[36:39]
GEMM_MMA_I8 v[40:43], v[138:139], v[170:171], v[40:43]
GEMM_MMA_I8 v[44:47], v[142:143], v[170:171], v[44:47]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[48:51], v[128:129], v[172:173], v[48:51]
GEMM_MMA_I8 v[52:55], v[132:133], v[172:173], v[52:55]
GEMM_MMA_I8 v[56:59], v[136:137], v[172:173], v[56:59]
GEMM_MMA_I8 v[60:63], v[140:141], v[172:173], v[60:63]
GEMM_MMA_I8 v[48:51], v[130:131], v[174:175], v[48:51]
GEMM_MMA_I8 v[52:55], v[134:135], v[174:175], v[52:55]
GEMM_MMA_I8 v[56:59], v[138:139], v[174:175], v[56:59]
GEMM_MMA_I8 v[60:63], v[142:143], v[174:175], v[60:63]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[64:67], v[128:129], v[176:177], v[64:67]
GEMM_MMA_I8 v[68:71], v[132:133], v[176:177], v[68:71]
GEMM_MMA_I8 v[72:75], v[136:137], v[176:177], v[72:75]
GEMM_MMA_I8 v[76:79], v[140:141], v[176:177], v[76:79]
GEMM_MMA_I8 v[64:67], v[130:131], v[178:179], v[64:67]
GEMM_MMA_I8 v[68:71], v[134:135], v[178:179], v[68:71]
GEMM_MMA_I8 v[72:75], v[138:139], v[178:179], v[72:75]
GEMM_MMA_I8 v[76:79], v[142:143], v[178:179], v[76:79]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[80:83], v[128:129], v[180:181], v[80:83]
GEMM_MMA_I8 v[84:87], v[132:133], v[180:181], v[84:87]
GEMM_MMA_I8 v[88:91], v[136:137], v[180:181], v[88:91]
GEMM_MMA_I8 v[92:95], v[140:141], v[180:181], v[92:95]
GEMM_MMA_I8 v[80:83], v[130:131], v[182:183], v[80:83]
GEMM_MMA_I8 v[84:87], v[134:135], v[182:183], v[84:87]
GEMM_MMA_I8 v[88:91], v[138:139], v[182:183], v[88:91]
GEMM_MMA_I8 v[92:95], v[142:143], v[182:183], v[92:95]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[96:99], v[128:129], v[184:185], v[96:99]
GEMM_MMA_I8 v[100:103], v[132:133], v[184:185], v[100:103]
GEMM_MMA_I8 v[104:107], v[136:137], v[184:185], v[104:107]
GEMM_MMA_I8 v[108:111], v[140:141], v[184:185], v[108:111]
GEMM_MMA_I8 v[96:99], v[130:131], v[186:187], v[96:99]
GEMM_MMA_I8 v[100:103], v[134:135], v[186:187], v[100:103]
GEMM_MMA_I8 v[104:107], v[138:139], v[186:187], v[104:107]
GEMM_MMA_I8 v[108:111], v[142:143], v[186:187], v[108:111]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[112:115], v[128:129], v[188:189], v[112:115]
GEMM_MMA_I8 v[116:119], v[132:133], v[188:189], v[116:119]
GEMM_MMA_I8 v[120:123], v[136:137], v[188:189], v[120:123]
GEMM_MMA_I8 v[124:127], v[140:141], v[188:189], v[124:127]
GEMM_MMA_I8 v[112:115], v[130:131], v[190:191], v[112:115]
GEMM_MMA_I8 v[116:119], v[134:135], v[190:191], v[116:119]
GEMM_MMA_I8 v[120:123], v[138:139], v[190:191], v[120:123]
GEMM_MMA_I8 v[124:127], v[142:143], v[190:191], v[124:127]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
v_add_u32_e32 v201, 8192, v192
GEMM_LDS_TO_REG v[160:163], v201, 0
GEMM_LDS_TO_REG v[164:167], v201, 1024
GEMM_LDS_TO_REG v[168:171], v201, 2048
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_P
GEMM_X_GLOBAL_SADDR_TO_REG v[128:131], v194, s[8:9], 0
GEMM_X_GLOBAL_SADDR_TO_REG v[132:135], v194, s[8:9], 1024
GEMM_X_GLOBAL_SADDR_TO_REG v[136:139], v194, s[8:9], 2048
GEMM_X_GLOBAL_SADDR_TO_REG v[140:143], v194, s[8:9], 3072
.L_custom_skip_P:
GEMM_LDS_TO_REG v[172:175], v201, 3072
GEMM_LDS_TO_REG v[176:179], v201, 4096
GEMM_LDS_TO_REG v[180:183], v201, 5120
GEMM_LDS_TO_REG v[184:187], v201, 6144
GEMM_LDS_TO_REG v[188:191], v201, 7168
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_S
s_mov_b32 m0, s26
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_W_GLOBAL_TO_LDS v195, s[0:3], s27
s_add_u32 s8, s8, s18
s_addc_u32 s9, s9, 0
v_add_u32_e32 v195, s19, v195
.L_custom_skip_S:
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[0:3], v[144:145], v[160:161], v[0:3]
GEMM_MMA_I8 v[4:7], v[148:149], v[160:161], v[4:7]
GEMM_MMA_I8 v[8:11], v[152:153], v[160:161], v[8:11]
GEMM_MMA_I8 v[12:15], v[156:157], v[160:161], v[12:15]
GEMM_MMA_I8 v[0:3], v[146:147], v[162:163], v[0:3]
GEMM_MMA_I8 v[4:7], v[150:151], v[162:163], v[4:7]
GEMM_MMA_I8 v[8:11], v[154:155], v[162:163], v[8:11]
GEMM_MMA_I8 v[12:15], v[158:159], v[162:163], v[12:15]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[16:19], v[144:145], v[164:165], v[16:19]
GEMM_MMA_I8 v[20:23], v[148:149], v[164:165], v[20:23]
GEMM_MMA_I8 v[24:27], v[152:153], v[164:165], v[24:27]
GEMM_MMA_I8 v[28:31], v[156:157], v[164:165], v[28:31]
GEMM_MMA_I8 v[16:19], v[146:147], v[166:167], v[16:19]
GEMM_MMA_I8 v[20:23], v[150:151], v[166:167], v[20:23]
GEMM_MMA_I8 v[24:27], v[154:155], v[166:167], v[24:27]
GEMM_MMA_I8 v[28:31], v[158:159], v[166:167], v[28:31]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[32:35], v[144:145], v[168:169], v[32:35]
GEMM_MMA_I8 v[36:39], v[148:149], v[168:169], v[36:39]
GEMM_MMA_I8 v[40:43], v[152:153], v[168:169], v[40:43]
GEMM_MMA_I8 v[44:47], v[156:157], v[168:169], v[44:47]
GEMM_MMA_I8 v[32:35], v[146:147], v[170:171], v[32:35]
GEMM_MMA_I8 v[36:39], v[150:151], v[170:171], v[36:39]
GEMM_MMA_I8 v[40:43], v[154:155], v[170:171], v[40:43]
GEMM_MMA_I8 v[44:47], v[158:159], v[170:171], v[44:47]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[48:51], v[144:145], v[172:173], v[48:51]
GEMM_MMA_I8 v[52:55], v[148:149], v[172:173], v[52:55]
GEMM_MMA_I8 v[56:59], v[152:153], v[172:173], v[56:59]
GEMM_MMA_I8 v[60:63], v[156:157], v[172:173], v[60:63]
GEMM_MMA_I8 v[48:51], v[146:147], v[174:175], v[48:51]
GEMM_MMA_I8 v[52:55], v[150:151], v[174:175], v[52:55]
GEMM_MMA_I8 v[56:59], v[154:155], v[174:175], v[56:59]
GEMM_MMA_I8 v[60:63], v[158:159], v[174:175], v[60:63]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[64:67], v[144:145], v[176:177], v[64:67]
GEMM_MMA_I8 v[68:71], v[148:149], v[176:177], v[68:71]
GEMM_MMA_I8 v[72:75], v[152:153], v[176:177], v[72:75]
GEMM_MMA_I8 v[76:79], v[156:157], v[176:177], v[76:79]
GEMM_MMA_I8 v[64:67], v[146:147], v[178:179], v[64:67]
GEMM_MMA_I8 v[68:71], v[150:151], v[178:179], v[68:71]
GEMM_MMA_I8 v[72:75], v[154:155], v[178:179], v[72:75]
GEMM_MMA_I8 v[76:79], v[158:159], v[178:179], v[76:79]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[80:83], v[144:145], v[180:181], v[80:83]
GEMM_MMA_I8 v[84:87], v[148:149], v[180:181], v[84:87]
GEMM_MMA_I8 v[88:91], v[152:153], v[180:181], v[88:91]
GEMM_MMA_I8 v[92:95], v[156:157], v[180:181], v[92:95]
GEMM_MMA_I8 v[80:83], v[146:147], v[182:183], v[80:83]
GEMM_MMA_I8 v[84:87], v[150:151], v[182:183], v[84:87]
GEMM_MMA_I8 v[88:91], v[154:155], v[182:183], v[88:91]
GEMM_MMA_I8 v[92:95], v[158:159], v[182:183], v[92:95]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[96:99], v[144:145], v[184:185], v[96:99]
GEMM_MMA_I8 v[100:103], v[148:149], v[184:185], v[100:103]
GEMM_MMA_I8 v[104:107], v[152:153], v[184:185], v[104:107]
GEMM_MMA_I8 v[108:111], v[156:157], v[184:185], v[108:111]
GEMM_MMA_I8 v[96:99], v[146:147], v[186:187], v[96:99]
GEMM_MMA_I8 v[100:103], v[150:151], v[186:187], v[100:103]
GEMM_MMA_I8 v[104:107], v[154:155], v[186:187], v[104:107]
GEMM_MMA_I8 v[108:111], v[158:159], v[186:187], v[108:111]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[112:115], v[144:145], v[188:189], v[112:115]
GEMM_MMA_I8 v[116:119], v[148:149], v[188:189], v[116:119]
GEMM_MMA_I8 v[120:123], v[152:153], v[188:189], v[120:123]
GEMM_MMA_I8 v[124:127], v[156:157], v[188:189], v[124:127]
GEMM_MMA_I8 v[112:115], v[146:147], v[190:191], v[112:115]
GEMM_MMA_I8 v[116:119], v[150:151], v[190:191], v[116:119]
GEMM_MMA_I8 v[120:123], v[154:155], v[190:191], v[120:123]
GEMM_MMA_I8 v[124:127], v[158:159], v[190:191], v[124:127]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
GEMM_WAIT_VM 0
v_mov_b32_e32 v203, s13
v_lshrrev_b32_e32 v194, 4, v192
v_and_b32_e32 v194, 15, v194
v_lshrrev_b32_e32 v195, 8, v192
v_lshlrev_b32_e32 v195, 4, v195
v_lshlrev_b32_e32 v196, 6, v193
v_add_u32_e32 v194, v196, v194
v_add_u32_e32 v194, s22, v194
v_add_u32_e32 v195, s23, v195
v_add_u32_e32 v199, 0, v194
v_cmp_gt_u32_e32 vcc, s14, v199
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_mul_u32_u24_e32 v200, 0x11000, v199
v_add_u32_e32 v200, v195, v200
v_add_co_u32_e32 v197, vcc, s12, v200
v_addc_co_u32_e32 v198, vcc, 0, v203, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[0:3], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[16:19], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[32:35], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[48:51], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[64:67], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[80:83], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[96:99], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[112:115], 448
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v199, 16, v194
v_cmp_gt_u32_e32 vcc, s14, v199
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_mul_u32_u24_e32 v200, 0x11000, v199
v_add_u32_e32 v200, v195, v200
v_add_co_u32_e32 v197, vcc, s12, v200
v_addc_co_u32_e32 v198, vcc, 0, v203, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[4:7], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[20:23], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[36:39], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[52:55], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[68:71], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[84:87], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[100:103], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[116:119], 448
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v199, 32, v194
v_cmp_gt_u32_e32 vcc, s14, v199
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_2
v_mul_u32_u24_e32 v200, 0x11000, v199
v_add_u32_e32 v200, v195, v200
v_add_co_u32_e32 v197, vcc, s12, v200
v_addc_co_u32_e32 v198, vcc, 0, v203, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[8:11], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[24:27], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[40:43], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[56:59], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[72:75], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[88:91], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[104:107], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[120:123], 448
.L_store_skip_2:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v199, 48, v194
v_cmp_gt_u32_e32 vcc, s14, v199
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_3
v_mul_u32_u24_e32 v200, 0x11000, v199
v_add_u32_e32 v200, v195, v200
v_add_co_u32_e32 v197, vcc, s12, v200
v_addc_co_u32_e32 v198, vcc, 0, v203, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[12:15], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[28:31], 64
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[44:47], 128
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[60:63], 192
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[76:79], 256
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[92:95], 320
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[108:111], 384
GEMM_EPILOGUE_STORE_GLC_SLC v[197:198], v[124:127], 448
.L_store_skip_3:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size M256_SP3_SAB, .L_func_end-M256_SP3_SAB
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel M256_SP3_SAB
.amdhsa_group_segment_fixed_size 16384
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 40
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 204
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 16384
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           M256_SP3_SAB
    .private_segment_fixed_size: 0
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         M256_SP3_SAB.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     204
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...
.end_amdgpu_metadata
