from harness import *
init()
plan=json.loads((R/'timing-plan.json').read_text())
plan['families_by_M']={str(m):sorted({plan['before'][str(m)],plan['after'][str(m)]}) for m in plan['M_points']}
records=plan['records']
mods=[Module(r) for r in records]
mm={q.fam:q for q in mods}
legacy=get_legacy()
out=dict(status='running',groups=[],correctness=dict(pool=0,graph=0,timed=0,cpu_spots=0),rounds=plan['rounds'],pool=72,seeds=plan['seeds'],copies=72)
save('timing-status.json',dict(status='running',groups=0))
for si,seed in enumerate(plan['seeds']):
 torch.manual_seed(seed)
 xf=torch.randint(-128,128,(256,5120),device='cuda',dtype=torch.int8)
 packs={(m,mp_for(f,m,mm,legacy)):pack(xf[:m],mp_for(f,m,mm,legacy)) for m in plan['M_points'] for f in plan['families_by_M'][str(m)]}
 poolcases=[]
 for r in records:
  for m in ([128,129] if r['BM']==128 else sorted(set([129,r['BM']]))):
   mp=mp_for(r['family'],m,mm,legacy)
   packs.setdefault((m,mp),pack(xf[:m],mp))
   poolcases.append((r['family'],m))
 poolcases+=[('E030',1),('E047',128)]
 for f,m in poolcases:
  mp=mp_for(f,m,mm,legacy)
  packs.setdefault((m,mp),pack(xf[:m],mp))
 xp={mp:torch.empty_like(next(t for (m,k),t in packs.items() if k==mp)) for mp in sorted(set(k for m,k in packs))}
 b,y=backing(256)
 wps=[]
 for ci in range(72):
  w=torch.randint(-128,128,(17408,5120),device='cuda',dtype=torch.int8)
  wp=pack_weight(w,True)
  ref=reference(xf,w)
  if ci in [0,71]:out['correctness']['cpu_spots']+=spots(xf,w,ref)
  for f,m in poolcases:
   mp=mp_for(f,m,mm,legacy)
   xp[mp].copy_(packs[m,mp])
   b.fill_(SENTINEL)
   run(f,xp[mp],wp,y,m,mp,mm,legacy)
   torch.cuda.synchronize()
   valid(b,y,m,ref)
   out['correctness']['pool']+=1
  wps.append(wp)
  if ci==71:ref71=ref
  del w,wp,ref
 orderM=list(plan['M_points'])
 random.Random(seed).shuffle(orderM)
 shard=R/f'timing-seed-{seed}.jsonl'
 assert not shard.exists()
 with shard.open('w') as stream:
  for mi,m in enumerate(orderM):
   fs=plan['families_by_M'][str(m)]
   graphs={}
   for f in fs:
    mp=mp_for(f,m,mm,legacy)
    xp[mp].copy_(packs[m,mp])
    g=capture(f,xp[mp],wps,y,m,mp,mm,legacy)
    b.fill_(SENTINEL)
    g.replay()
    torch.cuda.synchronize()
    valid(b,y,m,ref71)
    out['correctness']['graph']+=1
    graphs[f]=g
   for g in graphs.values():g.replay()
   torch.cuda.synchronize()
   group=dict(seed=seed,M=m,N=17408,K=5120,copies=72,samples=[],XP_by_MP={str(k):v.data_ptr() for k,v in xp.items()},Y_ptr=y.data_ptr(),WP_0=wps[0].data_ptr(),WP_71=wps[71].data_ptr())
   rng=random.Random(seed+m)
   for rnd in range(plan['rounds']):
    order=list(graphs)
    rng.shuffle(order)
    row=dict(round=rnd,us={})
    for f in order:
     row['us'][f]=measure(graphs[f],72,b,y,m,ref71)
     out['correctness']['timed']+=1
    group['samples'].append(row)
   out['groups'].append(group)
   stream.write(json.dumps(group,separators=(',',':'))+'\n')
   stream.flush()
   us={f:statistics.median(z['us'][f] for z in group['samples']) for f in graphs}
   old=[f for f in us if f in legacy or mm[f].rec['kind']=='old']
   fb=min(old,key=us.get)
   fa=min(us,key=us.get)
   save('timing-status.json',dict(status='running',seed=seed,seed_index=si,seed_completed_M=mi+1,groups=len(out['groups']),M=m,before=dict(family=fb,us=us[fb]),after=dict(family=fa,us=us[fa]),correctness=out['correctness']))
   if (mi+1)%16==0 or m in [128,129,192,193,208,224,240,256]:print('TIMING',seed,mi+1,m,fb,round(us[fb],4),'->',fa,round(us[fa],4),flush=True)
   del graphs,g
   gc.collect()
 del xf,packs,xp,b,y,wps,ref71
 gc.collect()
 torch.cuda.empty_cache()
out.update(status='complete',finished=now())
save('timing-raw.json',out)
save('timing-status.json',dict(status='complete',groups=len(out['groups']),correctness=out['correctness']))
print('TIMING_DONE',out['correctness'],flush=True)
