from pathlib import Path
import json,csv,statistics,collections,datetime,hashlib
I=Path(__file__).resolve().parent;S=I/'stage'
plan=json.loads((I/'timing-plan.json').read_text())
raw=json.loads((I/'timing-raw.json').read_text())
assert raw['status']=='complete' and len(raw['groups'])==768 and raw['copies']==72
records={r['family']:r for r in plan['records']}
values={};ptrs={}
for g in raw['groups']:
 m=g['M'];seed=str(g['seed']);expected={plan['before'][str(m)],plan['after'][str(m)]}
 assert g['copies']==72 and len(g['samples'])==7
 assert all(set(z['us'])==expected for z in g['samples'])
 pp={k:g[k] for k in ['XP_by_MP','Y_ptr','WP_0','WP_71']}
 if seed in ptrs:assert ptrs[seed]==pp
 else:ptrs[seed]=pp
 for f in expected:
  v=values.setdefault(m,{}).setdefault(f,dict(seeds={},rounds={}))
  assert seed not in v['seeds']
  v['rounds'][seed]=[s['us'][f] for s in g['samples']]
  v['seeds'][seed]=statistics.median(v['rounds'][seed])
for m,fs in values.items():
 for f,v in fs.items():
  assert len(v['seeds'])==3
  v['us']=statistics.median(v['seeds'].values())
N=17408;K=5120;HBM=1.35e12;L2=4.5e12
def model(m,f,us):
 if f=='E030':bm,bn,nw,ks,mp,d=32,64,2,2,32,'K-split'
 elif f=='E047':bm,bn,nw,ks,mp,d=128,128,4,1,128,'M'
 else:
  v=records[f];bm,bn,nw,ks,mp,d=v['BM'],v['BN'],4,1,256,v['direction']
 gm=(m+bm-1)//bm;gn=N//bn;cm=gm*bm
 qx=gn*cm*K;qw=gm*N*K
 first=(m+N)*K;padding=(cm-m)*K
 repeated=qx+qw-(cm+N)*K;total=qx+qw;sec=us*1e-6
 assert total==first+padding+repeated and gm==1 and qw==N*K
 return dict(M=m,N=N,K=K,family=f,direction=d,BM=bm,BN=bn,NW=nw,KS=ks,MP=mp,grid_M=gm,grid_N=gn,CTA=gm*gn,covered_M=cm,
 latency_us=us,HBM_unique_valid_bytes=first,X_padding_unique_bytes=padding,HBM_padded_unique_bytes=first+padding,
 X_requested_bytes=qx,W_requested_bytes=qw,input_requested_bytes=total,L2_repeat_X_bytes=qx-cm*K,L2_repeat_W_bytes=qw-N*K,L2_repeat_bytes=repeated,Y_int32_output_bytes=4*m*N,
 HBM_input_TBs=first/sec/1e12,HBM_input_util_pct=first/sec/HBM*100,HBM_with_padding_util_pct=(first+padding)/sec/HBM*100,
 L2_repeat_TBs=repeated/sec/1e12,L2_repeat_util_pct=repeated/sec/L2*100,L2_all_input_TBs=total/sec/1e12,L2_all_input_util_pct=total/sec/L2*100,
 HBM_input_plus_output_normalized_pct=(first+4*m*N)/sec/HBM*100)
rows=[];oldrows=[];comparison=[]
for m,fs in sorted(values.items()):
 b=plan['before'][str(m)];a=plan['after'][str(m)];bv=fs[b];av=fs[a]
 before=model(m,b,bv['us']);after=model(m,a,av['us'])
 assert all(before[k]==after[k] for k in ['HBM_unique_valid_bytes','X_padding_unique_bytes','X_requested_bytes','W_requested_bytes','L2_repeat_bytes','input_requested_bytes'])
 gains={s:bv['seeds'][s]-av['seeds'][s] for s in bv['seeds']}
 if m<=192:assert b==a and before['latency_us']==after['latency_us']
 else:assert before['latency_us']-after['latency_us']>=.2 and min(gains.values())>0
 rows.append(after);oldrows.append(before)
 c=dict(M=m,before_family=b,after_family=a,before_us=bv['us'],after_us=av['us'],saved_us=bv['us']-av['us'],
 reduction_pct=100*(bv['us']-av['us'])/bv['us'],HBM_before_pct=before['HBM_input_util_pct'],HBM_after_pct=after['HBM_input_util_pct'],
 L2_repeat_before_pct=before['L2_repeat_util_pct'],L2_repeat_after_pct=after['L2_repeat_util_pct'],L2_all_before_pct=before['L2_all_input_util_pct'],L2_all_after_pct=after['L2_all_input_util_pct'],
 request_bytes=after['input_requested_bytes'],seeds_before=json.dumps(bv['seeds'],separators=(',',':')),seeds_after=json.dumps(av['seeds'],separators=(',',':')),seeds_saved=json.dumps(gains,separators=(',',':')))
 comparison.append(c)
def writecsv(name,data):
 with (I/name).open('w',newline='') as h:
  w=csv.DictWriter(h,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
writecsv('bandwidth-M1-256.csv',rows)
writecsv('before-bandwidth-M1-256.csv',oldrows)
writecsv('before-after-M1-256.csv',comparison)
clock=json.loads((I/'sequence-status.json').read_text())
assert clock['status']=='complete' and all(j['returncode']==0 and j['before']=={} and j['after']=={} for j in clock['jobs'])
assert all(s['mode']=='manual' and s['sclk_MHz']==1499 and s['mclk_MHz']==1800 and len(s['owners'])<=1 for s in clock['clock_samples'])
(I/'timing-sequence-status.json').write_text(json.dumps(clock,indent=2)+'\n')
ranges=[]
for lo,hi in [(1,128),(129,192),(193,208),(209,224),(225,240),(241,256)]:
 sub=comparison[lo-1:hi]
 ranges.append(dict(M_start=lo,M_end=hi,mean_before_us=statistics.mean(v['before_us'] for v in sub),
 mean_after_us=statistics.mean(v['after_us'] for v in sub),mean_saved_us=statistics.mean(v['saved_us'] for v in sub),
 min_saved_us=min(v['saved_us'] for v in sub),max_saved_us=max(v['saved_us'] for v in sub),mean_reduction_pct=statistics.mean(v['reduction_pct'] for v in sub)))
jump=dict(before_us=oldrows[192]['latency_us']-oldrows[191]['latency_us'],after_us=rows[192]['latency_us']-rows[191]['latency_us'])
policy=json.loads((S/'tile_schedule_policy.json').read_text())
oldpolicy=json.loads((I/'before/tile_schedule_policy.json').read_text())
for m in range(193,257):
 row=comparison[m-1];e=policy['best_by_M'][str(m)]
 assert e['family']==row['after_family']
 e.update(latency_us=row['after_us'],previous_route_same_run_us=row['before_us'],saved_same_run_us=row['saved_us'],per_seed_saved_us=json.loads(row['seeds_saved']),measurement=str(I/'timing-raw.json'))
assert all(policy['best_by_M'][str(m)]==oldpolicy['best_by_M'][str(m)] for m in range(129,193))
policy['validation'].update(integration_status='passed',integration_proof=str(I/'integration-proof.json'),integration_holdout_seeds=plan['seeds'],
                           integration_correctness=raw['correctness'],clock=dict(sclk_MHz=1499,mclk_MHz=1800,mode='manual',samples=len(clock['clock_samples'])))
policy['compiled_variants']={r['family']:r for r in json.loads((I/'generated/policy/variants.json').read_text())}
(S/'tile_schedule_policy.json').write_text(json.dumps(policy,indent=2)+'\n')
result=dict(status='complete',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,before_rows=oldrows,comparison=comparison,ranges=ranges,jump_192_193=jump,
 seeds=plan['seeds'],rounds=7,copies=72,correctness=raw['correctness'],clock=policy['validation']['clock'],
 values=values,model=dict(HBM='(M+N)*K/t/1.35e12',L2_repeat='[Qx+Qw-(covered_M+N)*K]/t/4.5e12',L2_all='(Qx+Qw)/t/4.5e12',
 Qx='grid_N*covered_M*K',Qw='grid_M*N*K',first_touch_padding='(covered_M-M)*K',output='INT32 writes separate;not in the input-read curves',
 limits='software read payload under user assumptions;not physical HBM/L2 counter utilization;decimal TB/s'),input_request_bytes_unchanged=True,unchanged_M_range=[1,192],changed_M_range=[193,256])
(I/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print('ANALYZED_RANGES',json.dumps(ranges))
print('JUMP',jump,'CORRECTNESS',raw['correctness'],'CLOCK',result['clock'])
for m in [1,128,129,192,193,208,224,240,256]:
 r=rows[m-1];b=oldrows[m-1]
 print('POINT',m,b['family'],round(b['latency_us'],4),'->',r['family'],round(r['latency_us'],4),'HBM',round(b['HBM_input_util_pct'],3),round(r['HBM_input_util_pct'],3),'L2repeat',round(r['L2_repeat_util_pct'],3),'L2all',round(r['L2_all_input_util_pct'],3))
