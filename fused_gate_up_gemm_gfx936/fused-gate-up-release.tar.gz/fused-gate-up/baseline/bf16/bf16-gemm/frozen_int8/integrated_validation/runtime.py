
import os
os.environ['HIP_VISIBLE_DEVICES']='4'
for k in ['CUDA_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL']:os.environ.pop(k,None)
from pathlib import Path
import sys,ctypes as C,json,statistics,random,time,datetime,hashlib,gc,math
R=Path(__file__).resolve().parent
sys.path.insert(0,'/home/zmoe/experiments/int8-bw90-20261110/tools')
from common import torch,np,pack,pack_weight,reference
torch.set_num_threads(8)
HIP=C.CDLL('libamdhip64.so');HIP.hipGetErrorString.restype=C.c_char_p
HIP.hipModuleLoad.argtypes=[C.POINTER(C.c_void_p),C.c_char_p]
HIP.hipModuleGetFunction.argtypes=[C.POINTER(C.c_void_p),C.c_void_p,C.c_char_p]
HIP.hipModuleLaunchKernel.argtypes=[C.c_void_p]+[C.c_uint]*7+[C.c_void_p,C.POINTER(C.c_void_p),C.c_void_p]
HIP.hipFuncGetAttribute.argtypes=[C.POINTER(C.c_int),C.c_int,C.c_void_p]
SENTINEL=0x5a5a5a5a

def ok(rc):
 if rc:raise RuntimeError((rc,HIP.hipGetErrorString(rc).decode()))
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def init():
 assert torch.cuda.device_count()==1
 b=C.create_string_buffer(64);ok(HIP.hipDeviceGetPCIBusId(b,64,0));assert b.value.decode().lower()=='0000:e8:00.0'
 save('torch-environment.json',dict(torch=torch.__version__,HIP=torch.version.hip,device=str(torch.cuda.get_device_properties(0)),PCI=b.value.decode()))
class Module:
 def __init__(self,rec):
  self.rec=rec;self.fam=rec['family'];self.bm=rec['BM'];assert hashlib.sha256(Path(rec['path']).read_bytes()).hexdigest()==rec['hsaco_sha256']
  self.mod=C.c_void_p();ok(HIP.hipModuleLoad(C.byref(self.mod),rec['path'].encode()));self.fn=C.c_void_p();ok(HIP.hipModuleGetFunction(C.byref(self.fn),self.mod,rec['function'].encode()))
  self.info={}
  for attr in [0,1,2,3,4]:
   v=C.c_int();ok(HIP.hipFuncGetAttribute(C.byref(v),attr,self.fn));self.info[str(attr)]=v.value
  assert self.info['1']==rec['LDS'] and self.info['3']==0 and self.info['4']==rec['VGPR'],(self.fam,self.info,rec)
  self.capacity=None
  if hasattr(HIP,'hipModuleOccupancyMaxActiveBlocksPerMultiprocessor'):
   f=HIP.hipModuleOccupancyMaxActiveBlocksPerMultiprocessor;f.argtypes=[C.POINTER(C.c_int),C.c_void_p,C.c_int,C.c_size_t];a=C.c_int();rc=f(C.byref(a),self.fn,256,0);self.capacity=a.value if rc==0 else str(rc)
 def launch(self,xp,wp,y,m,mp=256,n=17408,k=5120):
  if self.rec.get("fixed"):assert (m,n,k,mp)==(128,17408,5120,128)
  if self.rec.get("M_limit"):assert m<=self.rec["M_limit"]
  assert m<=math.ceil(m/self.bm)*self.bm<=mp
  vals=[C.c_void_p(xp.data_ptr()),C.c_void_p(wp.data_ptr()),C.c_void_p(y.data_ptr())]+[C.c_int(x) for x in [m,n,k,mp]]
  args=(C.c_void_p*len(vals))(*[C.addressof(x) for x in vals])
  ok(HIP.hipModuleLaunchKernel(self.fn,n//self.rec["BN"],math.ceil(m/self.bm),1,256,1,1,0,C.c_void_p(torch.cuda.current_stream().cuda_stream),args,None))
def modules():return [Module(x) for x in json.loads((R/'variants.json').read_text())]
def backing(m,n=17408):
 b=torch.full((m*n+2048,),SENTINEL,dtype=torch.int32,device='cuda');return b,b[1024:-1024].view(m,n)
def check(b,y,ref):
 bad=int((y!=ref).sum().item());g=bool((b[:1024]==SENTINEL).all().item() and (b[-1024:]==SENTINEL).all().item())
 if bad or not g:
  ids=torch.nonzero(y!=ref)[:12].cpu().tolist();raise RuntimeError({'bad':bad,'guards':g,'first':[(i,j,int(y[i,j]),int(ref[i,j])) for i,j in ids]})
 return {'checked':y.numel(),'bad':0,'guards':True}
def spots(x,w,ref):
 rows=sorted(set([v for v in [0,15,16,31,32,47,48,63,64,95,96,127,128,129,143,144,191,192,255,256,287,288,x.shape[0]-1] if v<x.shape[0]]));cols=sorted(set([c for c in [0,15,16,31,32,127,128,17407,w.shape[0]-1] if c<w.shape[0]]))
 v=x[rows].cpu().numpy().astype(np.int64)@w[cols].cpu().numpy().astype(np.int64).T
 assert np.array_equal(v,ref[rows][:,cols].cpu().numpy());return len(rows)*len(cols)
