
from pathlib import Path
import os,json,time,subprocess,signal,sys
R=Path(__file__).resolve().parent;PCI=Path('/sys/bus/pci/devices/0000:e8:00.0');FREQ=next(PCI.glob('hwmon/hwmon*/freq1_input'));MEM=next(PCI.glob('hwmon/hwmon*/freq2_input'))
def owners():return {p.parent.name:int(p.read_text()) for p in Path('/sys/class/kfd/kfd/proc').glob('*/vram_17003') if int(p.read_text())>0}
base=json.loads((R/'environment-before.json').read_text())['owners'];state={'status':'running','baseline_owners':base,'jobs':[],'clock_samples':[]}
def save():(R/'sequence-status.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 for script in sys.argv[1:]:
  assert owners()==base,owners();env=os.environ.copy();env.update(HIP_VISIBLE_DEVICES='4',OMP_NUM_THREADS='8')
  for k in ['CUDA_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL','HSA_TOOLS_LIB','XPROF_SECTIONS','XPROF_METRICS']:env.pop(k,None)
  job={'script':script,'start':time.time(),'before':owners()};state['jobs'].append(job);save()
  with (R/(Path(script).stem+'.log')).open('w') as f:
   c=subprocess.Popen(['python3','-u',str(R/script)],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);start=time.monotonic()
   while c.poll() is None:
    o=owners();mhz=int(FREQ.read_text())/1e6;mem=int(MEM.read_text())/1e6;mode=(PCI/'power_dpm_force_performance_level').read_text().strip();state['clock_samples'].append({'unix':time.time(),'job':script,'sclk_MHz':mhz,'mclk_MHz':mem,'mode':mode,'owners':o})
    if len(set(o)-set(base))>1 or any(o.get(k)!=v for k,v in base.items()) or abs(mhz-1500)>5 or mem!=1800 or mode!='manual' or time.monotonic()-start>2400:
     os.killpg(c.pid,signal.SIGTERM);c.wait(timeout=20);raise RuntimeError({'gate':o,'sclk':mhz,'mclk':mem,'mode':mode})
    save();time.sleep(.2)
  job.update(returncode=c.returncode,after=owners(),finish=time.time());save();assert c.returncode==0,(script,(R/(Path(script).stem+'.log')).read_text()[-5000:]);assert owners()==base,owners()
 state['status']='complete';save()
except BaseException as e:state.update(status='failed',error=repr(e));save();raise
