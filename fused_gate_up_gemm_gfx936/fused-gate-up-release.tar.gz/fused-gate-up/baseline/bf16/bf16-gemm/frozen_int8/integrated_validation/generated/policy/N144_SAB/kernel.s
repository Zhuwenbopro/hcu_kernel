; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.N144_SAB,#alloc,#execinstr
.protected N144_SAB
.globl N144_SAB
.p2align 8
.type N144_SAB,@function
N144_SAB:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v124, 63, v0
v_lshlrev_b32_e32 v124, 4, v124
v_lshrrev_b32_e32 v125, 6, v0
v_lshlrev_b32_e32 v127, 4, v0
v_lshlrev_b32_e32 v128, 10, v125
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_mul_i32 s22, s7, 144
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_mul_i32 s21, s7, 9216
s_mov_b32 s0, s8
s_add_u32 s1, s9, 0x40800000
s_mov_b32 s18, s17
s_mov_b32 s19, s16
s_mov_b32 s26, s20
s_mov_b32 s20, s21
s_mov_b32 s21, s26
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v126, 11, v125
s_add_u32 s10, s10, s21
s_addc_u32 s11, s11, 0
v_add_u32_e32 v126, v126, v124
v_add_u32_e32 v127, s20, v127
v_readfirstlane_b32 s25, v125
v_mov_b32_e32 v135, s11
v_readfirstlane_b32 s26, v128
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[72:75], v126, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[76:79], v126, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s27
s_cmp_lt_u32 s25, 1
s_cbranch_scc0 .L_copy_skip_0_2
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s28
.L_copy_skip_0_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v127, s19, v127
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
v_mov_b32_e32 v64, 0
v_mov_b32_e32 v65, 0
v_mov_b32_e32 v66, 0
v_mov_b32_e32 v67, 0
v_mov_b32_e32 v68, 0
v_mov_b32_e32 v69, 0
v_mov_b32_e32 v70, 0
v_mov_b32_e32 v71, 0
s_mov_b32 s24, 40
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
; issue private and shared stage to slot1
GEMM_W_GLOBAL_SADDR_TO_REG v[80:83], v126, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[84:87], v126, s[10:11], 1024
s_add_u32 m0, s26, 9216
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], 0
s_add_u32 m0, s26, 13312
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s27
s_cmp_lt_u32 s25, 1
s_cbranch_scc0 .L_copy_skip_1_2
s_add_u32 m0, s26, 17408
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s28
.L_copy_skip_1_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v127, s19, v127
v_add_u32_e32 v133, 0, v124
GEMM_LDS_TO_REG v[88:91], v133, 0
GEMM_LDS_TO_REG v[92:95], v133, 1024
GEMM_LDS_TO_REG v[96:99], v133, 2048
GEMM_LDS_TO_REG v[100:103], v133, 3072
GEMM_LDS_TO_REG v[104:107], v133, 4096
GEMM_LDS_TO_REG v[108:111], v133, 5120
GEMM_LDS_TO_REG v[112:115], v133, 6144
GEMM_LDS_TO_REG v[116:119], v133, 7168
GEMM_LDS_TO_REG v[120:123], v133, 8192
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[0:3], v[88:89], v[72:73], v[0:3]
GEMM_MMA_I8 v[4:7], v[88:89], v[76:77], v[4:7]
GEMM_MMA_I8 v[0:3], v[90:91], v[74:75], v[0:3]
GEMM_MMA_I8 v[4:7], v[90:91], v[78:79], v[4:7]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[8:11], v[92:93], v[72:73], v[8:11]
GEMM_MMA_I8 v[12:15], v[92:93], v[76:77], v[12:15]
GEMM_MMA_I8 v[8:11], v[94:95], v[74:75], v[8:11]
GEMM_MMA_I8 v[12:15], v[94:95], v[78:79], v[12:15]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[16:19], v[96:97], v[72:73], v[16:19]
GEMM_MMA_I8 v[20:23], v[96:97], v[76:77], v[20:23]
GEMM_MMA_I8 v[16:19], v[98:99], v[74:75], v[16:19]
GEMM_MMA_I8 v[20:23], v[98:99], v[78:79], v[20:23]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[24:27], v[100:101], v[72:73], v[24:27]
GEMM_MMA_I8 v[28:31], v[100:101], v[76:77], v[28:31]
GEMM_MMA_I8 v[24:27], v[102:103], v[74:75], v[24:27]
GEMM_MMA_I8 v[28:31], v[102:103], v[78:79], v[28:31]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[32:35], v[104:105], v[72:73], v[32:35]
GEMM_MMA_I8 v[36:39], v[104:105], v[76:77], v[36:39]
GEMM_MMA_I8 v[32:35], v[106:107], v[74:75], v[32:35]
GEMM_MMA_I8 v[36:39], v[106:107], v[78:79], v[36:39]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[40:43], v[108:109], v[72:73], v[40:43]
GEMM_MMA_I8 v[44:47], v[108:109], v[76:77], v[44:47]
GEMM_MMA_I8 v[40:43], v[110:111], v[74:75], v[40:43]
GEMM_MMA_I8 v[44:47], v[110:111], v[78:79], v[44:47]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[48:51], v[112:113], v[72:73], v[48:51]
GEMM_MMA_I8 v[52:55], v[112:113], v[76:77], v[52:55]
GEMM_MMA_I8 v[48:51], v[114:115], v[74:75], v[48:51]
GEMM_MMA_I8 v[52:55], v[114:115], v[78:79], v[52:55]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[56:59], v[116:117], v[72:73], v[56:59]
GEMM_MMA_I8 v[60:63], v[116:117], v[76:77], v[60:63]
GEMM_MMA_I8 v[56:59], v[118:119], v[74:75], v[56:59]
GEMM_MMA_I8 v[60:63], v[118:119], v[78:79], v[60:63]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[64:67], v[120:121], v[72:73], v[64:67]
GEMM_MMA_I8 v[68:71], v[120:121], v[76:77], v[68:71]
GEMM_MMA_I8 v[64:67], v[122:123], v[74:75], v[64:67]
GEMM_MMA_I8 v[68:71], v[122:123], v[78:79], v[68:71]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_skip_next
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[72:75], v126, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[76:79], v126, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s27
s_cmp_lt_u32 s25, 1
s_cbranch_scc0 .L_copy_skip_2_2
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v127, s[0:3], s28
.L_copy_skip_2_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v127, s19, v127
.L_skip_next:
v_add_u32_e32 v133, 9216, v124
GEMM_LDS_TO_REG v[88:91], v133, 0
GEMM_LDS_TO_REG v[92:95], v133, 1024
GEMM_LDS_TO_REG v[96:99], v133, 2048
GEMM_LDS_TO_REG v[100:103], v133, 3072
GEMM_LDS_TO_REG v[104:107], v133, 4096
GEMM_LDS_TO_REG v[108:111], v133, 5120
GEMM_LDS_TO_REG v[112:115], v133, 6144
GEMM_LDS_TO_REG v[116:119], v133, 7168
GEMM_LDS_TO_REG v[120:123], v133, 8192
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[0:3], v[88:89], v[80:81], v[0:3]
GEMM_MMA_I8 v[4:7], v[88:89], v[84:85], v[4:7]
GEMM_MMA_I8 v[0:3], v[90:91], v[82:83], v[0:3]
GEMM_MMA_I8 v[4:7], v[90:91], v[86:87], v[4:7]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[8:11], v[92:93], v[80:81], v[8:11]
GEMM_MMA_I8 v[12:15], v[92:93], v[84:85], v[12:15]
GEMM_MMA_I8 v[8:11], v[94:95], v[82:83], v[8:11]
GEMM_MMA_I8 v[12:15], v[94:95], v[86:87], v[12:15]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[16:19], v[96:97], v[80:81], v[16:19]
GEMM_MMA_I8 v[20:23], v[96:97], v[84:85], v[20:23]
GEMM_MMA_I8 v[16:19], v[98:99], v[82:83], v[16:19]
GEMM_MMA_I8 v[20:23], v[98:99], v[86:87], v[20:23]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[24:27], v[100:101], v[80:81], v[24:27]
GEMM_MMA_I8 v[28:31], v[100:101], v[84:85], v[28:31]
GEMM_MMA_I8 v[24:27], v[102:103], v[82:83], v[24:27]
GEMM_MMA_I8 v[28:31], v[102:103], v[86:87], v[28:31]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[32:35], v[104:105], v[80:81], v[32:35]
GEMM_MMA_I8 v[36:39], v[104:105], v[84:85], v[36:39]
GEMM_MMA_I8 v[32:35], v[106:107], v[82:83], v[32:35]
GEMM_MMA_I8 v[36:39], v[106:107], v[86:87], v[36:39]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[40:43], v[108:109], v[80:81], v[40:43]
GEMM_MMA_I8 v[44:47], v[108:109], v[84:85], v[44:47]
GEMM_MMA_I8 v[40:43], v[110:111], v[82:83], v[40:43]
GEMM_MMA_I8 v[44:47], v[110:111], v[86:87], v[44:47]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[48:51], v[112:113], v[80:81], v[48:51]
GEMM_MMA_I8 v[52:55], v[112:113], v[84:85], v[52:55]
GEMM_MMA_I8 v[48:51], v[114:115], v[82:83], v[48:51]
GEMM_MMA_I8 v[52:55], v[114:115], v[86:87], v[52:55]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[56:59], v[116:117], v[80:81], v[56:59]
GEMM_MMA_I8 v[60:63], v[116:117], v[84:85], v[60:63]
GEMM_MMA_I8 v[56:59], v[118:119], v[82:83], v[56:59]
GEMM_MMA_I8 v[60:63], v[118:119], v[86:87], v[60:63]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[64:67], v[120:121], v[80:81], v[64:67]
GEMM_MMA_I8 v[68:71], v[120:121], v[84:85], v[68:71]
GEMM_MMA_I8 v[64:67], v[122:123], v[82:83], v[64:67]
GEMM_MMA_I8 v[68:71], v[122:123], v[86:87], v[68:71]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
GEMM_WAIT_VM 0
v_mov_b32_e32 v135, s13
v_lshrrev_b32_e32 v126, 4, v124
v_and_b32_e32 v126, 15, v126
v_lshrrev_b32_e32 v127, 8, v124
v_lshlrev_b32_e32 v127, 4, v127
v_lshlrev_b32_e32 v128, 5, v125
v_lshlrev_b32_e32 v128, 2, v128
v_add_u32_e32 v127, v128, v127
v_add_u32_e32 v126, s22, v126
v_add_u32_e32 v127, s23, v127
v_add_u32_e32 v131, 0, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[0:3], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[4:7], 64
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 16, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[8:11], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[12:15], 64
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 32, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_2
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[16:19], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[20:23], 64
.L_store_skip_2:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 48, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_3
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[24:27], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[28:31], 64
.L_store_skip_3:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 64, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_4
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[32:35], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[36:39], 64
.L_store_skip_4:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 80, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_5
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[40:43], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[44:47], 64
.L_store_skip_5:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 96, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_6
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[48:51], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[52:55], 64
.L_store_skip_6:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 112, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_7
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[56:59], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[60:63], 64
.L_store_skip_7:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v131, 128, v126
v_cmp_gt_u32_e32 vcc, s14, v131
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_8
v_mul_u32_u24_e32 v132, 0x11000, v131
v_add_u32_e32 v132, v127, v132
v_add_co_u32_e32 v129, vcc, s12, v132
v_addc_co_u32_e32 v130, vcc, 0, v135, vcc
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[64:67], 0
GEMM_EPILOGUE_STORE_GLC_SLC v[129:130], v[68:71], 64
.L_store_skip_8:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size N144_SAB, .L_func_end-N144_SAB
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel N144_SAB
.amdhsa_group_segment_fixed_size 18432
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 40
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 136
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 18432
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           N144_SAB
    .private_segment_fixed_size: 0
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         N144_SAB.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     136
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...
.end_amdgpu_metadata
