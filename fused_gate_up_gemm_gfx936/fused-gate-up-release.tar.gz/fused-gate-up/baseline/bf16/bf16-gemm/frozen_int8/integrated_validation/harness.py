from runtime import *
from common import library,current_library,launch as legacy_launch
def get_legacy():
 E=Path('/home/zmoe/experiments/int8-bw90-20261110')
 libs={'E030':library(E/'best/E030/kernel.so'),'E047':current_library('E047')}
 manifest=json.loads((E/'best/manifest.json').read_text())
 assert hashlib.sha256((E/'best/E030/kernel.so').read_bytes()).hexdigest()==manifest['binaries']['E030']['kernel.so']
 for v in libs.values():assert v['pi'] and v['info'][2]==0
 return libs
def mp_for(f,m,mm,legacy):
 if f in legacy:
  bm=legacy[f]['info'][3];return ((m+bm-1)//bm)*bm
 return 128 if mm[f].bm==128 and m<=128 else 256
def run(f,xp,wp,y,m,mp,mm,legacy):
 if f in legacy:legacy_launch(legacy[f],xp,wp,y[:m],m,17408,5120)
 else:mm[f].launch(xp,wp,y[:m],m,mp=mp)
def valid(b,y,m,ref):
 check(b,y[:m],ref[:m]);assert bool((y[m:]==SENTINEL).all().item())
def capture(f,xp,wps,y,m,mp,mm,legacy):
 g=torch.cuda.CUDAGraph()
 with torch.cuda.graph(g):
  for wp in wps:run(f,xp,wp,y,m,mp,mm,legacy)
 return g
def measure(g,copies,b,y,m,ref):
 b.fill_(SENTINEL);a=torch.cuda.Event(enable_timing=True);e=torch.cuda.Event(enable_timing=True);a.record();g.replay();e.record();e.synchronize();us=a.elapsed_time(e)*1000/copies;valid(b,y,m,ref);return us
def eligible(rec,m):return rec['BM']>=m or rec['BM']==128
