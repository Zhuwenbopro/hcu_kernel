from pathlib import Path
import re
I=Path(__file__).resolve().parent
S=I/'stage'
p=S/'tile_generator.py'
src=p.read_text()
def replace_once(a,b):
 global src
 assert src.count(a)==1,(a[:100],src.count(a))
 src=src.replace(a,b)
replace_once("PREFETCH_ORDERS = ('legacy','private_first')","PREFETCH_ORDERS = ('legacy','private_first','split_private_then_shared')")
replace_once(" fam=f'{direction}{bm}'+(f'_RF{read_first}' if read_first else '')"," fam=f'{direction}{bm}'+(f'_SP{read_first}' if prefetch_order=='split_private_then_shared' else f'_RF{read_first}' if read_first else '')")
replace_once("prefetch_order=prefetch_order, current_reads_before_shared=sf if prefetch_order=='private_first' else read_first,","prefetch_order=prefetch_order,\n             current_reads_before_private=0 if prefetch_order=='private_first' else read_first,\n             current_reads_before_shared=sf if prefetch_order in ('private_first','split_private_then_shared') else read_first,")
helper=r'''
def _split_prefetch_source(src,cfg):
 """D_prefix(current), P(next), D_rest(current), S(next), compute.

 Both current-slot read groups remain unconditional in the final K64 pair.
 P and S use the existing, disjoint private/address/shared register windows.
 """
 sf=cfg['SF'];k=cfg['read_first_fragments'];t=cfg['address_registers'][0]
 advance=_advance_source(cfg)
 stages=list(re.finditer(r'; issue private and shared stage to slot([01])\n(.*?)('+re.escape(advance)+')',src,re.S))
 assert len(stages)==3
 packets=[]
 for m in stages:
  body=m[2]
  loads=list(re.finditer(r'GEMM_[XW]_GLOBAL_(?:SADDR_)?TO_REG [^\n]+\n',body))
  assert len(loads)==cfg['PF']
  cut=loads[-1].end()
  packets.append(dict(P=body[:cut],S=body[cut:],advance=m[3]))
 pattern=fr'v_add_u32_e32 v{t+9}, (0|{sf*1024}), v{t}\n(?:(?:GEMM_LDS_TO_REG|GEMM_WAIT_LGKM|GEMM_MMA_I8)[^\n]*\n)+'
 consumers=list(re.finditer(pattern,src))
 assert len(consumers)==2
 prefix=[];rest=[];math=[]
 for m in consumers:
  ls=m[0].splitlines(keepends=True)
  assert all('GEMM_LDS_TO_REG' in z for z in ls[1:sf+1])
  prefix.append(''.join(ls[:k+1]))
  rest.append(''.join(ls[k+1:sf+1]))
  math.append(''.join(ls[sf+1:]))
 ready='GEMM_WAIT_VM 0\nGEMM_WAIT_LGKM 0\nGEMM_CTA_BARRIER\n'
 out=[ready,prefix[0],packets[1]['P'],rest[0],packets[1]['S'],packets[1]['advance'],
      math[0],ready,'s_sub_u32 s24, s24, 1\n',prefix[1],
      's_cmp_eq_u32 s24, 0\ns_cbranch_scc1 .L_custom_skip_P\n',packets[2]['P'],
      '.L_custom_skip_P:\n',rest[1],
      's_cmp_eq_u32 s24, 0\ns_cbranch_scc1 .L_custom_skip_S\n',packets[2]['S'],
      packets[2]['advance'],'.L_custom_skip_S:\n',math[1],
      's_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0']
 a=src.index('.L_pair:\n')+len('.L_pair:\n')
 marker='s_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0'
 b=src.index(marker,a)+len(marker)
 return src[:a]+''.join(out)+src[b:]

'''
replace_once("def render_kernel(direction,bm,read_first=0,scalar_address='none',prefetch_order='legacy'):",helper+"def render_kernel(direction,bm,read_first=0,scalar_address='none',prefetch_order='legacy'):")
replace_once(" cfg=kernel_layout(direction,bm,read_first,scalar_address,prefetch_order)\n sp=",r""" cfg=kernel_layout(direction,bm,read_first,scalar_address,prefetch_order)
 if prefetch_order=='split_private_then_shared':
  source,parent=render_kernel(direction,bm,0,scalar_address,'legacy')
  source=re.sub(r'\b'+re.escape(parent['family'])+r'\b',cfg['family'],source)
  return _split_prefetch_source(source,cfg),cfg
 sp=""")
a=src.index('def main(argv=None):')
b=src.index("\nif __name__=='__main__':",a)
main=r'''
def select_for_m(m,policy_path=None):
 """Return the validated exact-M choice. This fixed-N/K tile policy is M129..256."""
 if type(m) is not int:
  raise ValueError('M must be an integer')
 policy=policy_path if isinstance(policy_path,dict) else json.loads(Path(policy_path or R/'tile_schedule_policy.json').read_text())
 scope=policy['scope']
 if (scope['N'],scope['K'])!=(17408,5120):
  raise ValueError('policy shape does not match this fixed-N/K generator')
 lo,hi=scope['M_range']
 if not lo<=m<=hi:
  raise ValueError(f'M must be in the measured policy range {lo}..{hi}')
 if str(m) not in policy['best_by_M']:
  raise ValueError(f'policy has no measured entry for M={m}')
 choice=dict(policy['best_by_M'][str(m)])
 cfg=kernel_layout(choice['direction'],choice['BM'],choice.get('read_first',0),
                   choice.get('scalar_address','none'),choice.get('prefetch_order','legacy'))
 for key in ['family','BN','VGPR','LDS']:
  if key in choice and choice[key]!=cfg[key]:
   raise ValueError(f'policy {key} disagrees with generated layout at M={m}')
 mp=scope['MP']
 if ((m+cfg['BM']-1)//cfg['BM'])*cfg['BM']>mp:
  raise ValueError('policy MP does not cover the selected CTA grid')
 choice.update(M=m,N=scope['N'],K=scope['K'],MP=mp)
 return choice

def main(argv=None):
 import argparse
 ap=argparse.ArgumentParser(description='Generate gfx936 INT8 GEMM CTA tiles; four waves, BN128, N17408, K5120. Does not launch GPU kernels.')
 specs_args=ap.add_mutually_exclusive_group()
 specs_args.add_argument('--variant',action='append',metavar='DIRECTION:BM',help='repeatable, e.g. --variant M:192 --variant N:144')
 specs_args.add_argument('--M',dest='actual_M',action='append',type=int,metavar='M',help='select exact measured best_by_M entry; repeatable and deduplicates shared kernels; defaults to bundled policy')
 ap.add_argument('--output-dir',type=Path,default=DEFAULT_OUTPUT)
 schedule_args=ap.add_mutually_exclusive_group()
 schedule_args.add_argument('--schedule-policy',type=Path,help='measured per-tile or exact-M policy JSON')
 schedule_args.add_argument('--read-first',type=int,default=None,help='legacy: current LDS reads before both prefetches; split: before private prefetch; range 0..SF')
 ap.add_argument('--scalar-address',choices=ADDRESS_MODES,default=None,help='scalarize private/shared/both address paths; default follows policy or none')
 ap.add_argument('--prefetch-order',choices=PREFETCH_ORDERS,default=None,help='legacy, private_first (read-first 0), or split_private_then_shared (Dk,P,Drest,S)')
 ap.add_argument('--check-only',action='store_true',help='print validated resource budgets without writing or assembling files')
 args=ap.parse_args(argv)
 try:
  selected={}
  if args.actual_M:
   if len(args.actual_M)!=len(set(args.actual_M)):raise ValueError('duplicate M values')
   if any(v is not None for v in [args.read_first,args.scalar_address,args.prefetch_order]):
    raise ValueError('--M uses the measured policy; use --variant for manual overrides')
   policy=json.loads((args.schedule_policy or R/'tile_schedule_policy.json').read_text())
   unique={}
   for m in args.actual_M:
    choice=select_for_m(m,policy)
    setting=dict(read_first=choice.get('read_first',0),scalar_address=choice.get('scalar_address','none'),prefetch_order=choice.get('prefetch_order','legacy'))
    cfg=kernel_layout(choice['direction'],choice['BM'],**setting)
    selected[m]=cfg['family']
    unique[cfg['family']]=((choice['direction'],choice['BM']),setting)
   specs=[v[0] for v in unique.values()]
   settings=[v[1] for v in unique.values()]
  else:
   specs=[parse_variant(v) for v in args.variant] if args.variant else [(d,b) for b in [128,256] for d in ['M','N']]
   if len(specs)!=len(set(specs)):raise ValueError('duplicate variants')
   policy={}
   if args.schedule_policy:
    config=json.loads(args.schedule_policy.read_text())
    if (config['scope']['N'],config['scope']['K'])!=(17408,5120):raise ValueError('policy shape does not match this fixed-N/K generator')
    policy=config['tiles']
   settings=[]
   for d,b in specs:
    v=policy.get(f'{d}{b}',{})
    settings.append(dict(read_first=args.read_first if args.read_first is not None else int(v.get('read_first',0)),
                         scalar_address=args.scalar_address if args.scalar_address is not None else v.get('scalar_address','none'),
                         prefetch_order=args.prefetch_order if args.prefetch_order is not None else v.get('prefetch_order','legacy')))
  budgets=[kernel_layout(d,b,**v) for (d,b),v in zip(specs,settings)]
  if selected:
   for v in budgets:v['selected_Ms']=[m for m,f in selected.items() if f==v['family']]
  if args.check_only:
   print(json.dumps(budgets,indent=2));return 0
  base=args.output_dir.resolve()
  if base==R.resolve():raise ValueError('choose a separate output directory; historical measured artifacts are protected')
  if (base/'variants.json').exists():raise ValueError('output variants.json already exists; select a fresh output directory')
  if any((base/v['family']).exists() for v in budgets):raise ValueError('output variant already exists; select a fresh output directory')
  out=[emit(d,b,base,**v) for (d,b),v in zip(specs,settings)]
  if selected:
   for v in out:v['selected_Ms']=[m for m,f in selected.items() if f==v['family']]
   (base/'selection_by_M.json').write_text(json.dumps(dict(scope=policy['scope'],policy=str(args.schedule_policy or R/'tile_schedule_policy.json'),best_by_M=selected),indent=2)+'\n')
  (base/'variants.json').write_text(json.dumps(out,indent=2)+'\n')
  return 0
 except (ValueError,KeyError) as e:
  ap.error(str(e))
'''
src=src[:a]+main+src[b:]
p.write_text(src)
print('PATCHED_STAGE',p,len(src))
