from pathlib import Path
import json,re,ast,importlib.util,subprocess,hashlib
I=Path(__file__).resolve().parent;S=I/'stage'
P=Path('/home/zmoe/src/gemm_asm')
R=Path('/home/metic/gemm-split-prefetch-allm-locked-20261114')
Q=Path('/home/metic/gemm-scalar-address-sweep-locked-20261114')
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
g=load('new_g',S/'tile_generator.py');old=load('old_g',I/'before/tile_generator.py')
tree=ast.parse((R/'build.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='split_render')
env=dict(g=old,re=re)
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(R/'build.py'),'exec'),env)
reference=env['split_render']
old_count=0;new_count=0
for direction,bm in [('M',b) for b in [128,192,256]]+[('N',b) for b in range(128,257,16)]:
 sf=old.kernel_layout(direction,bm)['SF']
 for mode in old.ADDRESS_MODES:
  for k in range(sf+1):
   before,br=old.render_kernel(direction,bm,k,mode,'legacy')
   after,ar=g.render_kernel(direction,bm,k,mode,'legacy')
   assert before==after,(direction,bm,mode,k,'old source')
   old_count+=1
   actual,ar=g.render_kernel(direction,bm,k,mode,'split_private_then_shared')
   expected,er=reference(direction,bm,mode,k)
   expected=re.sub(r'\b'+re.escape(er['family'])+r'\b',ar['family'],expected)
   assert actual==expected,(ar['family'],'split source')
   new_count+=1
  before,_=old.render_kernel(direction,bm,0,mode,'private_first')
  after,_=g.render_kernel(direction,bm,0,mode,'private_first')
  assert before==after;old_count+=1
print('SOURCE_PROOF',old_count,new_count,flush=True)
from elf_tools import elf
new=[]
for ref in json.loads((R/'variants-new.json').read_text()):
 rec=g.emit(ref['direction'],ref['BM'],I/'generated/all-split',ref['read_first_fragments'],ref['scalar_address'],'split_private_then_shared')
 _,e=elf(Path(ref['path']).read_bytes());_,a=elf(Path(rec['path']).read_bytes())
 assert a[rec['function']]['body']==e[ref['function']]['body'],rec['family']
 assert all(rec[k]==ref[k] for k in ['VGPR','SGPR','LDS','scratch','MMAC_per_wave_K64','DS_read_per_wave_K64'])
 new.append(dict(family=rec['family'],measured_family=ref['family'],instruction_bytes_equal=True,body_sha256=hashlib.sha256(a[rec['function']]['body']).hexdigest()))
print('BYTE_PROOF',len(new),flush=True)
args=['python3',str(S/'tile_generator.py'),'--schedule-policy',str(S/'tile_schedule_policy.json'),'--output-dir',str(I/'generated/policy')]
for m in range(129,257):args+=['--M',str(m)]
c=subprocess.run(args,capture_output=True,text=True)
(I/'cli-build.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
policy=json.loads((S/'tile_schedule_policy.json').read_text())
pv=json.loads((I/'generated/policy/variants.json').read_text())
selection=json.loads((I/'generated/policy/selection_by_M.json').read_text())
assert len(selection['best_by_M'])==128
qv={r['family']:r for r in json.loads((Q/'variants.json').read_text())}
rv={r['family']:r for r in json.loads((R/'variants-new.json').read_text())}
for rec in pv:
 measured=next(v for v in policy['best_by_M'].values() if v['family']==rec['family'])
 ref=rv[measured['measured_family']] if 'measured_family' in measured else qv[rec['family']]
 _,a=elf(Path(rec['path']).read_bytes());_,b=elf(Path(ref['path']).read_bytes())
 assert a[rec['function']]['body']==b[ref['function']]['body']
for m in range(129,257):
 assert selection['best_by_M'][str(m)]==g.select_for_m(m,policy)['family']
invalid=0
for m in [0,128,257,1.5,True]:
 try:g.select_for_m(m,policy);raise AssertionError('accepted invalid M')
 except ValueError:invalid+=1
for entry in ['family','VGPR']:
 bad=json.loads(json.dumps(policy));bad['best_by_M']['193'][entry]='bad'
 try:g.select_for_m(193,bad);raise AssertionError('accepted bad policy')
 except ValueError:invalid+=1
for extra in [['--M','193','--variant','N:208'],['--M','193','--scalar-address','none'],['--M','193','--read-first','6'],['--M','193','--M','193']]:
 c=subprocess.run(['python3',str(S/'tile_generator.py'),'--check-only']+extra,capture_output=True,text=True)
 assert c.returncode!=0;invalid+=1
proof=dict(status='passed',unchanged_old_renderings=old_count,split_renderings_equal_independent_reference=new_count,
           compiled_split_functions_equal_validated_experiment=new,policy_compiled_variants=len(pv),exact_M_routes_checked=128,invalid_requests_rejected=invalid)
(I/'integration-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
# Route benchmark uses the exact prior choices and newly generated choices.
small={str(r['M']):r['family'] for r in json.loads(Path('/home/metic/gemm-hbm-l2-util-locked-20261114/RESULT.json').read_text())['rows'] if r['M']<=128}
before_policy=json.loads((I/'before/tile_schedule_policy.json').read_text())
before={str(m):small[str(m)] if m<=128 else before_policy['best_by_M'][str(m)]['family'] for m in range(1,257)}
after={str(m):before[str(m)] if m<=192 else policy['best_by_M'][str(m)]['family'] for m in range(1,257)}
records={}
for rec in pv:
 rec.update(direction=rec['family'][0],kind='split' if rec['prefetch_order']=='split_private_then_shared' else 'old',tile_key=rec['family'].split('_')[0])
 records[rec['family']]=rec
for f in set(before.values()):
 if f not in ['E030','E047'] and f not in records:records[f]=dict(qv[f],kind='old')
assert all(before[str(m)]==after[str(m)] for m in range(1,193))
plan=dict(M_points=list(range(1,257)),before=before,after=after,records=list(records.values()),
 seeds=[202611149101,202611149102,202611149103],rounds=7,copies=72,policy=str(S/'tile_schedule_policy.json'))
(I/'timing-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('INTEGRATION_PROOF',old_count,new_count,len(new),len(pv),invalid,flush=True)
