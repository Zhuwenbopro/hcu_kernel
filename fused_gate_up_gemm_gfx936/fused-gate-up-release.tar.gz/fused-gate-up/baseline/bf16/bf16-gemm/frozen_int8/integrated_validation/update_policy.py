from pathlib import Path
import json,importlib.util,collections,datetime
I=Path(__file__).resolve().parent
S=I/'stage'
R=Path('/home/metic/gemm-split-prefetch-allm-locked-20261114')
spec=importlib.util.spec_from_file_location('staged_generator',S/'tile_generator.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
old=json.loads((I/'before/tile_schedule_policy.json').read_text())
policy=json.loads(json.dumps(old))
result=json.loads((R/'RESULT.json').read_text())
rr={r['family']:r for r in json.loads((R/'variants.json').read_text())}
search=json.loads((R/'search-summary.json').read_text())
def setting(rec):
 return dict(read_first=rec['read_first_fragments'],scalar_address=rec['scalar_address'],prefetch_order=rec['prefetch_order'])
def layout(rec):
 return g.kernel_layout(rec['direction'],rec['BM'],**setting(rec))
changed=[]
for m in range(129,257):
 point=result['points'][str(m)]
 assert old['best_by_M'][str(m)]['family']==point['previous_route']
 if m<=192:continue
 f=point['recommended_family'];rec=rr[f];cfg=layout(rec)
 assert rec['kind']=='split'
 fs=result['data'][str(m)]
 previous=point['previous_route']
 gains={seed:fs[previous]['seeds'][seed]-fs[f]['seeds'][seed] for seed in fs[f]['seeds']}
 assert min(gains.values())>0 and fs[previous]['us']-fs[f]['us']>=.2
 entry={k:cfg[k] for k in ['family','BM','BN','VGPR','SGPR','LDS','scratch','prefetch_order','scalar_address','private_operand','shared_operand','current_reads_before_private','current_reads_before_shared']}
 entry.update(direction=rec['direction'],read_first=cfg['read_first_fragments'],latency_us=point['recommended_us'],
   measured_family=f,previous_implementation=old['best_by_M'][str(m)],
   previous_route_same_run_us=point['previous_route_us'],saved_same_run_us=point['previous_route_us']-point['recommended_us'],
   per_seed_saved_us=gains,measurement=str(R/'confirm-raw.json'))
 policy['best_by_M'][str(m)]=entry
 changed.append(m)
for key in ['N208','N224','N240','N256']:
 default=search['defaults'][key+'_both']['normal']
 rec=rr[default['split']];cfg=layout(rec)
 entry=dict(policy['tiles'][key])
 entry.update({k:cfg[k] for k in ['family','BM','BN','VGPR','LDS','prefetch_order','scalar_address','current_reads_before_private','current_reads_before_shared']})
 entry.update(read_first=cfg['read_first_fragments'],mean_us=default['split_mean_us'],measured_family=rec['family'],
              selection_metric='mean of per-M three-seed medians; prefix selected before independent 72-launch confirmation',
              validation_report=str(R/'REPORT.md'))
 policy['tiles'][key]=entry
assert changed==list(range(193,257))
assert all(policy['best_by_M'][str(m)]==old['best_by_M'][str(m)] for m in range(129,193))
assert all(v==old['tiles'][k] for k,v in policy['tiles'].items() if k not in ['N208','N224','N240','N256'])
ranges=[]
familyranges=[]
for m in range(129,257):
 e=policy['best_by_M'][str(m)]
 if ranges and (ranges[-1]['direction'],ranges[-1]['BM'])==(e['direction'],e['BM']):ranges[-1]['M_end']=m
 else:ranges.append(dict(M_start=m,M_end=m,direction=e['direction'],BM=e['BM']))
 if familyranges and familyranges[-1]['family']==e['family']:familyranges[-1]['M_end']=m
 else:familyranges.append(dict(M_start=m,M_end=m,family=e['family']))
policy.update(status='validated_split_prefetch_per_M',schema_version=2,dispatch_ranges_by_tile=ranges,dispatch_ranges_by_family=familyranges)
policy['scalar_address_validation']=old['validation']
policy['validation']=dict(report=str(I/'REPORT.md'),integration_status='pending',source_experiment=str(R/'REPORT.md'),all_M_CSV=str(I/'bandwidth-M1-256.csv'),
                        source_holdout_seeds=json.loads((R/'confirm-plan.json').read_text())['seeds'],
                        source_selection_seeds=json.loads((R/'search-plan.json').read_text())['seeds'],confirmation='3 seeds x 7 rounds x72 distinct weights;median of seed medians',
                        changed_M_range=[193,256],unchanged_policy_M_range=[129,192],M1_128='existing E030/E047 routes and binaries retained')
policy['notes']=[
 'tiles supplies per-tile defaults; --M / select_for_m consumes the exact best_by_M choice.',
 'Scope remains N17408/K5120/MP256/M129..256. Existing M1..128 E030/E047 routes are retained separately.',
 'M129..192 entries and non-beneficial tile defaults are byte-for-byte unchanged as JSON values.',
 'M193..256 split prefixes were selected on separate seeds and confirmed with gain >=0.2us and positive gain in each of3 seeds.',
 'The generator emits kernels and selection_by_M.json; it does not change the frozen E023/E047 C ABI or model service.'
]
(S/'tile_schedule_policy.json').write_text(json.dumps(policy,indent=2)+'\n')
for m in range(129,257):assert g.select_for_m(m,policy)['family']==policy['best_by_M'][str(m)]['family']
print('POLICY_STAGED',len(changed),ranges)
print('PREFIXES',dict(collections.Counter(e['family'] for k,e in policy['best_by_M'].items() if int(k)>=193)))
