from pathlib import Path
import os,sys,json
R=Path(__file__).resolve().parent
sys.path.insert(0,'/home/zmoe/experiments/int8-bw90-20261110/nodes/S001/plot-deps')
os.environ['MPLCONFIGDIR']=str(R/'mpl-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
font_manager.fontManager.addfont(str(Path('/home/metic/gemm-hbm-l2-util-locked-20261114')/'fonts/NotoSansSC-400.ttf'))
font_manager.fontManager.addfont(str(Path('/home/metic/gemm-hbm-l2-util-locked-20261114')/'fonts/NotoSansSC-700.ttf'))
plt.rcParams.update({'font.family':'Noto Sans SC','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white','figure.facecolor':'white','svg.fonttype':'path'})
j=json.loads((R/'RESULT.json').read_text());d=j['rows'];x=np.array([r['M'] for r in d])
def arr(k):return np.array([r[k] for r in d],dtype=float)
blue='#2563b5';green='#15846b';orange='#c98122';grey='#9da6b3';ink='#293645'
fig,axs=plt.subplots(3,1,figsize=(13.5,10.3),sharex=True,gridspec_kw={'height_ratios':[2.1,1.55,1.15]})
fig.subplots_adjust(left=.075,right=.975,top=.845,bottom=.105,hspace=.25)
fig.suptitle('拆分预取接入后：HBM / L2 输入读取带宽利用率（模型）',x=.5,y=.985,fontsize=18,fontweight='bold',color=ink)
fig.text(.5,.944,'N = 17408   ·   K = 5120   ·   INT8 输入   ·   M = 1–256   ·   核心 1499 MHz / 显存 1800 MHz',ha='center',fontsize=10.5,color='#586574')
a=axs[0]
a.plot(x,arr('HBM_input_util_pct'),color=blue,lw=2.1,label='HBM：X/W 各读一次 ÷ 1.35 TB/s')
a.plot(x,arr('L2_repeat_util_pct'),color=green,lw=2.0,label='L2：只计重复读取 ÷ 4.5 TB/s')
a.plot(x,arr('L2_all_input_util_pct'),color=orange,lw=1.8,ls=(0,(5,2.5)),label='L2：全部输入请求 ÷ 4.5 TB/s')
handles,labels=a.get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.918),ncol=3,frameon=False,fontsize=9.2,columnspacing=2.0)
a.axhline(100,color='#9aa2ad',lw=.9,ls='--')
a.text(255,101.5,'100%',ha='right',fontsize=9,color='#677384')
a.set_ylim(0,108);a.set_yticks([0,20,40,60,80,100]);a.set_ylabel('利用率 / %')
a.set_title('按测得 kernel 延时折算的读取需求率；不是硬件计数器实测占用率',loc='left',pad=9,color=ink)
for m,offset in [(1,2.5),(128,2.3),(192,2.3),(193,-6.2),(256,2.3)]:
 r=d[m-1];val=r['HBM_input_util_pct'];a.scatter([m],[val],s=18,color=blue,zorder=5)
 a.annotate(f"{val:.1f}%",(m,val),xytext=(4 if m==1 else -3 if m==256 else 0,offset*2),textcoords='offset points',ha='left' if m==1 else 'right' if m==256 else 'center',va='bottom' if offset>0 else 'top',fontsize=9,color=blue)
a.text(154,8,f"M193：HBM {j['before_rows'][192]['HBM_input_util_pct']:.1f}% → {d[192]['HBM_input_util_pct']:.1f}%\nL2 全请求 {j['before_rows'][192]['L2_all_input_util_pct']:.1f}% → {d[192]['L2_all_input_util_pct']:.1f}%",fontsize=9,color='#546272',ha='left',bbox=dict(boxstyle='round,pad=.4',facecolor='#f6f8fa',edgecolor='none'))
b=axs[1]
b.stackplot(x,arr('HBM_unique_valid_bytes')/1e6,arr('X_padding_unique_bytes')/1e6,arr('L2_repeat_bytes')/1e6,
 labels=['有效 X/W 首次读取','填充 X 首次读取','X 跨 CTA 重复读取'],colors=[blue,grey,green],alpha=.78)
b.plot(x,arr('input_requested_bytes')/1e6,color='#41505e',lw=.8)
b.set_ylim(0,292);b.set_yticks([0,50,100,150,200,250]);b.set_ylabel('每 kernel 输入请求 / MB')
b.set_title('字节账：软件请求 = 有效首次读取 + 填充首次读取 + 重复读取',loc='left',pad=8,color=ink)
b.legend(loc='upper left',frameon=False,fontsize=9)
b.text(252,15,'当前选中方案 grid_M = 1：W 无重复；重复来自 X',ha='right',fontsize=9,color='white')
c=axs[2]
c.plot(x,[r['latency_us'] for r in j['before_rows']],color='#9da6b3',lw=1.4,ls='--',label='更新前')
c.plot(x,arr('latency_us'),color=ink,lw=1.8,label='更新后')
c.set_ylim(64,100);c.set_yticks([65,75,85,95]);c.set_ylabel('kernel 延时 / µs');c.set_xlabel('M')
c.set_title('同轮锁频复测：M≤192 保留原实现，M≥193 启用拆分预取',loc='left',pad=8,color=ink)
c.legend(loc='upper left',frameon=False,ncol=2,fontsize=9)
jump=d[192]['latency_us']-d[191]['latency_us']
oldjump=j['before_rows'][192]['latency_us']-j['before_rows'][191]['latency_us']
c.annotate(f'192 → 193：+{oldjump:.2f} → +{jump:.2f} µs',xy=(193,d[192]['latency_us']),xytext=(146,96),fontsize=9,color='#a34d3b',arrowprops=dict(arrowstyle='->',color='#a34d3b',lw=1.0))
jump128=d[128]['latency_us']-d[127]['latency_us']
c.annotate(f'128 → 129：+{jump128:.2f} µs',xy=(129,d[128]['latency_us']),xytext=(69,88),fontsize=9,color='#546272',arrowprops=dict(arrowstyle='->',color='#7c8795',lw=.9))
for a in axs:
 a.set_xlim(1,256);a.grid(axis='y',color='#dce1e7',lw=.65,alpha=.85);a.set_axisbelow(True)
 a.tick_params(colors='#52606f')
 for boundary in [128.5,144.5,160.5,176.5,192.5,208.5,224.5,240.5]:
  a.axvline(boundary,color='#d2d8df' if boundary!=192.5 else '#b58a80',lw=.65 if boundary!=192.5 else .9,ls='--',zorder=0)
c.set_xticks([1,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240,256])
fig.text(.075,.048,'HBM 主曲线只计有效 X/W 各读取一次；L2 实线只计严格重复，虚线计全部输入请求。填充首次读单列，INT32 输出写入不计入主图。',fontsize=9,color='#586574')
fig.text(.075,.025,'每点：3 seed × 7 轮 × 每图 72 组独立权重；新旧同轮测量。M≤192 沿用原实现，数据未平滑、未插值。TB/s = 10¹² B/s。',fontsize=8.8,color='#586574')
fig.savefig(R/'bandwidth-M1-256.png',dpi=160)
fig.savefig(R/'bandwidth-M1-256.svg')
plt.close(fig)
print('PLOTTED',[(p.name,p.stat().st_size) for p in [R/'bandwidth-M1-256.png',R/'bandwidth-M1-256.svg']])

# Separate zoomed comparison keeps all three modeled bandwidth definitions.
old=j['before_rows']
def oldarr(k):return np.array([r[k] for r in old],dtype=float)
fig2,aa=plt.subplots(2,1,figsize=(13.5,7.4),sharex=True,gridspec_kw={'height_ratios':[1,1.1]})
fig2.subplots_adjust(left=.075,right=.975,top=.87,bottom=.13,hspace=.23)
fig2.suptitle('\u62c6\u5206\u9884\u53d6\uff1a\u6309 M \u66f4\u65b0\u524d\u540e\uff08\u540c\u8f6e\u9501\u9891\u590d\u6d4b\uff09',y=.985,fontsize=18,fontweight='bold',color=ink)
fig2.text(.5,.932,'N = 17408  \u00b7  K = 5120  \u00b7  \u6838\u5fc3 1499 MHz / \u663e\u5b58 1800 MHz  \u00b7  M\u2264192 \u4fdd\u7559\u539f\u5b9e\u73b0',ha='center',fontsize=10.5,color='#586574')
a=aa[0]
a.plot(x,oldarr('latency_us'),color='#7c8795',ls='--',lw=1.8,label='\u66f4\u65b0\u524d\u539f\u8def\u7531')
a.plot(x,arr('latency_us'),color=blue,lw=2.0,label='\u66f4\u65b0\u540e\u8def\u7531')
a.set_ylim(73,98);a.set_yticks([75,80,85,90,95]);a.set_ylabel('kernel \u5ef6\u65f6 / \u00b5s')
a.legend(loc='upper left',ncol=2,frameon=False,fontsize=9.5)
a.annotate(f"M193\uff1a{old[192]['latency_us']:.2f} \u2192 {d[192]['latency_us']:.2f} \u00b5s",xy=(193,d[192]['latency_us']),xytext=(148,94),color=blue,fontsize=10,arrowprops=dict(arrowstyle='->',color=blue))
a.text(252,75.4,f"192\u2192193 \u8df3\u53d8\uff1a{j['jump_192_193']['before_us']:.2f} \u2192 {j['jump_192_193']['after_us']:.2f} \u00b5s",ha='right',fontsize=10,color=ink)
b=aa[1]
for key,color,label in [('HBM_input_util_pct',blue,'HBM'),('L2_all_input_util_pct',orange,'L2 \u5168\u8bf7\u6c42'),('L2_repeat_util_pct',green,'L2 \u91cd\u590d')]:
 b.plot(x,oldarr(key),color=color,alpha=.45,lw=1.4,ls='--',label=label+'\uff1a\u66f4\u65b0\u524d')
 b.plot(x,arr(key),color=color,lw=1.9,label=label+'\uff1a\u66f4\u65b0\u540e')
b.set_ylim(24,94);b.set_yticks([30,40,50,60,70,80,90]);b.set_ylabel('\u5229\u7528\u7387\u6a21\u578b / %');b.set_xlabel('M')
b.legend(loc='lower right',bbox_to_anchor=(.995,.025),ncol=3,frameon=False,fontsize=8.5,columnspacing=1.4)
for a in aa:
 a.set_xlim(128,256);a.set_xticks([128,144,160,176,192,208,224,240,256]);a.grid(axis='y',color='#dce1e7',lw=.65);a.set_axisbelow(True);a.tick_params(colors='#52606f')
 for boundary in [144.5,160.5,176.5,192.5,208.5,224.5,240.5]:
  a.axvline(boundary,color='#d2d8df' if boundary!=192.5 else '#b58a80',lw=.65,ls='--',zorder=0)
fig2.text(.075,.057,'HBM \u4e0a\u9650 1.35 TB/s\uff0cL2 \u4e0a\u9650 4.5 TB/s\uff1b\u5747\u6309\u8f6f\u4ef6\u8f93\u5165\u8bfb\u53d6\u5b57\u8282 \u00f7 \u5b9e\u6d4b\u5ef6\u65f6\u6298\u7b97\uff0c\u975e\u786c\u4ef6\u8ba1\u6570\u5668\u5360\u7528\u7387\u3002',fontsize=9,color='#586574')
fig2.text(.075,.027,'\u672c\u6b21\u66f4\u65b0\u524d\u540e\u8f93\u5165\u8bf7\u6c42\u5b57\u8282\u6570\u76f8\u540c\uff1b\u53ea\u66ff\u6362 M193\u2013256 \u7684\u6709\u6536\u76ca\u65b9\u6848\u3002INT32 \u8f93\u51fa\u5199\u5165\u4e0d\u8ba1\u5165\u5e26\u5bbd\u4e3b\u66f2\u7ebf\u3002',fontsize=9,color='#586574')
fig2.savefig(R/'before-after-M128-256.png',dpi=160)
fig2.savefig(R/'before-after-M128-256.svg')
plt.close(fig2)
print('COMPARISON_PLOTTED')
