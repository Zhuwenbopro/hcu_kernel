> [METRIC_CORRECTION_TOTAL_IO] 用户已更正主指标为总有效IO=(MK+NK+4MN)/时间，W-only仅作辅助。四个正式形状与S001五候选最快的256个形状均已过总IO90%；旧W门槛保留为历史，统一定义见 /home/zmoe/experiments/int8-bw90-20261110/METRICS.md。

# 当前验收候选
来源与精确构建参数见每个子目录plan.json。kernel.so从已经验收的节点复制，未重新编译。
E023: full N34816/K5120，M32及M128，W REG + X LDS共享，每K64一处barrier。
E030: TP2 N17408/K5120，M32，主环X/W REG，CTA内K二分，末尾一次LDS INT32归约。
E025: M32 full的完全REG替代支路（0LDS/0barrier），正确且90%+，但不如E023快。
输入打包必须使用tools/common.py的pack(x, BM)、pack_weight(w, True)。PI16布局与K64分组已在全部输出中验证。不可把未打包行优先tensor直接传入。
zmoe_launch的参数/返回值在source.cu；zmoe_info给出BM/BN/寄存器/LDS。要求N整除对应BN、K>=64且K整除64。形状超过正式验收范围不作90%保证。
E047: TP2 M128的当前最快候选，X REG、W LDS共享、连续带glc/slc的i32写回，附固定shape特化及通用回退。
正式证据见../REPORT.md、../nodes/F001和F002。TP2 M128的严格W约88.1%，尚未90%；逻辑总读写约97.5%，单独列明，不能当作W97.5%。


<!-- COMMON_ASM_CURRENT_20261113 -->
## 当前E023/E047公共汇编入口

当前实现由/home/zmoe/src/gemm_asm/common_gfx936.inc和e023.s/e047.s构建，登记见current_asm.json。tools/common.py的current_library加载并校验当前SO；本目录原source.cu/kernel.so保留作冻结对照，历史library(path)不重定向。8点性能对齐及指令证明见/home/metic/gemm-common-asm-20261113/REPORT.md。E030等其它分支保持原路径。
