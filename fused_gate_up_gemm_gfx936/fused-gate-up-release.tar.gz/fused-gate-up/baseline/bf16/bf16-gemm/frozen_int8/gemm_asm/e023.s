; Shared primitive refactor. Original addresses/registers/schedule retained.
.include "common_gfx936.inc"
	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z8reg_E023PKaS0_Piiiii ; -- Begin function _Z8reg_E023PKaS0_Piiiii
	.globl	_Z8reg_E023PKaS0_Piiiii
	.p2align	8
	.type	_Z8reg_E023PKaS0_Piiiii,@function
_Z8reg_E023PKaS0_Piiiii:                ; @_Z8reg_E023PKaS0_Piiiii
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x18
	s_load_dwordx2 s[16:17], s[4:5], 0x10
	v_mov_b32_e32 v4, 0
	v_and_b32_e32 v132, 0xc0, v0
	s_mov_b32 s8, 0
	GEMM_WAIT_LGKM 0
	s_cmp_lt_i32 s2, 64
	v_mov_b32_e32 v3, v4
	v_mov_b32_e32 v2, v4
	v_mov_b32_e32 v1, v4
	v_mov_b32_e32 v8, v4
	v_mov_b32_e32 v7, v4
	v_mov_b32_e32 v6, v4
	v_mov_b32_e32 v5, v4
	v_mov_b32_e32 v12, v4
	v_mov_b32_e32 v11, v4
	v_mov_b32_e32 v10, v4
	v_mov_b32_e32 v9, v4
	v_mov_b32_e32 v16, v4
	v_mov_b32_e32 v15, v4
	v_mov_b32_e32 v14, v4
	v_mov_b32_e32 v13, v4
	v_mov_b32_e32 v20, v4
	v_mov_b32_e32 v19, v4
	v_mov_b32_e32 v18, v4
	v_mov_b32_e32 v17, v4
	v_mov_b32_e32 v24, v4
	v_mov_b32_e32 v23, v4
	v_mov_b32_e32 v22, v4
	v_mov_b32_e32 v21, v4
	v_mov_b32_e32 v28, v4
	v_mov_b32_e32 v27, v4
	v_mov_b32_e32 v26, v4
	v_mov_b32_e32 v25, v4
	v_mov_b32_e32 v32, v4
	v_mov_b32_e32 v31, v4
	v_mov_b32_e32 v30, v4
	v_mov_b32_e32 v29, v4
	v_mov_b32_e32 v40, v4
	v_mov_b32_e32 v39, v4
	v_mov_b32_e32 v38, v4
	v_mov_b32_e32 v37, v4
	v_mov_b32_e32 v52, v4
	v_mov_b32_e32 v51, v4
	v_mov_b32_e32 v50, v4
	v_mov_b32_e32 v49, v4
	v_mov_b32_e32 v68, v4
	v_mov_b32_e32 v67, v4
	v_mov_b32_e32 v66, v4
	v_mov_b32_e32 v65, v4
	v_mov_b32_e32 v36, v4
	v_mov_b32_e32 v35, v4
	v_mov_b32_e32 v34, v4
	v_mov_b32_e32 v33, v4
	v_mov_b32_e32 v48, v4
	v_mov_b32_e32 v47, v4
	v_mov_b32_e32 v46, v4
	v_mov_b32_e32 v45, v4
	v_mov_b32_e32 v64, v4
	v_mov_b32_e32 v63, v4
	v_mov_b32_e32 v62, v4
	v_mov_b32_e32 v61, v4
	v_mov_b32_e32 v84, v4
	v_mov_b32_e32 v83, v4
	v_mov_b32_e32 v82, v4
	v_mov_b32_e32 v81, v4
	v_mov_b32_e32 v44, v4
	v_mov_b32_e32 v43, v4
	v_mov_b32_e32 v42, v4
	v_mov_b32_e32 v41, v4
	v_mov_b32_e32 v60, v4
	v_mov_b32_e32 v59, v4
	v_mov_b32_e32 v58, v4
	v_mov_b32_e32 v57, v4
	v_mov_b32_e32 v80, v4
	v_mov_b32_e32 v79, v4
	v_mov_b32_e32 v78, v4
	v_mov_b32_e32 v77, v4
	v_mov_b32_e32 v100, v4
	v_mov_b32_e32 v99, v4
	v_mov_b32_e32 v98, v4
	v_mov_b32_e32 v97, v4
	v_mov_b32_e32 v56, v4
	v_mov_b32_e32 v55, v4
	v_mov_b32_e32 v54, v4
	v_mov_b32_e32 v53, v4
	v_mov_b32_e32 v76, v4
	v_mov_b32_e32 v75, v4
	v_mov_b32_e32 v74, v4
	v_mov_b32_e32 v73, v4
	v_mov_b32_e32 v96, v4
	v_mov_b32_e32 v95, v4
	v_mov_b32_e32 v94, v4
	v_mov_b32_e32 v93, v4
	v_mov_b32_e32 v116, v4
	v_mov_b32_e32 v115, v4
	v_mov_b32_e32 v114, v4
	v_mov_b32_e32 v113, v4
	v_mov_b32_e32 v72, v4
	v_mov_b32_e32 v71, v4
	v_mov_b32_e32 v70, v4
	v_mov_b32_e32 v69, v4
	v_mov_b32_e32 v92, v4
	v_mov_b32_e32 v91, v4
	v_mov_b32_e32 v90, v4
	v_mov_b32_e32 v89, v4
	v_mov_b32_e32 v112, v4
	v_mov_b32_e32 v111, v4
	v_mov_b32_e32 v110, v4
	v_mov_b32_e32 v109, v4
	v_mov_b32_e32 v124, v4
	v_mov_b32_e32 v123, v4
	v_mov_b32_e32 v122, v4
	v_mov_b32_e32 v121, v4
	v_mov_b32_e32 v88, v4
	v_mov_b32_e32 v87, v4
	v_mov_b32_e32 v86, v4
	v_mov_b32_e32 v85, v4
	v_mov_b32_e32 v108, v4
	v_mov_b32_e32 v107, v4
	v_mov_b32_e32 v106, v4
	v_mov_b32_e32 v105, v4
	v_mov_b32_e32 v120, v4
	v_mov_b32_e32 v119, v4
	v_mov_b32_e32 v118, v4
	v_mov_b32_e32 v117, v4
	v_mov_b32_e32 v128, v4
	v_mov_b32_e32 v127, v4
	v_mov_b32_e32 v126, v4
	v_mov_b32_e32 v125, v4
	v_mov_b32_e32 v104, v4
	v_mov_b32_e32 v103, v4
	v_mov_b32_e32 v102, v4
	v_mov_b32_e32 v101, v4
	v_lshl_or_b32 v131, s6, 8, v132
	s_cbranch_scc1 .LBB0_3
; %bb.1:
	s_load_dwordx4 s[12:15], s[4:5], 0x0
	s_ashr_i32 s4, s2, 31
	s_lshr_b32 s4, s4, 26
	s_add_i32 s2, s2, s4
	v_ashrrev_i32_e32 v1, 4, v131
	s_ashr_i32 s4, s2, 6
	s_ashr_i32 s2, s3, 31
	v_ashrrev_i32_e32 v2, 31, v1
	s_lshr_b32 s2, s2, 28
	v_lshlrev_b64 v[1:2], 10, v[1:2]
	s_add_i32 s5, s3, s2
	s_ashr_i32 s2, s1, 31
	v_and_b32_e32 v133, 63, v0
	GEMM_WAIT_LGKM 0
	v_mov_b32_e32 v3, s15
	v_add_co_u32_e32 v1, vcc, s14, v1
	s_lshr_b32 s2, s2, 28
	v_addc_co_u32_e32 v2, vcc, v3, v2, vcc
	v_lshlrev_b32_e32 v3, 4, v133
	s_add_i32 s2, s1, s2
	v_add_co_u32_e32 v129, vcc, v1, v3
	v_lshlrev_b32_e32 v1, 4, v0
	s_ashr_i32 s2, s2, 4
	v_lshl_or_b32 v134, s7, 13, v1
	s_ashr_i32 s3, s2, 31
	s_lshl_b32 s5, s5, 6
	v_mov_b32_e32 v1, 0
	v_addc_co_u32_e32 v130, vcc, 0, v2, vcc
	s_add_i32 s13, s13, 4.0
	s_mov_b32 s15, 0x20000
	s_brev_b32 s14, 1
	s_lshl_b64 s[2:3], s[2:3], 10
	s_and_b32 s5, s5, 0xfffffc00
	s_movk_i32 s6, 0x400
	s_movk_i32 s18, 0x800
	s_movk_i32 s19, 0xc00
	s_mov_b32 s20, 0
	v_mov_b32_e32 v2, v1
	v_mov_b32_e32 v3, v1
	v_mov_b32_e32 v4, v1
	v_mov_b32_e32 v5, v1
	v_mov_b32_e32 v6, v1
	v_mov_b32_e32 v7, v1
	v_mov_b32_e32 v8, v1
	v_mov_b32_e32 v9, v1
	v_mov_b32_e32 v10, v1
	v_mov_b32_e32 v11, v1
	v_mov_b32_e32 v12, v1
	v_mov_b32_e32 v13, v1
	v_mov_b32_e32 v14, v1
	v_mov_b32_e32 v15, v1
	v_mov_b32_e32 v16, v1
	v_mov_b32_e32 v17, v1
	v_mov_b32_e32 v18, v1
	v_mov_b32_e32 v19, v1
	v_mov_b32_e32 v20, v1
	v_mov_b32_e32 v21, v1
	v_mov_b32_e32 v22, v1
	v_mov_b32_e32 v23, v1
	v_mov_b32_e32 v24, v1
	v_mov_b32_e32 v25, v1
	v_mov_b32_e32 v26, v1
	v_mov_b32_e32 v27, v1
	v_mov_b32_e32 v28, v1
	v_mov_b32_e32 v29, v1
	v_mov_b32_e32 v30, v1
	v_mov_b32_e32 v31, v1
	v_mov_b32_e32 v32, v1
	v_mov_b32_e32 v37, v1
	v_mov_b32_e32 v38, v1
	v_mov_b32_e32 v39, v1
	v_mov_b32_e32 v40, v1
	v_mov_b32_e32 v49, v1
	v_mov_b32_e32 v50, v1
	v_mov_b32_e32 v51, v1
	v_mov_b32_e32 v52, v1
	v_mov_b32_e32 v65, v1
	v_mov_b32_e32 v66, v1
	v_mov_b32_e32 v67, v1
	v_mov_b32_e32 v68, v1
	v_mov_b32_e32 v33, v1
	v_mov_b32_e32 v34, v1
	v_mov_b32_e32 v35, v1
	v_mov_b32_e32 v36, v1
	v_mov_b32_e32 v45, v1
	v_mov_b32_e32 v46, v1
	v_mov_b32_e32 v47, v1
	v_mov_b32_e32 v48, v1
	v_mov_b32_e32 v61, v1
	v_mov_b32_e32 v62, v1
	v_mov_b32_e32 v63, v1
	v_mov_b32_e32 v64, v1
	v_mov_b32_e32 v81, v1
	v_mov_b32_e32 v82, v1
	v_mov_b32_e32 v83, v1
	v_mov_b32_e32 v84, v1
	v_mov_b32_e32 v41, v1
	v_mov_b32_e32 v42, v1
	v_mov_b32_e32 v43, v1
	v_mov_b32_e32 v44, v1
	v_mov_b32_e32 v57, v1
	v_mov_b32_e32 v58, v1
	v_mov_b32_e32 v59, v1
	v_mov_b32_e32 v60, v1
	v_mov_b32_e32 v77, v1
	v_mov_b32_e32 v78, v1
	v_mov_b32_e32 v79, v1
	v_mov_b32_e32 v80, v1
	v_mov_b32_e32 v97, v1
	v_mov_b32_e32 v98, v1
	v_mov_b32_e32 v99, v1
	v_mov_b32_e32 v100, v1
	v_mov_b32_e32 v53, v1
	v_mov_b32_e32 v54, v1
	v_mov_b32_e32 v55, v1
	v_mov_b32_e32 v56, v1
	v_mov_b32_e32 v73, v1
	v_mov_b32_e32 v74, v1
	v_mov_b32_e32 v75, v1
	v_mov_b32_e32 v76, v1
	v_mov_b32_e32 v93, v1
	v_mov_b32_e32 v94, v1
	v_mov_b32_e32 v95, v1
	v_mov_b32_e32 v96, v1
	v_mov_b32_e32 v113, v1
	v_mov_b32_e32 v114, v1
	v_mov_b32_e32 v115, v1
	v_mov_b32_e32 v116, v1
	v_mov_b32_e32 v69, v1
	v_mov_b32_e32 v70, v1
	v_mov_b32_e32 v71, v1
	v_mov_b32_e32 v72, v1
	v_mov_b32_e32 v89, v1
	v_mov_b32_e32 v90, v1
	v_mov_b32_e32 v91, v1
	v_mov_b32_e32 v92, v1
	v_mov_b32_e32 v109, v1
	v_mov_b32_e32 v110, v1
	v_mov_b32_e32 v111, v1
	v_mov_b32_e32 v112, v1
	v_mov_b32_e32 v121, v1
	v_mov_b32_e32 v122, v1
	v_mov_b32_e32 v123, v1
	v_mov_b32_e32 v124, v1
	v_mov_b32_e32 v85, v1
	v_mov_b32_e32 v86, v1
	v_mov_b32_e32 v87, v1
	v_mov_b32_e32 v88, v1
	v_mov_b32_e32 v105, v1
	v_mov_b32_e32 v106, v1
	v_mov_b32_e32 v107, v1
	v_mov_b32_e32 v108, v1
	v_mov_b32_e32 v117, v1
	v_mov_b32_e32 v118, v1
	v_mov_b32_e32 v119, v1
	v_mov_b32_e32 v120, v1
	v_mov_b32_e32 v125, v1
	v_mov_b32_e32 v126, v1
	v_mov_b32_e32 v127, v1
	v_mov_b32_e32 v128, v1
	v_mov_b32_e32 v101, v1
	v_mov_b32_e32 v102, v1
	v_mov_b32_e32 v103, v1
	v_mov_b32_e32 v104, v1
.LBB0_2:                                ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s10, s8
	s_mov_b32 s11, s8
	s_mov_b32 s9, s8
	v_mov_b64_e32 v[137:138], s[10:11]
	v_mov_b64_e32 v[135:136], s[8:9]
	v_mov_b64_e32 v[141:142], v[137:138]
	v_mov_b64_e32 v[139:140], v[135:136]
	;;#ASMSTART
	GEMM_W_GLOBAL_TO_REG v[139:142], v[129:130]
	;;#ASMEND
	v_add_co_u32_e32 v147, vcc, s6, v129
	v_mov_b64_e32 v[145:146], v[137:138]
	v_addc_co_u32_e32 v148, vcc, 0, v130, vcc
	v_mov_b64_e32 v[143:144], v[135:136]
	;;#ASMSTART
	GEMM_W_GLOBAL_TO_REG v[143:146], v[147:148]
	;;#ASMEND
	v_add_co_u32_e32 v151, vcc, s18, v129
	v_mov_b64_e32 v[149:150], v[137:138]
	v_addc_co_u32_e32 v152, vcc, 0, v130, vcc
	v_mov_b64_e32 v[147:148], v[135:136]
	;;#ASMSTART
	GEMM_W_GLOBAL_TO_REG v[147:150], v[151:152]
	;;#ASMEND
	v_add_co_u32_e32 v151, vcc, s19, v129
	v_addc_co_u32_e32 v152, vcc, 0, v130, vcc
	;;#ASMSTART
	GEMM_W_GLOBAL_TO_REG v[135:138], v[151:152]
	;;#ASMEND
	s_and_b32 s9, s20, 0x200
	v_or_b32_e32 v151, s9, v132
	v_lshlrev_b32_e32 v151, 4, v151
	v_readfirstlane_b32 s10, v151
	v_or_b32_e32 v151, 0x1000, v151
	s_mov_b32 m0, s10
	v_readfirstlane_b32 s10, v151
	GEMM_X_GLOBAL_TO_LDS v134, s[12:15], 0
	v_add_u32_e32 v152, 0x1000, v134
	s_mov_b32 m0, s10
	s_nop 0
	GEMM_X_GLOBAL_TO_LDS v152, s[12:15], 0
	;;#ASMSTART
	GEMM_WAIT_VM 0
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	GEMM_WAIT_LGKM 0
	;;#ASMSTART
	GEMM_CTA_BARRIER
	;;#ASMEND
	v_or_b32_e32 v151, s9, v133
	v_lshlrev_b32_e32 v179, 4, v151
	GEMM_WAIT_VM 0
	GEMM_LDS_TO_REG v[151:154], v179, 0
	GEMM_LDS_TO_REG v[155:158], v179, 1024
	GEMM_LDS_TO_REG v[159:162], v179, 2048
	GEMM_LDS_TO_REG v[163:166], v179, 3072
	GEMM_LDS_TO_REG v[167:170], v179, 4096
	GEMM_LDS_TO_REG v[171:174], v179, 5120
	GEMM_LDS_TO_REG v[175:178], v179, 6144
	GEMM_LDS_TO_REG v[179:182], v179, 7168
	GEMM_WAIT_LGKM 7
	GEMM_MMA_I8 v[29:32], v[151:152], v[139:140], v[29:32]
	GEMM_MMA_I8 v[37:40], v[151:152], v[143:144], v[37:40]
	GEMM_MMA_I8 v[49:52], v[151:152], v[147:148], v[49:52]
	GEMM_MMA_I8 v[65:68], v[151:152], v[135:136], v[65:68]
	GEMM_WAIT_LGKM 6
	GEMM_MMA_I8 v[33:36], v[155:156], v[139:140], v[33:36]
	GEMM_MMA_I8 v[45:48], v[155:156], v[143:144], v[45:48]
	GEMM_MMA_I8 v[61:64], v[155:156], v[147:148], v[61:64]
	GEMM_MMA_I8 v[81:84], v[155:156], v[135:136], v[81:84]
	GEMM_WAIT_LGKM 5
	GEMM_MMA_I8 v[41:44], v[159:160], v[139:140], v[41:44]
	GEMM_MMA_I8 v[57:60], v[159:160], v[143:144], v[57:60]
	GEMM_MMA_I8 v[77:80], v[159:160], v[147:148], v[77:80]
	GEMM_MMA_I8 v[97:100], v[159:160], v[135:136], v[97:100]
	GEMM_WAIT_LGKM 4
	GEMM_MMA_I8 v[53:56], v[163:164], v[139:140], v[53:56]
	GEMM_MMA_I8 v[73:76], v[163:164], v[143:144], v[73:76]
	GEMM_MMA_I8 v[93:96], v[163:164], v[147:148], v[93:96]
	GEMM_MMA_I8 v[113:116], v[163:164], v[135:136], v[113:116]
	GEMM_WAIT_LGKM 3
	GEMM_MMA_I8 v[69:72], v[167:168], v[139:140], v[69:72]
	GEMM_MMA_I8 v[89:92], v[167:168], v[143:144], v[89:92]
	GEMM_MMA_I8 v[109:112], v[167:168], v[147:148], v[109:112]
	GEMM_MMA_I8 v[121:124], v[167:168], v[135:136], v[121:124]
	GEMM_WAIT_LGKM 2
	GEMM_MMA_I8 v[85:88], v[171:172], v[139:140], v[85:88]
	GEMM_MMA_I8 v[105:108], v[171:172], v[143:144], v[105:108]
	GEMM_MMA_I8 v[117:120], v[171:172], v[147:148], v[117:120]
	GEMM_MMA_I8 v[125:128], v[171:172], v[135:136], v[125:128]
	GEMM_WAIT_LGKM 1
	GEMM_MMA_I8 v[101:104], v[175:176], v[139:140], v[101:104]
	GEMM_MMA_I8 v[25:28], v[175:176], v[143:144], v[25:28]
	GEMM_MMA_I8 v[21:24], v[175:176], v[147:148], v[21:24]
	GEMM_MMA_I8 v[17:20], v[175:176], v[135:136], v[17:20]
	GEMM_WAIT_LGKM 0
	GEMM_MMA_I8 v[13:16], v[179:180], v[139:140], v[13:16]
	GEMM_MMA_I8 v[9:12], v[179:180], v[143:144], v[9:12]
	GEMM_MMA_I8 v[5:8], v[179:180], v[147:148], v[5:8]
	GEMM_MMA_I8 v[1:4], v[179:180], v[135:136], v[1:4]
	s_add_i32 s4, s4, -1
	s_addk_i32 s20, 0x200
	v_mov_b32_e32 v135, s3
	v_add_co_u32_e32 v129, vcc, s2, v129
	GEMM_MMA_I8 v[29:32], v[153:154], v[141:142], v[29:32]
	GEMM_MMA_I8 v[37:40], v[153:154], v[145:146], v[37:40]
	GEMM_MMA_I8 v[49:52], v[153:154], v[149:150], v[49:52]
	GEMM_MMA_I8 v[65:68], v[153:154], v[137:138], v[65:68]
	GEMM_MMA_I8 v[33:36], v[157:158], v[141:142], v[33:36]
	GEMM_MMA_I8 v[45:48], v[157:158], v[145:146], v[45:48]
	GEMM_MMA_I8 v[61:64], v[157:158], v[149:150], v[61:64]
	GEMM_MMA_I8 v[81:84], v[157:158], v[137:138], v[81:84]
	GEMM_MMA_I8 v[41:44], v[161:162], v[141:142], v[41:44]
	GEMM_MMA_I8 v[57:60], v[161:162], v[145:146], v[57:60]
	GEMM_MMA_I8 v[77:80], v[161:162], v[149:150], v[77:80]
	GEMM_MMA_I8 v[97:100], v[161:162], v[137:138], v[97:100]
	GEMM_MMA_I8 v[53:56], v[165:166], v[141:142], v[53:56]
	GEMM_MMA_I8 v[73:76], v[165:166], v[145:146], v[73:76]
	GEMM_MMA_I8 v[93:96], v[165:166], v[149:150], v[93:96]
	GEMM_MMA_I8 v[113:116], v[165:166], v[137:138], v[113:116]
	GEMM_MMA_I8 v[69:72], v[169:170], v[141:142], v[69:72]
	GEMM_MMA_I8 v[89:92], v[169:170], v[145:146], v[89:92]
	GEMM_MMA_I8 v[109:112], v[169:170], v[149:150], v[109:112]
	GEMM_MMA_I8 v[121:124], v[169:170], v[137:138], v[121:124]
	GEMM_MMA_I8 v[85:88], v[173:174], v[141:142], v[85:88]
	GEMM_MMA_I8 v[105:108], v[173:174], v[145:146], v[105:108]
	GEMM_MMA_I8 v[117:120], v[173:174], v[149:150], v[117:120]
	GEMM_MMA_I8 v[125:128], v[173:174], v[137:138], v[125:128]
	GEMM_MMA_I8 v[101:104], v[177:178], v[141:142], v[101:104]
	GEMM_MMA_I8 v[25:28], v[177:178], v[145:146], v[25:28]
	GEMM_MMA_I8 v[21:24], v[177:178], v[149:150], v[21:24]
	GEMM_MMA_I8 v[17:20], v[177:178], v[137:138], v[17:20]
	GEMM_MMA_I8 v[13:16], v[181:182], v[141:142], v[13:16]
	GEMM_MMA_I8 v[9:12], v[181:182], v[145:146], v[9:12]
	GEMM_MMA_I8 v[5:8], v[181:182], v[149:150], v[5:8]
	GEMM_MMA_I8 v[1:4], v[181:182], v[137:138], v[1:4]
	v_add_u32_e32 v134, s5, v134
	s_cmp_eq_u32 s4, 0
	v_addc_co_u32_e32 v130, vcc, v130, v135, vcc
	GEMM_WAIT_LGKM 0
	s_cbranch_scc0 .LBB0_2
.LBB0_3:
	s_lshl_b32 s4, s7, 7
	v_and_b32_e32 v129, 15, v0
	v_or_b32_e32 v132, s4, v129
	v_cmp_gt_i32_e32 vcc, s0, v132
	v_lshrrev_b32_e32 v130, 2, v0
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_5
; %bb.4:
	v_mad_i64_i32 v[132:133], s[6:7], s1, v132, 0
	v_and_or_b32 v134, v130, 12, v131
	v_mov_b32_e32 v135, s17
	v_lshlrev_b64 v[132:133], 2, v[132:133]
	v_add_co_u32_e32 v136, vcc, s16, v132
	v_addc_co_u32_e32 v137, vcc, v135, v133, vcc
	v_ashrrev_i32_e32 v135, 31, v134
	v_lshlrev_b64 v[132:133], 2, v[134:135]
	v_add_co_u32_e32 v132, vcc, v136, v132
	v_addc_co_u32_e32 v133, vcc, v137, v133, vcc
	GEMM_EPILOGUE_STORE v[132:133], v[29:32], 0
	GEMM_EPILOGUE_STORE v[132:133], v[37:40], 64
	GEMM_EPILOGUE_STORE v[132:133], v[49:52], 128
	GEMM_EPILOGUE_STORE v[132:133], v[65:68], 192
.LBB0_5:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 16
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_7
; %bb.6:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_and_or_b32 v31, v130, 12, v131
	v_mov_b32_e32 v32, s17
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_add_co_u32_e32 v37, vcc, s16, v29
	v_addc_co_u32_e32 v38, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v37, v29
	v_addc_co_u32_e32 v30, vcc, v38, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[33:36], 0
	GEMM_EPILOGUE_STORE v[29:30], v[45:48], 64
	GEMM_EPILOGUE_STORE v[29:30], v[61:64], 128
	GEMM_EPILOGUE_STORE v[29:30], v[81:84], 192
.LBB0_7:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 32
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_9
; %bb.8:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_lshrrev_b32_e32 v31, 2, v0
	v_and_or_b32 v31, v31, 12, v131
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_mov_b32_e32 v32, s17
	v_add_co_u32_e32 v33, vcc, s16, v29
	v_addc_co_u32_e32 v34, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v33, v29
	v_addc_co_u32_e32 v30, vcc, v34, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[41:44], 0
	GEMM_EPILOGUE_STORE v[29:30], v[57:60], 64
	GEMM_EPILOGUE_STORE v[29:30], v[77:80], 128
	GEMM_EPILOGUE_STORE v[29:30], v[97:100], 192
.LBB0_9:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 48
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_11
; %bb.10:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_lshrrev_b32_e32 v31, 2, v0
	v_and_or_b32 v31, v31, 12, v131
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_mov_b32_e32 v32, s17
	v_add_co_u32_e32 v33, vcc, s16, v29
	v_addc_co_u32_e32 v34, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v33, v29
	v_addc_co_u32_e32 v30, vcc, v34, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[53:56], 0
	GEMM_EPILOGUE_STORE v[29:30], v[73:76], 64
	GEMM_EPILOGUE_STORE v[29:30], v[93:96], 128
	GEMM_EPILOGUE_STORE v[29:30], v[113:116], 192
.LBB0_11:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 64
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_13
; %bb.12:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_lshrrev_b32_e32 v31, 2, v0
	v_and_or_b32 v31, v31, 12, v131
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_mov_b32_e32 v32, s17
	v_add_co_u32_e32 v33, vcc, s16, v29
	v_addc_co_u32_e32 v34, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v33, v29
	v_addc_co_u32_e32 v30, vcc, v34, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[69:72], 0
	GEMM_EPILOGUE_STORE v[29:30], v[89:92], 64
	GEMM_EPILOGUE_STORE v[29:30], v[109:112], 128
	GEMM_EPILOGUE_STORE v[29:30], v[121:124], 192
.LBB0_13:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 0x50
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_15
; %bb.14:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_lshrrev_b32_e32 v31, 2, v0
	v_and_or_b32 v31, v31, 12, v131
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_mov_b32_e32 v32, s17
	v_add_co_u32_e32 v33, vcc, s16, v29
	v_addc_co_u32_e32 v34, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v33, v29
	v_addc_co_u32_e32 v30, vcc, v34, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[85:88], 0
	GEMM_EPILOGUE_STORE v[29:30], v[105:108], 64
	GEMM_EPILOGUE_STORE v[29:30], v[117:120], 128
	GEMM_EPILOGUE_STORE v[29:30], v[125:128], 192
.LBB0_15:
	s_or_b64 exec, exec, s[2:3]
	s_add_i32 s2, s4, 0x60
	v_or_b32_e32 v29, s2, v129
	v_cmp_gt_i32_e32 vcc, s0, v29
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_17
; %bb.16:
	v_mad_i64_i32 v[29:30], s[6:7], s1, v29, 0
	v_lshrrev_b32_e32 v31, 2, v0
	v_and_or_b32 v31, v31, 12, v131
	v_lshlrev_b64 v[29:30], 2, v[29:30]
	v_mov_b32_e32 v32, s17
	v_add_co_u32_e32 v33, vcc, s16, v29
	v_addc_co_u32_e32 v34, vcc, v32, v30, vcc
	v_ashrrev_i32_e32 v32, 31, v31
	v_lshlrev_b64 v[29:30], 2, v[31:32]
	v_add_co_u32_e32 v29, vcc, v33, v29
	v_addc_co_u32_e32 v30, vcc, v34, v30, vcc
	GEMM_EPILOGUE_STORE v[29:30], v[101:104], 0
	GEMM_EPILOGUE_STORE v[29:30], v[25:28], 64
	GEMM_EPILOGUE_STORE v[29:30], v[21:24], 128
	GEMM_EPILOGUE_STORE v[29:30], v[17:20], 192
.LBB0_17:
	s_or_b64 exec, exec, s[2:3]
	s_addk_i32 s4, 0x70
	v_or_b32_e32 v17, s4, v129
	v_cmp_gt_i32_e32 vcc, s0, v17
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_19
; %bb.18:
	v_mad_i64_i32 v[17:18], s[0:1], s1, v17, 0
	v_lshrrev_b32_e32 v0, 2, v0
	v_and_or_b32 v19, v0, 12, v131
	v_lshlrev_b64 v[17:18], 2, v[17:18]
	v_mov_b32_e32 v0, s17
	v_add_co_u32_e32 v21, vcc, s16, v17
	v_ashrrev_i32_e32 v20, 31, v19
	v_addc_co_u32_e32 v0, vcc, v0, v18, vcc
	v_lshlrev_b64 v[17:18], 2, v[19:20]
	v_add_co_u32_e32 v17, vcc, v21, v17
	v_addc_co_u32_e32 v18, vcc, v0, v18, vcc
	GEMM_EPILOGUE_STORE v[17:18], v[13:16], 0
	GEMM_EPILOGUE_STORE v[17:18], v[9:12], 64
	GEMM_EPILOGUE_STORE v[17:18], v[5:8], 128
	GEMM_EPILOGUE_STORE v[17:18], v[1:4], 192
.LBB0_19:
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z8reg_E023PKaS0_Piiiii
		.amdhsa_group_segment_fixed_size 16384
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 40
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 183
		.amdhsa_next_free_sgpr 21
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z8reg_E023PKaS0_Piiiii, .Lfunc_end0-_Z8reg_E023PKaS0_Piiiii
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 3056
; NumSgprs: 25
; NumVgprs: 183
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 16384 bytes/workgroup (compile time only)
; SGPRBlocks: 3
; VGPRBlocks: 45
; NumSGPRsForWavesPerEU: 25
; NumVGPRsForWavesPerEU: 183
; Occupancy: 1
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0 (http://10.16.1.181/dcutoolkit/driverruntime/llvm-project.git b8c5e6d901d63a10d73acf48579414a1ea463c62)"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 16384
    .kernarg_segment_align: 8
    .kernarg_segment_size: 40
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z8reg_E023PKaS0_Piiiii
    .private_segment_fixed_size: 0
    .sgpr_count:     25
    .sgpr_spill_count: 0
    .symbol:         _Z8reg_E023PKaS0_Piiiii.kd
    .unfolded_args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     183
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
