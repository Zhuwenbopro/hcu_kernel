# 公共模块ABI与冻结范围

目标：gfx936，wave64，预打包INT8×INT8→INT32。第一版保持E023及E047原物理寄存器绑定，未强行统一两者寄存器区域或调度。

| 模块 | 显式参数 | 调用者责任 |
|---|---|---|
| GEMM_W/X_GLOBAL_TO_REG | dst四个VGPR、64位addr | 地址合法、目标存活区、消费前VM就绪 |
| GEMM_W/X_GLOBAL_TO_LDS | vaddr、SRD四SGPR、soffset | 准备m0及LDS槽、原VM/LGKM/barrier规则 |
| GEMM_LDS_TO_REG | dst四VGPR、LDS地址、立即数offset | LDS已发布、消费前LGKM就绪 |
| GEMM_MMA_I8 | acc_out、X/W K32片段、acc_in | PI16/K64片段匹配、累加器存活 |
| GEMM_EPILOGUE_STORE | 地址、四INT32、offset | 行有效性、连续16B输出布局 |
| GEMM_EPILOGUE_STORE_GLC_SLC | 同上 | 同上，明确保留glc/slc |
| GEMM_WAIT_VM/LGKM | 显式计数阈值 | 调度骨架决定位置及可安全消费的数据 |
| GEMM_CTA_BARRIER | 无 | 所有需要协作的wave参与 |

宏不分配临时寄存器、不推进地址、不修改m0、不隐式等待；实际指令固有的隐式寄存器语义仍由调用者遵守。每个方案的prologue、地址计算、槽位切换、wait/barrier及分支在.s中显式保留。不会为对齐在热循环中额外填NOP。

一条global dwordx4每lane16B，满wave1KiB；LDS读取和MMAC仍按原逐片交错。global数据可能来自缓存，HBM来源需硬件计数器判定。

X打包及W PI16置换沿用experiments/int8-bw90-20261110/tools/common.py的pack和pack_weight(w,True)，不接受未打包row-major输入。pack、scale与模型端到端不在本轮计时范围。

标准build.py先在独立暂存目录构建，要求函数地址/大小/字节、描述符与元数据等价后才发布。未来修改GPU指令需显式--allow-device-change并指定独立--output-dir，避免覆盖当前对照。汇编中保留的历史编译器Occupancy/MemoryBound注释不当作实测驻留或瓶颈结论。

## READ_FIRST调用约束

当前槽的LDS→REG可以先于下一槽global预取发射，但必须先经过当前槽的ready等待及CTA barrier，且其目标寄存器不能与下一槽的地址计算临时寄存器、私有操作数窗口重叠。生成器的shared read窗口、私有ping-pong窗口和地址区原本分离，可直接重排；E047必须先把steady-state shared窗口上移4个VGPR。

前移读不改变MMAC顺序、LDS片段布局、global地址、指令数量或wait阈值。最后一段跳过预取时，也必须执行当前槽前移读，不能将它放进“是否预取下一槽”的条件分支。E047奇数K64尾段独立保留。

前移数量是按tile实测的参数；0为旧顺序，1..SF为显式前移。不能把N176上8片的收益推广到所有tile；2026-11-13的M128/N128/N144选择为0。E047分流候选在generic使用132 VGPR、16KiB LDS，原generic为128 VGPR；未命中分流条件时使用原函数和原资源声明。

## 标量地址原语与生成器约束（2026-11-14）

新增 GEMM_GLOBAL_SADDR_TO_REG 及 X/W 包装，参数为 dst 四个 VGPR、voffset 单个 VGPR、saddr 两个连续 SGPR、可选立即数 offset。展开为 global_load_dwordx4 dst, voffset, saddr offset:offset；不隐式推进基址。调用者保证 32 位 lane 偏移和立即数范围，并在消费前完成 VM 等待。

生成器 private 路径沿 M 使用 X 的 s8:s9，沿 N 使用 W 的 s10:s11。先将 CTA 偏移加入标量基址，再按 K64 用 s_add_u32/s_addc_u32 推进完整64位地址。各片立即数为 p*1024；当前模式限制每 wave 私有片数 PF≤4。原来的两 VGPR 地址和逐片 v_add_co/v_addc 由上述 SADDR 形式替代。共享 SRD 在私有基址推进前已复制，不随其改变。

shared 路径的 s26 保存 wave LDS 基址，s27/s28/s29 保存4096/8192/12288字节偏移；用 s_mov/s_add 准备 m0，将轮次偏移传给 buffer load 的 SGPR soffset。s26..s29 从第一次预取前存活到最后一次预取；s28:s29 仅在最后 VM 等待后才复用于输出 exec 掩码。shared 模式不能再把 s26 当临时中转寄存器。M 分工共享 W，N 分工共享 X。

private_first 先发下一槽私有加载，再发整批当前槽 LDS 读，之后发下一槽共享复制。它只接受 read_first=0，当前 LDS 读必须位于最后一段的条件预取分支之外。标量地址和 private_first 都保留两槽 LDS 发布等待、CTA barrier、MMAC 顺序及 epilogue 掩码。每个地址模式的 VGPR/SGPR/LDS 声明与同 tile 的原版一致；这不等同于声称实测驻留数一定相同。

新 family 后缀：_PF 表示 private_first；_SAP/_SAS/_SAB 表示 private/shared/both；_RFk 仍表示 legacy 顺序中先发 k 条当前 LDS 读。无后缀的原 family 和默认生成输出保持一致。选择表中缺省 scalar_address/prefetch_order 时兼容旧值 none/legacy。源码及实测文件见 /home/metic/gemm-scalar-address-sweep-locked-20261114/。

## 拆分预取的调度约束（2026-11-14）

split_private_then_shared 的精确顺序为 D_prefix(current)→P(next)→D_rest(current)→S(next)→MMAC；其中 D 是 LDS→REG，P 是私有 global→REG，S 是共享 global→LDS。read_first 只指定 P 之前的当前 LDS 读条数；S 之前总是已经发出全部 SF 条当前 LDS 读。布局元数据分别记录 current_reads_before_private 和 current_reads_before_shared。

当前槽的 ready 等待及 CTA barrier 必须在两段 D 之前。私有双缓冲、当前共享寄存器窗口和地址临时区继续使用既有互不覆盖的物理寄存器区间。最后一段分别条件跳过 P 和 S 及相应地址推进；两段当前 D 均无条件执行，防止尾 K64 数据丢失。保持原 MMAC 顺序、内存操作、wait 阈值、barrier 和 epilogue 掩码。多数候选比 legacy 旧排法静态上多一条比较和一条条件分支。

k=0 的拆分预取与 private_first 的地址准备/末段组织不同，不应自动将二者视为相同函数。沿 M 和沿 N 不能共享未经测量的统一 k。默认模式仍为 legacy，所有旧生成组合保持源码一致。新 family 为 _SPk，加原有标量地址后缀。

select_for_m / --M 只接受策略 scope 内的实际 M，校验固定 N/K、tile、family、资源及 MP 对 CTA 覆盖范围，不外推到未测 shape。--M 会按完整排法去重生成函数并写 selection_by_M.json；--variant 的 per-tile 默认规则保持兼容。M1..128 的既有 E030/E047 不由该固定 MP256 的 tile 策略改写。
