# gfx936 GEMM公共汇编模板

common_gfx936.inc提供X/W global→LDS、global→REG、LDS→REG、INT8 MMAC、epilogue及显式wait/barrier原语。参数是物理寄存器/立即数，宏内不隐含临时寄存器、m0修改或等待。

e023.s/e047.s保留原地址计算、寄存器绑定和调度，GPU代码只经过llvm-mc/ld.lld。hipcc只编译嵌入该code object的C ABI主机加载器。

构建：python3 /home/zmoe/src/gemm_asm/build.py。默认检查全部函数地址/大小/指令字节、描述符和元数据与冻结best一致。未来有计划的变体需显式--allow-device-change。

输出：build/E023、build/E047的kernel.hsaco/kernel.so/plan.json，兼容zmoe_launch/zmoe_info，保留E047特化/通用入口和PI16/K64契约。

验收：/home/metic/gemm-common-asm-20261113/。current.json在性能对齐后写入当前入口，冻结原版仍保留在experiments/int8-bw90-20261110/best。

## 当前入口与验收

已通过8个代表点、3seed×7轮对齐，GPU指令和全部运行时分配节与冻结版相同。当前登记在current.json及experiments/int8-bw90-20261110/best/current_asm.json。使用已有tools/common.py的current_library("E023")或current_library("E047")；其会先初始化模块并校验哈希。

未来变体必须使用--allow-device-change --output-dir /home/metic/<variant>，不能直接覆盖已验证build。构建不自动修改当前登记。原语ABI见MODULE_ABI.md；地址/调度目前仍由各方案显式描述。

## 2026-11-13：当前LDS读与下一段预取的调度

`tile_generator.py`是可复用的四wave、BN128、N17408/K5120 INT8汇编生成器，覆盖沿M的BM128/192/256及沿N的BM128..256（步长16）。`--read-first N`在当前槽通过VM/LGKM等待和CTA barrier后，先发N条当前LDS读，再发下一槽global预取；最后一段不预取的分支仍保留。省略调度参数时保留旧调度，并已逐字节对齐旧生成器的12个baseline。

2026-11-13 的 read-first 选择表及独立复测保存在 /home/metic/gemm-schedule-apply-locked-20261113/。当日 BM128 只测 M128；2026-11-14 的表已覆盖 M129..256，并为 BM128 使用两行 CTA。当前 tile_schedule_policy.json 的适用范围和新地址选项见下节。

示例（输出目录需为新目录）：

```sh
python3 /home/zmoe/src/gemm_asm/tile_generator.py --variant M:192 --variant M:256 --variant N:176 --schedule-policy /home/zmoe/src/gemm_asm/tile_schedule_policy.json --output-dir /home/metic/my-readfirst-tiles
```

E047原来的预取临时寄存器与LDS操作数窗口重叠。`e047_readfirst.py`把steady-state窗口整体上移4个VGPR后再前移LDS读，保留所有wait/barrier和奇数K64收尾。`build.py --allow-device-change --e047-read-first 0..8 --output-dir <独立目录>`用于原始对照；0只调整寄存器窗口，1..8再移动读取。原始RF8候选在小M会退步，不能作为所有shape的统一替代。

`build_readfirst.py --output-dir <独立新目录>`构建带分流的E047候选库，C ABI仍为`zmoe_launch/zmoe_info/zmoe_info_generic`，另有`zmoe_info_shape`和`zmoe_schedule_route`用于检查实际入口。该库在K5120且N17408/M129..256，或N34816/M128时选择RF8 generic；其它合法shape调用保留原指令的fixed/generic。原fixed M128/N17408/K5120函数完全保留。候选不会修改current.json或冻结best。

E023每K64没有同样的跨段global预取/LDS读重叠，不直接套用本次改动；E025/E030主环使用REG路径，末尾归约另行处理。

完整改动、验收、前后延时和原始数据在`/home/metic/gemm-schedule-apply-locked-20261113/REPORT.md`。

## 2026-11-14：标量地址与 M129..256 选择

tile_generator.py 新增 --scalar-address none|private|shared|both。none 保留原向量地址；private 将私有 global→REG 改为 64 位 SGPR 基址加 32 位 lane 偏移；shared 将 global→LDS 的 m0 和复制轮次偏移改为标量计算。沿 M 分工时 private=X、shared=W，沿 N 分工时 private=W、shared=X。它们不改变 MMAC、数据布局、global/LDS 请求数量、wait/barrier 或寄存器声明数。具体寄存器约束见 MODULE_ABI.md。

--prefetch-order legacy 保留 read-first 的调度方式；private_first 使用 P(next)→D(current)→S(next) 的顺序，其中 P 为私有 global→REG，D 为当前槽 LDS→REG，S 为共享 global→LDS；必须配 --read-first 0。最终 K64 不发下一段预取，当前 LDS 读取仍无条件执行。地址模式和发射顺序分别选择，不能把两者的合并收益全部归因于地址模式。

例子（输出到独立新目录）：

~~~sh
python3 /home/zmoe/src/gemm_asm/tile_generator.py --variant N:208 --scalar-address both --read-first 13 --output-dir /home/metic/my-scalar-N208
python3 /home/zmoe/src/gemm_asm/tile_generator.py --variant M:192 --scalar-address both --prefetch-order private_first --read-first 0 --output-dir /home/metic/my-scalar-M192
python3 /home/zmoe/src/gemm_asm/tile_generator.py --variant M:192 --variant N:208 --schedule-policy /home/zmoe/src/gemm_asm/tile_schedule_policy.json --check-only
~~~

当前选择表来自 /home/metic/gemm-scalar-address-sweep-locked-20261114/：固定 gfx936、N17408、K5120、MP256、M129..256；四 wave、BN128，M 分工 BM128/192/256，N 分工 BM128..256、步长16。624 组地址/顺序候选全部做正确性检查，111 组进入逐 M、3 seed×7 轮扫描；另用独立3 seed×7轮、每图72次 kernel 确认全区间赢家。tiles 给出各 tile 在合法 M 区间的平均延时选择；best_by_M 给出逐 M 的实测赢家。两者用途不同，CLI 的 --schedule-policy 使用 tiles，不自动按 M 生成分流加载器。精确时序、输入、尾行守卫和全部128点结果见该目录 REPORT.md、latency-all-M.csv、RESULT.json。

未传策略或新选项时保持原生成器输出；144组旧向量地址/read-first源代码完全一致。标准 build.py 仍生成冻结 E023/E047，指令、描述符和运行时分配节一致。此次只更新 tile 生成能力和测得的选择表，current.json、冻结 best 和现有模型入口保持原登记。

## 2026-11-14：拆分私有预取与共享复制，按实际 M 选取

新增 --prefetch-order split_private_then_shared。--read-first k 在此模式表示：当前槽先发 k 条 LDS→REG，再发下一槽私有 global→REG，再发剩余当前 LDS→REG，最后发下一槽共享 global→LDS。沿 N 分工时私有=W、共享=X；沿 M 分工时相反。每个 tile 单独测 k，合法范围仍为 0..SF。family 使用 _SPk，加原有地址后缀 _SAP/_SAS/_SAB；无地址后缀表示向量地址。与实验临时命名 _SPk_AB 相比只更改函数名，指令字节相同。

本次只替换 best_by_M 的 M193..256；M129..192 条目和其他 tile 的默认排法保持原值，M1..128 的 E030/E047 路由及已登记二进制保留。选择范围固定为 gfx936、N17408、K5120、MP256。完整验证、逐 M 新旧对照和 HBM/L2 模型图保存在 /home/metic/gemm-split-prefetch-integrated-locked-20261114/。

--M 读取 best_by_M，不再只读取 tiles。可重复传入 M；同一函数只构建一次，同时输出 selection_by_M.json。--variant 仍读取每个 tile 的默认排法。--M 与手工 tile/地址/顺序覆盖互斥，避免将修改后的参数误称为已测最优；超出实测范围会拒绝。省略新选项时，原有默认生成行为保持一致。

~~~sh
python3 /home/zmoe/src/gemm_asm/tile_generator.py --M 193 --M 194 --M 224 --M 256 --output-dir /home/metic/my-split-best
python3 /home/zmoe/src/gemm_asm/tile_generator.py --M 193 --check-only
python3 /home/zmoe/src/gemm_asm/tile_generator.py --variant N:224 --prefetch-order split_private_then_shared --read-first 9 --scalar-address both --output-dir /home/metic/my-split-N224
~~~

Python 调用 select_for_m(193) 返回该实际 M 的完整策略，包括 direction/BM/BN/read_first/scalar_address/prefetch_order 和 N/K/MP。生成器负责输出 HSACO 和选择清单，不会自行启动 GPU kernel 或替换现有模型服务。

新策略：M193..208 选择沿 N 的208×128，M209..224 选择224×128，M225..240 选择240×128，M241..256 选择256×128。具体 k 以 best_by_M 为准；tiles 的默认 k 分别为5、9、12、11。只有独立复测有收益的 M 才更新。

624 个旧地址/顺序组合的源码逐字一致；576 个拆分预取组合与独立实验生成规则一致，其中153个已有 GPU 验证的候选函数与集成版指令字节相同。实际逐 M 路由再以新编译模块做完整输出、尾部 guard 和同轮锁频计时验证。current.json、冻结 best、E023/E047 公共原语和 C ABI 不因本次更新改变。
