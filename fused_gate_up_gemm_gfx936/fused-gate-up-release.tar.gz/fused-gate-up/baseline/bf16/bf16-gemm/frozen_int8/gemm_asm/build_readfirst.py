
"""Build an E047 library preserving frozen small/fixed entrypoints and guarding RF8 by measured shapes."""
from pathlib import Path
import argparse,subprocess,hashlib,json,re,sys
from elf_tools import elf
from e047_readfirst import rewrite_e047
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--output-dir',required=True,type=Path);args=ap.parse_args();out=args.output_dir.resolve()
if out==P/'build' or P/'build' in out.parents:ap.error('choose a separate output directory; current build is protected')
out.mkdir(parents=True,exist_ok=False)
source=(P/'e047.s').read_text();opt,audit=rewrite_e047(source,8)
base_blob=(P/'build/E047/kernel.hsaco').read_bytes();_,oldf=elf(base_blob);fixed=next(k for k in oldf if 'Li128ELi17408ELi5120' in k);generic=next(k for k in oldf if k!=fixed)
for name in sorted(oldf,key=len,reverse=True):opt=opt.replace(name,name+'_RF8')
opt=re.sub(r'\b_ZZ8reg_E047[A-Za-z0-9_]+',lambda m:m[0]+'_RF8',opt)
opt=re.sub(r'\.L[A-Za-z0-9_]+',lambda m:'.LRF8_'+m[0][2:],opt)
opt='\n'.join(l for l in opt.splitlines() if not l.lstrip().startswith('.include'))+'\n'
def separate(text):
 body,meta=text.split('\t.amdgpu_metadata\n',1);ks=meta.split('amdhsa.kernels:\n',1)[1];kernels,tail=ks.split('amdhsa.target:',1);return body,kernels,tail
body,kernels,tail=separate(source);ob,ok,ot=separate(opt);combined=body+'\n'+ob+'\t.amdgpu_metadata\n---\namdhsa.kernels:\n'+kernels+ok+'amdhsa.target:'+tail
(out/'kernel.s').write_text(combined)
cmds=[['/opt/dtk/aillvm/bin/llvm-mc','-I',str(P),'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(out/'kernel.s'),'-o',str(out/'kernel.o')],['/opt/dtk/aillvm/bin/ld.lld','-shared',str(out/'kernel.o'),'-o',str(out/'kernel.hsaco')]]
for cmd in cmds:
 q=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
blob=(out/'kernel.hsaco').read_bytes();_,newf=elf(blob);assert set(newf)==set(oldf)|{k+'_RF8' for k in oldf}
proof={k:newf[k]['body']==oldf[k]['body'] for k in oldf};assert all(proof.values()),proof
sha=hashlib.sha256(blob).hexdigest();header='#pragma once\nstatic const unsigned char kCodeObject[] = {\n'+','.join(str(x) for x in blob)+'\n};\n'
for key,value in [('kGenericName',generic),('kFixedName',fixed),('kOptimizedGenericName',generic+'_RF8'),('kCodeObjectSHA256',sha)]:header+=f'constexpr const char* {key}={json.dumps(value)};\n'
header+='constexpr bool kHasFixed=true;\nconstexpr int kBM=128,kBN=128,kDepth=2,kNW=4;\n';(out/'embedded.hpp').write_text(header)
cmd=['/opt/dtk/bin/hipcc','-O2','-std=c++17','-fPIC','-shared','--offload-arch=gfx936','-I',str(out),str(P/'launcher_readfirst.cpp'),'-o',str(out/'kernel.so'),'-pthread'];q=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/'host-build.log').write_text(q.stdout);assert q.returncode==0,q.stdout
(out/'device.disasm').write_text(subprocess.check_output(['/opt/dtk/aillvm/bin/llvm-objdump','-d','--mcpu=gfx936',str(out/'kernel.hsaco')],text=True))
manifest={'source_root':str(P),'kernel_so':str(out/'kernel.so'),'hsaco':str(out/'kernel.hsaco'),'code_object_sha256':sha,'kernel_so_sha256':hashlib.sha256((out/'kernel.so').read_bytes()).hexdigest(),'original_function_bodies_preserved':proof,'read_first':8,'optimized_shape_predicate':'K==5120 && ((N==17408 &&129<=M<=256) || (N==34816 && M==128))','fallback':'frozen fixed entry for128/17408/5120; frozen generic for all other valid shapes','symbols':{'fixed':fixed,'generic':generic,'optimized_generic':generic+'_RF8'},'operand_audit':audit,'no_current_update':True};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
