
"""Apply read-first scheduling to the frozen E047 source, keeping prefetch temporaries live.
The steady-state LDS operand window moves by4 VGPRs; prefetch address temporaries retain their original registers.
read_first=0 is the register-only control;1..8 advances that many current-slot reads.
The odd-K64 drain is untouched. No wait or barrier is removed.
"""
import hashlib,re
BASELINE_SHA256='b8e35752f9df2fcb4e5a3ace9551b73a68120e0bb1be0fbe245a98d03d6b072b'
def rewrite_e047(source,read_first):
 if hashlib.sha256(source.encode()).hexdigest()!=BASELINE_SHA256:raise ValueError('E047 source differs from the audited baseline; review operand liveness before applying this transform')
 if type(read_first) is not int or not 0<=read_first<=8:raise ValueError('read_first must be0..8')
 generic='\t.section\t.text._Z8reg_E047ILi0ELi0ELi0EEvPKaS1_Piiiii,#alloc,#execinstr';cut=source.index(generic);met=source.index('\t.amdgpu_metadata');parts=[source[:cut],source[cut:met]];audit=[]
 for fun,oldreg,bases in [(0,91,[84,90]),(1,96,[90,95])]:
  text=parts[fun];prefixes={}
  for addr in bases:
   lines=text.splitlines(keepends=True);needle=f'GEMM_LDS_TO_REG v[{oldreg}:{oldreg+3}], v{addr}, 0';start=next(i for i,x in enumerate(lines) if x.strip()==needle);end=start
   count_mma=0
   while end<len(lines):
    assert not lines[end].lstrip().startswith('.LBB'), (fun,addr,'unexpected control-flow boundary')
    count_mma+=lines[end].strip().startswith('GEMM_MMA_I8')
    end+=1
    if count_mma==32:break
   assert count_mma==32
   block=lines[start:end];new=[];reads=[];mmac=0
   for line in block:
    z=line.strip()
    if z.startswith('GEMM_LDS_TO_REG'):
     m=re.match(r'(\s*GEMM_LDS_TO_REG )v\[(\d+):(\d+)\](.*)',line);assert m,line;a,b=int(m[2]),int(m[3]);assert oldreg<=a<=oldreg+28
     line=m[1]+f'v[{a+4}:{b+4}]'+m[4]+'\n';reads.append(line)
     if len(reads)<=read_first:continue
    elif z.startswith('GEMM_MMA_I8'):
     m=re.match(r'(\s*GEMM_MMA_I8 v\[\d+:\d+\], v\[\d+:\d+\], )v\[(\d+):(\d+)\](.*)',line);assert m,line;a,b=int(m[2]),int(m[3]);assert oldreg<=a<b<=oldreg+31
     line=m[1]+f'v[{a+4}:{b+4}]'+m[4]+'\n';mmac+=1
    new.append(line)
   assert len(reads)==8 and mmac==32,(fun,addr,len(reads),mmac);prefixes[addr]=''.join(reads[:read_first]);text=''.join(lines[:start]+new+lines[end:]);audit.append({'function':'fixed' if fun==0 else 'generic','LDS_address_vgpr':addr,'old_window':[oldreg,oldreg+31],'new_window':[oldreg+4,oldreg+35],'advanced_reads':read_first})
  if read_first:
   hits=list(re.finditer(r'^\s*GEMM_CTA_BARRIER[^\n]*\n',text,re.M));assert len(hits)>=(2 if fun==0 else 3),(fun,len(hits))
   for hit,addr in reversed(list(zip(hits[:2],bases))):text=text[:hit.end()]+prefixes[addr]+text[hit.end():]
  oldcount=123 if fun==0 else 128;newcount=oldcount+4
  needle=f'.amdhsa_next_free_vgpr {oldcount}';assert text.count(needle)==1;text=text.replace(needle,f'.amdhsa_next_free_vgpr {newcount}')
  text=text.replace(f'; NumVgprs: {oldcount}',f'; NumVgprs: {newcount}');parts[fun]=text
 metadata=source[met:]
 for a,b in [(123,127),(128,132)]:
  metadata,n=re.subn(fr'(\.vgpr_count:\s+){a}(?=\s|$)',fr'\g<1>{b}',metadata);assert n==1,(a,n)
 return ''.join(parts)+metadata,audit
