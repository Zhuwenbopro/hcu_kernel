from pathlib import Path
import argparse,json,subprocess,hashlib,tempfile,shutil,os
from elf_tools import elf
P=Path(__file__).resolve().parent;OLD=P.parents[1]/'experiments/int8-bw90-20261110'
MC='/opt/dtk/aillvm/bin/llvm-mc';LD='/opt/dtk/aillvm/bin/ld.lld';OD='/opt/dtk/aillvm/bin/llvm-objdump'
ap=argparse.ArgumentParser()
ap.add_argument('--allow-device-change',action='store_true')
ap.add_argument('--output-dir',type=Path)
ap.add_argument('--e047-read-first',type=int,choices=range(9),default=None,
                help='E047 candidate:0 relocates its LDS operand window only;1..8 also advances current-slot LDS reads. Omit for frozen code.')
args=ap.parse_args()
if args.e047_read_first is not None and not args.allow_device_change:
 ap.error('--e047-read-first requires --allow-device-change and a separate --output-dir')
DEST=(args.output_dir or (P/'build')).resolve()
if args.allow_device_change and DEST==(P/'build').resolve():raise SystemExit('Experimental device changes require a separate --output-dir; current build is protected')
DEST.mkdir(parents=True,exist_ok=True)
STAGE=Path(tempfile.mkdtemp(prefix='.build-',dir=str(P)))
records=[]
for fam in ['E023','E047']:
 out=STAGE/fam;out.mkdir(parents=True,exist_ok=True);commands=[]
 device_source=P/(fam.lower()+'.s')
 schedule=None
 if fam=='E047' and args.e047_read_first is not None:
  from e047_readfirst import rewrite_e047
  transformed,operand_audit=rewrite_e047(device_source.read_text(),args.e047_read_first)
  device_source=out/'kernel.readfirst.s';device_source.write_text(transformed)
  schedule={'read_first':args.e047_read_first,'LDS_operand_window_shift':4,'operand_audit':operand_audit}

 for cmd in [[MC,'-I',str(P),'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(device_source),'-o',str(out/'kernel.o')],[LD,'-shared',str(out/'kernel.o'),'-o',str(out/'kernel.hsaco')]]:
  q=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);commands.append(cmd);assert q.returncode==0,q.stdout
 gold=(OLD/'nodes'/fam/'device.co').read_bytes();new=(out/'kernel.hsaco').read_bytes();a,aa=elf(gold);b,bb=elf(new)
 proof={'function_names_identical':set(aa)==set(bb),'functions':{},'allocated_sections':{},'whole_hsaco_identical':gold==new}
 for name,x in aa.items():
  y=bb[name];proof['functions'][name]={'address_identical':x['address']==y['address'],'size_identical':x['size']==y['size'],'instruction_bytes_identical':x['body']==y['body'],'body_sha256':hashlib.sha256(y['body']).hexdigest()}
 for name in a:
  if name.startswith('.text') or name in ['.rodata','.note']:proof['allocated_sections'][name]=a[name]==b.get(name)
 same=proof['function_names_identical'] and all(all(v[k] for k in ['address_identical','size_identical','instruction_bytes_identical']) for v in proof['functions'].values()) and all(proof['allocated_sections'].values());assert args.allow_device_change or same,(fam,proof)
 (out/'device.disasm').write_text(subprocess.check_output([OD,'-d','--mcpu=gfx936',str(out/'kernel.hsaco')],text=True))
 fixed=next((n for n in bb if 'Li128ELi17408ELi5120' in n),None);generic=next(n for n in bb if n!=fixed);cfg=json.loads((OLD/'best'/fam/'plan.json').read_text())['config'];bm,bn,depth,nw=(128,256,1,4) if fam=='E023' else (128,128,2,4);sha=hashlib.sha256(new).hexdigest()
 header='#pragma once\nstatic const unsigned char kCodeObject[] = {\n'+','.join(str(x) for x in new)+'\n};\n'+f'constexpr const char* kGenericName={json.dumps(generic)};\nconstexpr const char* kFixedName={json.dumps(fixed or generic)};\nconstexpr bool kHasFixed={str(bool(fixed)).lower()};\nconstexpr int kBM={bm},kBN={bn},kDepth={depth},kNW={nw};\nconstexpr const char* kCodeObjectSHA256={json.dumps(sha)};\n'
 (out/'embedded.hpp').write_text(header)
 cmd=['/opt/dtk/bin/hipcc','-O2','-std=c++17','-fPIC','-shared','--offload-arch=gfx936','-I',str(out),str(P/'launcher.cpp'),'-o',str(out/'kernel.so'),'-pthread'];q=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);commands.append(cmd);(out/'host-build.log').write_text(q.stdout);assert q.returncode==0,q.stdout
 (out/'plan.json').write_text(json.dumps({'id':fam+'_COMMON_ASM','source':str(P/(fam.lower()+'.s')),'common':str(P/'common_gfx936.inc'),'config':cfg,'frozen_parent':str(OLD/'best'/fam)},indent=2)+'\n')
 records.append({'family':fam,'source':str(P/(fam.lower()+'.s')),'common_sha256':hashlib.sha256((P/'common_gfx936.inc').read_bytes()).hexdigest(),'code_object_sha256':sha,'kernel_so_sha256':hashlib.sha256((out/'kernel.so').read_bytes()).hexdigest(),'kernel_so':str(out/'kernel.so'),'hsaco':str(out/'kernel.hsaco'),'proof':proof,'commands':commands,'device_change_explicitly_allowed':args.allow_device_change,'schedule':schedule});print('BUILT',fam,'same_device_code',same,'whole_hsaco_identical',gold==new,flush=True)
for record in records:
 fam=record['family'];dst=DEST/fam;dst.mkdir(parents=True,exist_ok=True)
 for item in (STAGE/fam).iterdir():
  temp=dst/('.pending-'+item.name);shutil.copy2(item,temp);os.replace(temp,dst/item.name)
 record['kernel_so']=str(dst/'kernel.so');record['hsaco']=str(dst/'kernel.hsaco')
 if record.get('schedule') is not None:record['generated_source']=str(dst/'kernel.readfirst.s')
temp=DEST/'.manifest.pending';temp.write_text(json.dumps(records,indent=2)+'\n');os.replace(temp,DEST/'manifest.json')
assert STAGE.parent.resolve()==P.resolve() and STAGE.name.startswith('.build-')
shutil.rmtree(STAGE)

