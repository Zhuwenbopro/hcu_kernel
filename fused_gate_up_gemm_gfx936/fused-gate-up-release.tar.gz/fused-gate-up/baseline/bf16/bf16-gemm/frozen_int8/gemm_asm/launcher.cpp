#include <hip/hip_runtime_api.h>
#include <mutex>
#include <map>
#include "embedded.hpp"
namespace {
struct State {hipModule_t module{};hipFunction_t generic{},fixed{};hipError_t error=hipSuccess;};
std::mutex state_mutex;std::map<int,State> states;
State* get_state(hipError_t& error){
 int device=0;error=hipGetDevice(&device);if(error!=hipSuccess)return nullptr;
 std::lock_guard<std::mutex> lock(state_mutex);auto found=states.find(device);
 if(found!=states.end()){error=found->second.error;return &found->second;}
 State s;s.error=hipModuleLoadData(&s.module,kCodeObject);
 if(s.error==hipSuccess)s.error=hipModuleGetFunction(&s.generic,s.module,kGenericName);
 if(s.error==hipSuccess){if(kHasFixed)s.error=hipModuleGetFunction(&s.fixed,s.module,kFixedName);else s.fixed=s.generic;}
 auto result=states.emplace(device,s);error=result.first->second.error;return &result.first->second;
}
int info(int* out,bool generic){
 hipError_t e;State* s=get_state(e);if(e!=hipSuccess)return int(e);hipFunction_t f=generic?s->generic:s->fixed;
 e=hipFuncGetAttribute(&out[0],HIP_FUNC_ATTRIBUTE_NUM_REGS,f);if(e!=hipSuccess)return int(e);
 e=hipFuncGetAttribute(&out[1],HIP_FUNC_ATTRIBUTE_SHARED_SIZE_BYTES,f);if(e!=hipSuccess)return int(e);
 e=hipFuncGetAttribute(&out[2],HIP_FUNC_ATTRIBUTE_LOCAL_SIZE_BYTES,f);if(e!=hipSuccess)return int(e);
 out[3]=kBM;out[4]=kBN;out[5]=kDepth;out[6]=kNW;return 0;
}
}
extern "C" int zmoe_launch(const signed char* x,const signed char* w,int* y,int M,int N,int K,void* stream){
 if(M<1||N%kBN||K<64||K%64)return -1;int MP=(M+kBM-1)/kBM*kBM;
 hipError_t e;State* s=get_state(e);if(e!=hipSuccess)return int(e);
 hipFunction_t f=(kHasFixed&&M==128&&N==17408&&K==5120)?s->fixed:s->generic;
 void* args[]={&x,&w,&y,&M,&N,&K,&MP};
 return int(hipModuleLaunchKernel(f,N/kBN,MP/kBM,1,kNW*64,1,1,0,reinterpret_cast<hipStream_t>(stream),args,nullptr));
}
extern "C" int zmoe_info(int* out){return info(out,false);}
extern "C" int zmoe_info_generic(int* out){return info(out,true);}
extern "C" const char* zmoe_asm_sha256(){return kCodeObjectSHA256;}
