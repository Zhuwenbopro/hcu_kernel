import ctypes,json,os,statistics,time
from pathlib import Path
import numpy as np
import torch

def library(path):
    h=ctypes.CDLL(str(path),mode=ctypes.RTLD_LOCAL)
    f=h.zmoe_launch
    f.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,
                ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_void_p];f.restype=ctypes.c_int
    q=h.zmoe_info;q.argtypes=[ctypes.POINTER(ctypes.c_int)];q.restype=ctypes.c_int
    a=(ctypes.c_int*7)();assert q(a)==0
    spec=Path(path).parent/'plan.json'
    pi=bool(json.loads(spec.read_text()).get('config',{}).get('PI',0)) if spec.exists() else False
    return {'handle':h,'fn':f,'info':list(a),'path':str(path),'pi':pi}

def pack(t,block_m=16):
    rows,k=t.shape
    pad=(rows+block_m-1)//block_m*block_m
    if pad!=rows:
        t=torch.cat([t,torch.zeros((pad-rows,k),device=t.device,dtype=t.dtype)],dim=0)
    return t.view(pad//16,16,k//64,4,16).permute(2,0,3,1,4).contiguous()

def pack_weight(t,pi=False):
    if pi:
        n,k=t.shape
        perm=torch.tensor([4*(p%4)+p//4 for p in range(16)],device=t.device)
        t=t.view(n//16,16,k)[:,perm,:].reshape(n,k)
    return pack(t)

def launch(lib,x,w,y,m,n,k):
    rc=lib['fn'](x.data_ptr(),w.data_ptr(),y.data_ptr(),m,n,k,torch.cuda.current_stream().cuda_stream)
    if rc:raise RuntimeError('launch rc '+str(rc))

def reference(x,w):
    m,k=x.shape
    if m<=16:
        x=torch.cat([x,torch.zeros((32-m,k),device=x.device,dtype=x.dtype)],dim=0)
    return torch._int_mm(x,w.t())[:m]

def correctness(lib,output):
    bm,bn=lib['info'][3:5]
    ns=max(256,bn)
    cases=[]
    for m in [1,3,6,16,24,32,48,64,96,128]:
        cases.append((m,ns,64,'random'))
    for s in [2,3,4,5,7,8,9,15,16,17,79,80,81]:
        cases.append((32,ns,s*64,'random'))
    for pat in ['zero','minmin','minmax','maxmax','onehot']:
        cases.append((32,ns,576,pat))
    for m in [32,128]:
        for n in [17408,34816]:cases.append((m,n,5120,'random'))
    records=[]
    for ci,(m,n,k,pat) in enumerate(cases):
        torch.manual_seed(100+ci)
        x=torch.randint(-128,128,(m,k),device='cuda',dtype=torch.int8)
        w=torch.randint(-128,128,(n,k),device='cuda',dtype=torch.int8)
        if pat=='zero':x.zero_()
        if pat=='minmin':x.fill_(-128);w.fill_(-128)
        if pat=='minmax':x.fill_(-128);w.fill_(127)
        if pat=='maxmax':x.fill_(127);w.fill_(127)
        if pat=='onehot':
            x.zero_();rr=torch.arange(m,device='cuda');x[rr,(rr*17+3)%k]=1
        xp,wp=pack(x,bm),pack_weight(w,lib.get('pi',False))
        expect=reference(x,w)
        cpu_bad=0
        if m*n*k<=80_000_000:
            cpu=x.cpu().numpy().astype(np.int64)@w.cpu().numpy().astype(np.int64).T
            cpu_bad=int(np.count_nonzero(cpu!=expect.cpu().numpy()))
            cpu_checked=m*n
        else:
            rs=sorted(set([0,min(15,m-1),min(16,m-1),m//2,m-1]))
            cs=sorted(set([0,1,15,16,n//2,n-1]))
            cpu=x[rs].cpu().numpy().astype(np.int64)@w[cs].cpu().numpy().astype(np.int64).T
            cpu_bad=int(np.count_nonzero(cpu!=expect[rs][:,cs].cpu().numpy()))
            cpu_checked=len(rs)*len(cs)
        backing=torch.full((m*n+2048,),0x5a5a5a5a,device='cuda',dtype=torch.int32)
        y=backing[1024:-1024].view(m,n)
        launch(lib,xp,wp,y,m,n,k);torch.cuda.synchronize()
        bad=int((y!=expect).sum().item())
        guard=bool((backing[:1024]==0x5a5a5a5a).all().item() and (backing[-1024:]==0x5a5a5a5a).all().item())
        rec={'M':m,'N':n,'K':k,'pattern':pat,'checked':m*n,'bad':bad,'guard':guard,
             'cpu_checked':cpu_checked,'cpu_bad':cpu_bad}
        if bad:
            rec['first']=[]
            for r,c in torch.nonzero(y!=expect)[:6].cpu().tolist():
                rec['first'].append([r,c,int(y[r,c]),int(expect[r,c])])
        records.append(rec)
        output.write_text(json.dumps(records,indent=2)+'\n')
        if bad or cpu_bad or not guard:raise RuntimeError('correctness failed '+str(rec))
        del x,w,xp,wp,expect,backing,y
        torch.cuda.empty_cache()
    return records

def timing(libs,m,n,k=5120,copies=4):
    torch.manual_seed(20261110)
    x=torch.randint(-128,128,(m,k),device='cuda',dtype=torch.int8)
    raw=[torch.randint(-128,128,(n,k),device='cuda',dtype=torch.int8) for _ in range(copies)]
    wp={pi:[pack_weight(w,pi) for w in raw] for pi in {l.get('pi',False) for l in libs.values()}}
    xp={key:pack(x,l['info'][3]) for key,l in libs.items()}
    y=torch.empty((m,n),device='cuda',dtype=torch.int32)
    iters,rounds=100,5
    expect=reference(x,raw[(iters-1)%copies])
    for key,l in libs.items():
        for i in range(20):launch(l,xp[key],wp[l.get('pi',False)][i%copies],y,m,n,k)
    torch.cuda.synchronize()
    graphs={}
    for key,l in libs.items():
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):
            for i in range(iters):launch(l,xp[key],wp[l.get('pi',False)][i%copies],y,m,n,k)
        graphs[key]=g
    for _ in range(2):
        for g in graphs.values():g.replay()
    torch.cuda.synchronize()
    samples={k:[] for k in libs};records=[]
    for r in range(rounds):
        order=list(libs)
        if r%2:order.reverse()
        one={'round':r,'order':order,'us':{}}
        for key in order:
            e0=torch.cuda.Event(enable_timing=True);e1=torch.cuda.Event(enable_timing=True)
            e0.record();graphs[key].replay();e1.record();e1.synchronize()
            us=e0.elapsed_time(e1)*1000/iters
            assert torch.equal(y,expect),'graph output failed '+key
            samples[key].append(us);one['us'][key]=us
        records.append(one)
    result={'shape':[m,n,k],'copies':copies,'iters':iters,'rounds':records,'summary':{}}
    for key,v in samples.items():
        t=statistics.median(v)
        result['summary'][key]={'median_us':t,'min_us':min(v),'max_us':max(v),
          'weight_GBs':n*k/t/1e3,'weight_util_pct':n*k/t/1e3/1363.5*100,
          'logical_total_GBs':(m*k+n*k+4*m*n)/t/1e3}
    del graphs,x,raw,wp,xp,y,expect
    torch.cuda.empty_cache()
    return result


def current_library(candidate, registry=None):
    """Load a hash-verified current assembly implementation; explicit library(path) remains available for frozen comparisons."""
    import hashlib
    if registry is None:
        registry=Path(__file__).resolve().parent.parent/'best/current_asm.json'
    config=json.loads(Path(registry).read_text())
    if config.get('status')!='validated':
        raise RuntimeError('Current assembly registry has not passed validation')
    if candidate not in config['implementations']:
        raise ValueError('No current assembly implementation for '+str(candidate))
    record=config['implementations'][candidate]
    path=Path(record['kernel_so'])
    if hashlib.sha256(path.read_bytes()).hexdigest()!=record['kernel_so_sha256']:
        raise RuntimeError('Current assembly library hash mismatch: '+str(path))
    result=library(path)
    query=result['handle'].zmoe_asm_sha256
    query.restype=ctypes.c_char_p
    if query().decode()!=record['code_object_sha256']:
        raise RuntimeError('Embedded device code hash mismatch: '+str(path))
    return result
