# BF16 输入、BF16 输出：模块化汇编扩展

实测 bw47 / zhuwenbo_sgl_0522 / GPU5。范围为 M1..256、N17408、K5120；A、B均为BF16，使用原生 BF16 MMAC，FP32累加，BF16输出。B外部布局仍为[K,N]、stride=(1,K)，W可提前重排。本轮为独立适配版，未替换模型服务入口。

## 实测结果

包含每次调用的BF16激活重排，静态W提前重排。torch.mm全256点，当前LightOp BF16入口抽测18点。训练候选选择使用单独seed，正式结果来自三个未参与选路的seed，每组七轮、每图72份W轮转；先取每seed中位，再取三个seed中位。

| M | torch.mm us | LightOp us | Ours incl. X pack us | Ours GEMM only us | Speedup vs torch |
|---:|---:|---:|---:|---:|---:|
| 1 | 247.902 | 207.482 | 136.078 | 131.898 | 1.822x |
| 2 | 136.271 | - | 136.375 | 132.004 | 0.999x |
| 4 | 148.391 | 215.082 | 136.524 | 132.118 | 1.087x |
| 8 | 152.462 | 228.753 | 136.611 | 132.178 | 1.116x |
| 16 | 154.849 | 272.018 | 137.571 | 132.455 | 1.126x |
| 32 | 166.569 | 533.697 | 138.327 | 133.142 | 1.204x |
| 64 | 184.927 | 1023.473 | 140.013 | 134.633 | 1.321x |
| 65 | 361.322 | 1192.526 | 140.124 | 134.898 | 2.579x |
| 96 | 214.351 | 1500.855 | 141.771 | 136.100 | 1.512x |
| 128 | 235.073 | 1978.652 | 143.560 | 137.595 | 1.637x |
| 129 | 360.518 | 2141.583 | 147.829 | 141.189 | 2.439x |
| 160 | 245.344 | 2450.041 | 151.298 | 143.860 | 1.622x |
| 176 | 247.818 | 2688.665 | 154.131 | 146.675 | 1.608x |
| 192 | 220.429 | 2922.447 | 156.955 | 147.869 | 1.404x |
| 193 | 220.647 | 3084.776 | 163.313 | 160.778 | 1.351x |
| 208 | 222.038 | 3155.836 | 169.718 | 162.373 | 1.308x |
| 224 | 223.013 | 3394.743 | 171.393 | 164.293 | 1.301x |
| 240 | 340.802 | 3627.147 | 179.135 | 171.293 | 1.902x |
| 256 | 367.326 | 3860.953 | 184.091 | 177.064 | 1.995x |

对torch.mm，中位数比值范围 0.999–2.851x。接近持平（比值距1不足0.5%）的M为 [2]；其余 255 点更快、0 点更慢。区间统计及同轮配对比值见RESULT.json和latency-M1-256.csv。LightOp数据来自已安装gemmopt.gemm -> op.gemm_opt入口，使用当前二进制而非根据仓库旧代码推测；它在这组形状明显慢于torch.mm，因此主图以torch.mm作更强基线。18点完整对照见lightop-representative-points.csv。

这些是Graph内GPU时间；CPU调用、首次模块加载/JIT、Graph构建、一次性W重排不计入。不是模型请求端到端加速。

## 真正的BF16计算路径

BF16 A -> GPU K32重排及M补零 -> BF16 MMAC / FP32 accumulators -> BF16 RNE写回。没有INT8量化、scale或完整FP32中间矩阵。FP32输出变体仅用于精度检查。

核心指令为 v_mmac_f32_16x16x16_bf16。INT8每行K64字节与BF16每行K32元素均为64字节，因此每lane16B加载、1KiB片段、LDS双槽和私有双缓冲可沿用；K5120需要160个K32段，原INT8为80个K64段。生成器的固定pair计数40改80；E047固定入口的末段边界同步调整；运行时packed ABI以K字节数10240传递，公开API仍以5120个BF16元素理解K。E030 split-K归约由整数add改FP32 add。BF16输出执行RNE并正确处理NaN分类，直接按两个dword写四个BF16。

28个模块包含FP32和BF16两种输出、每种输出类型15个函数入口。反汇编确认不存在INT8 MMAC。FP32与BF16输出版本的K主循环字节一致，只有指向不同尾部的合法分支位移变化；详见instruction-audit.json。公共寄存器和LDS预算未因输入改为BF16增加，因为每段K元素数减半。默认路由的M1..128选择N128_SAB，使用124 VGPR、16KiB LDS、4 wave、BN128。大M沿用这组候选内实测选择，完整逐M策略在bf16-policy.json。

选路在14类既有/派生候选中进行，不代表所有tile和流水的全局最优。本轮没有逐因素消融，不把相对BLAS的总收益单独归因于布局、tile、资源或某条指令。

## 正确性

106组小整数/one-hot/尾行检查，对应FP32及BF16输出均通过完整结果与guard。one-hot覆盖K分区两半和最后K32段。

初始路由使用两组随机BF16输入逐M覆盖全部256点，共 1,145,307,136 个BF16元素。FP64完整矩阵乘作为参考，并用CPU FP64点检；FP32累加最大绝对误差 0.000445315614，最大相对L2误差 4.47642356e-07。BF16输出与自身FP32结果的RNE转换逐位一致；其相对FP64最大L2误差 0.00166836041，主要处于BF16舍入精度范围。尾部guard、Graph重复回放、NaN/Inf分类均通过。

本轮浮点累加顺序与BLAS可不同，不承诺与LightOp或torch.mm逐位相同。BF16对FP64舍入结果的检查阈值 rtol=1/128、atol=1/256；报告同时保留误差实测值。原始精度数据在validation.json；正式计时的768个组、共 16506 次主图回放检查最后一份W的完整输出，均通过。

## 计时与准备成本

每份W为170 MiB，72份原W与72份对应packed W每种布局约11.95 GiB，远大于卡上8 MiB L2。各实现共用同一组数值和轮转顺序；同轮随机实现顺序。候选包含激活重排与纯GEMM两图共享BF16输出地址，外部基线按各自公开接口分配输出。每次候选激活重排都计时。一次性W重排中位数 421.940 us/权重；保留原W时packed副本额外占170 MiB。

频率采样 416 次，分布 {"freq1_input": {"1499000000": 416}, "freq2_input": {"1800000000": 416}, "power_dpm_force_performance_level": {"manual": 416}}。torch.mm/LightOp版本、入口及Torch选项见environment.json和baseline-manifest.json。

## 保存与使用

代码与工件均在本目录。上一轮INT8成果包SHA256在PRESERVED.json中，本轮没有覆盖它。接口bf16_gemm.py，生成器bf16_generator.py，策略bf16-policy.json；验证smoke.py/validate.py；选路tune.py；正式计时benchmark.py；全部原始样本benchmark-raw.json和benchmark-seed-*.jsonl。

```python
import torch
from bf16_gemm import prepare_weight, matmul

# a: BF16 [M,5120] contiguous
# w: BF16 [5120,17408], stride=(1,5120)
prepared = prepare_weight(w)  # static weight, prepare once
y = matmul(a, w, prepared_weight=prepared)  # BF16 [M,17408]
# Optional FP32 debug output:
y32 = matmul(a, w, prepared_weight=prepared, out_dtype=torch.float32)
```

热身所需M后可捕获Graph。省略prepared_weight会在每次调用重排W。修改W后需重新prepare。默认输出为BF16；当前支持M1..256和固定N/K，非匹配形状会报错。验证、调优及benchmark脚本显式使用BW47物理GPU5；适配模块本身继承调用方的GPU映射。
