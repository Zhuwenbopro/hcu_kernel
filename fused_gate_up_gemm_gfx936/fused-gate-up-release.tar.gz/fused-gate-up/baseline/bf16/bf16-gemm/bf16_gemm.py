"""BF16 input / FP32 accumulation / BF16 output, fixed N17408 K5120 gfx936."""
from pathlib import Path
from dataclasses import dataclass
import ctypes as C
import math,json,hashlib
import torch
import triton
import triton.language as tl
R=Path(__file__).resolve().parent
N,K=17408,5120

@triton.jit
def _pack(SRC,DST,rows,PAD:tl.constexpr,PI:tl.constexpr,BLOCK:tl.constexpr):
    z=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    rr=(z//8)%16
    if PI:rr=4*(rr%4)+rr//4
    row=((z//512)%(PAD//16))*16+rr
    col=(z//(PAD*32))*32+((z//128)%4)*8+z%8
    val=tl.load(SRC+row*5120+col,(z<PAD*5120)&(row<rows),other=0)
    tl.store(DST+z,val,z<PAD*5120)

def pack_a(a,mp,out=None):
    if out is None:out=torch.empty((K//32,mp//16,4,16,8),device=a.device,dtype=torch.bfloat16)
    _pack[(triton.cdiv(mp*K,4096),)](a,out,a.shape[0],mp,False,4096,num_warps=4)
    return out

def pack_w(b,out=None):
    if out is None:out=torch.empty((K//32,N//16,4,16,8),device=b.device,dtype=torch.bfloat16)
    _pack[(triton.cdiv(N*K,4096),)](b,out,N,N,True,4096,num_warps=4)
    return out

HIP=C.CDLL('libamdhip64.so')
HIP.hipGetErrorString.restype=C.c_char_p
HIP.hipModuleLoad.argtypes=[C.POINTER(C.c_void_p),C.c_char_p]
HIP.hipModuleGetFunction.argtypes=[C.POINTER(C.c_void_p),C.c_void_p,C.c_char_p]
HIP.hipModuleLaunchKernel.argtypes=[C.c_void_p]+[C.c_uint]*7+[C.c_void_p,C.POINTER(C.c_void_p),C.c_void_p]
HIP.hipFuncGetAttribute.argtypes=[C.POINTER(C.c_int),C.c_int,C.c_void_p]
def ok(rc):
    if rc:raise RuntimeError((rc,HIP.hipGetErrorString(rc).decode()))

class Kernel:
    def __init__(self,rec,name):
        self.rec=rec;self.name=name;self.bm=rec['BM'];self.bn=rec['BN'];self.nw=rec['NW']
        path=R/'kernels'/rec['family']/'kernel.hsaco'
        if hashlib.sha256(path.read_bytes()).hexdigest()!=rec['hsaco_sha256']:raise RuntimeError('Module checksum mismatch')
        self.module=C.c_void_p();ok(HIP.hipModuleLoad(C.byref(self.module),str(path).encode()))
        self.fn=C.c_void_p();ok(HIP.hipModuleGetFunction(C.byref(self.fn),self.module,name.encode()))
        self.info={}
        for attr in [0,1,2,3,4]:
            v=C.c_int();ok(HIP.hipFuncGetAttribute(C.byref(v),attr,self.fn));self.info[str(attr)]=v.value
        if self.info['3']!=0:raise RuntimeError('Unexpected scratch')
    def mp_for(self,m):
        if self.rec['base_family'] in ['E030','E047']:return math.ceil(m/self.bm)*self.bm
        return 128 if self.bm==128 and m<=128 else 256
    def launch(self,xp,wp,y,m):
        if 'fixed' in self.name and m!=128:raise ValueError('Fixed kernel requires M128')
        mp=self.mp_for(m)
        if math.ceil(m/self.bm)*self.bm>mp:raise ValueError('MP does not cover this tile')
        # Private packed ABI uses the K-byte extent; the public API uses K elements.
        vals=[C.c_void_p(t.data_ptr()) for t in [xp,wp,y]]+[C.c_int(x) for x in [m,N,K*2,mp]]
        args=(C.c_void_p*len(vals))(*[C.addressof(v) for v in vals])
        ok(HIP.hipModuleLaunchKernel(self.fn,N//self.bn,math.ceil(m/self.bm),1,self.nw*64,1,1,0,C.c_void_p(torch.cuda.current_stream().cuda_stream),args,None))

class Engine:
    def __init__(self):
        self.records=json.loads((R/'kernels/manifest.json').read_text())
        policy=R/'bf16-policy.json'
        if not policy.exists():policy=R/'initial-policy.json'
        self.routes=json.loads(policy.read_text())['by_M']
        self.kernels={}
        for rec in self.records:
            for name in rec.get('functions',[rec.get('function')]):
                base=rec['base_family']+('_fixed' if 'fixed' in name else '')
                self.kernels[base,rec['output_dtype']]=Kernel(rec,name)
    def key(self,m,family=None):
        if not 1<=m<=256:raise ValueError('Validated M range is 1..256')
        f=family or self.routes[str(m)]
        return 'E047_fixed' if f=='E047' and m==128 else f
    def kernel(self,m,out_dtype=torch.bfloat16,family=None):
        kind='bf16' if out_dtype==torch.bfloat16 else 'fp32' if out_dtype==torch.float32 else None
        if kind is None:raise ValueError('Output must be BF16 or FP32')
        return self.kernels[self.key(m,family),kind]
    def launch_packed(self,xp,wp,y,m,family=None):self.kernel(m,y.dtype,family).launch(xp,wp,y,m)
    def mm(self,a,prepared,out_dtype=torch.bfloat16,out=None,family=None):
        validate(a,prepared.original,out_dtype);prepared.check()
        m=a.shape[0];kernel=self.kernel(m,out_dtype,family)
        xp=pack_a(a,kernel.mp_for(m))
        if out is None:out=torch.empty((m,N),device=a.device,dtype=out_dtype)
        if out.shape!=(m,N) or out.dtype!=out_dtype or out.device!=a.device or not out.is_contiguous():
            raise ValueError('Invalid output tensor')
        kernel.launch(xp,prepared.packed,out,m)
        return out

_ENGINE=None
def engine():
    global _ENGINE
    if _ENGINE is None:_ENGINE=Engine()
    return _ENGINE

def validate(a,b,out_dtype):
    if a.ndim!=2 or a.shape[1]!=K or not 1<=a.shape[0]<=256 or a.dtype!=torch.bfloat16 or not a.is_cuda or not a.is_contiguous():
        raise ValueError('A must be contiguous BF16 CUDA [M,5120], M1..256')
    if b.shape!=(K,N) or b.stride()!=(1,K) or b.dtype!=torch.bfloat16 or b.device!=a.device:
        raise ValueError('B must be BF16 [5120,17408] stride (1,5120) on A device')
    if out_dtype not in [torch.bfloat16,torch.float32]:raise ValueError('Output must be BF16 or FP32')

def version(t):
    try:return t._version
    except RuntimeError:return None

@dataclass
class PreparedWeight:
    original:torch.Tensor
    packed:torch.Tensor
    source_version:object
    def check(self):
        if version(self.original)!=self.source_version:raise ValueError('Weight changed; prepare again')
    def mm(self,a,b=None,out_dtype=torch.bfloat16):
        if b is not None:
            validate(a,b,out_dtype)
            if b.data_ptr()!=self.original.data_ptr():raise ValueError('Prepared weight belongs to another B')
        return engine().mm(a,self,out_dtype)

def prepare_weight(b):
    if b.shape!=(K,N) or b.stride()!=(1,K) or b.dtype!=torch.bfloat16 or not b.is_cuda:
        raise ValueError('B must be BF16 CUDA [5120,17408], stride (1,5120)')
    return PreparedWeight(b,pack_w(b),version(b))

def matmul(a,b,*,prepared_weight=None,out_dtype=torch.bfloat16):
    validate(a,b,out_dtype)
    prepared=prepared_weight or prepare_weight(b)
    return prepared.mm(a,b,out_dtype)
