# LightOp 与现有优化：W8A8 / BF16 输出对齐

实测节点 bw47，容器 zhuwenbo_sgl_0522，GPU5；固定 N=17408、K=5120、M=1..256。当前 LightOp 包和 hcu_sglang 包装接口作为基线；适配版保留冻结逐 M 选择，在 K 循环后融合 FP32 scale 与 BF16 输出。

## 结果

包含每次调用的激活重排，静态 W 提前重排：256个M点中 256 个更快。逐点加速 1.223–1.492x，耗时下降 18.24%–32.99%。这是同卡独立算子的Graph内GPU时间，不是模型请求端到端延时。

| M | LightOp us | Ours incl. X pack us | Ours GEMM only us | Speedup | Latency reduction |
|---:|---:|---:|---:|---:|---:|
| 1 | 95.344 | 70.271 | 67.267 | 1.357x | 26.30% |
| 8 | 96.889 | 70.929 | 67.804 | 1.366x | 26.79% |
| 16 | 98.038 | 73.067 | 69.536 | 1.342x | 25.47% |
| 32 | 99.782 | 74.367 | 70.749 | 1.342x | 25.47% |
| 64 | 103.333 | 75.982 | 72.182 | 1.360x | 26.47% |
| 65 | 108.011 | 75.796 | 72.100 | 1.425x | 29.83% |
| 96 | 110.053 | 77.667 | 73.427 | 1.417x | 29.43% |
| 128 | 109.524 | 79.307 | 75.244 | 1.381x | 27.59% |
| 129 | 118.327 | 79.291 | 75.613 | 1.492x | 32.99% |
| 160 | 119.724 | 81.451 | 77.409 | 1.470x | 31.97% |
| 176 | 119.971 | 83.298 | 79.180 | 1.440x | 30.57% |
| 192 | 120.369 | 84.596 | 80.362 | 1.423x | 29.72% |
| 193 | 120.480 | 86.873 | 82.522 | 1.387x | 27.89% |
| 208 | 121.362 | 87.269 | 82.840 | 1.391x | 28.09% |
| 224 | 121.633 | 89.700 | 85.116 | 1.356x | 26.25% |
| 240 | 122.431 | 94.651 | 89.893 | 1.293x | 22.69% |
| 256 | 117.902 | 96.391 | 91.916 | 1.223x | 18.24% |

## 输入、输出与权重准备

外部 W 仍为 INT8 [5120,17408]、stride=(1,5120)。prepare_weight 生成 PI16/K64 布局，packed W 为85 MiB/权重；本实现同时保留原 W，新增85 MiB存储。一次性 W 重排中位数 198.880 us/权重，不计入主表。公开函数不传 prepared_weight 时会当次重排 W；推理调用应提前准备并复用。

每次调用：连续INT8激活 -> GPU重排并补零至MP -> 原有INT8 MMAC / INT32累加 -> FP32(acc)*(sx*sw) -> BF16 RNE -> 连续[M,17408]输出。无完整INT32中间矩阵，也没有独立dequant kernel。sx [M,1]、sw [17408,1] 均为FP32。当前验证范围要求 bias=None、best_config=None、BF16输出和上述固定N/K/M。

## 正确性

两组BF16随机激活（含零行）、全范围随机INT8 W、FP32正scale，逐M覆盖全部256点，共 1,145,307,136 个BF16元素与合并scale顺序的参考逐位一致。W/X重排与冻结pack参考完整一致；CPU INT64点检校验方向和完整K。尾部guard、独立Graph回放通过，另有跨split-K分区的one-hot检查。

LightOp采用先合并sx*sw、再乘FP32(acc)的数值行为。初始74个代表点与该顺序逐位一致；全部768个正式组的每次主路径Graph回放也检查双方最后一份W的完整输出，均逐位一致。依次乘sx、sw会有少量BF16 1 ULP差异，因此正式版本及正式计时均采用合并scale。

## 代码与资源

- 原E030/E047和最新scalar-address / split-prefetch逐M路由保留。
- 10个大M函数的prologue和K主循环字节完全不变。E047两个入口新增一条scale指针加载，此后至输出段的原字节不变。E030保留K循环、发布和barrier，归约段在输出前汇总8组LDS INT32 partial；一条分支指向新尾部的位移重定位。详见bf16_kernels/manifest.json。
- BF16 epilogue复用已死VGPR，VGPR/LDS声明不增加。E030/E047增加scale指针SGPR，next_free_sgpr=28，metadata sgpr_count=32；大M tile SGPR不变。实际属性在kernel-attributes.json。
- LightOp M<=64显式slide9：逻辑M64xN64、256线程、272 CTA；CO元数据200 VGPR、88 SGPR、32 KiB LDS。
- LightOp M65..128自动分派：逻辑M128xN256、512线程、68 CTA；255 VGPR、102 SGPR、64 KiB LDS。
- LightOp M129..256自动分派：逻辑M256xN256、768线程、68 CTA；255 VGPR、102 SGPR、64 KiB LDS。
- 我方E030：M32xN64、128线程、272 CTA、72 VGPR、8 KiB LDS；E047：M128xN128、256线程、136 CTA、固定/通用123/128运行时VGPR、16 KiB LDS；大M BM144..256、BN128、256线程、136 CTA，LDS/VGPR按原策略。

布局、tile、线程数、资源和代码路径是已核对的实现差异；本轮没有逐因素消融，不把总收益单独归因于其中一项。

## 方法与边界

三组独立seed，每M每组七轮。每轮随机实现顺序，72份W轮转；原W和对应packed W数值相同。每种布局权重池约5.98 GiB，远大于此卡8 MiB L2。主表先取每seed七轮中位数，再取三seed中位数；CSV另存同轮配对比值。输出按各自公开接口分配；候选包含重排和纯GEMM两图共享相同BF16输出地址。同一stream GPU events计时，模块加载、JIT、Graph构建、CPU Python调用开销不计入。

频率采样 211 条：{"freq1_input": {"1499000000": 211}, "freq2_input": {"1800000000": 211}, "power_dpm_force_performance_level": {"manual": 211}}。18个代表点另测相同per_token_quant_int8 + 对应BF16 GEMM链路，见quantized-pipeline.csv。

## 保存与复现

原成果快照 optimized-preserved.tar.gz，SHA256=d8c6df82570354c7784fddddd480c476d99cb8af76efb8053627b4f60fc1ff07。源码、best二进制、最新逐M策略和已验证工件在frozen/。949 个原文件的结束复核差异数为 0。

API aligned_gemm.py；构建 build_bf16.py；验证 validate_bf16.py；计时 benchmark.py；逐点 latency-M1-256.csv；原始 benchmark-raw.json 和 benchmark-seed-*.jsonl；汇总 RESULT.json；图 lightop-vs-ours-BF16.png/.svg。LightOp包/CO哈希及三个当前CO在lightop-baseline-manifest.json / lightop_baseline/。本轮为独立适配与对比，生产分派和模型服务未替换。
