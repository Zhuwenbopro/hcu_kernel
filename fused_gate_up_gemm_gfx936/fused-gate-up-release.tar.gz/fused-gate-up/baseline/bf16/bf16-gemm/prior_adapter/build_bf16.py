from pathlib import Path
import re,json,subprocess,hashlib,struct,sys,yaml
R=Path(__file__).resolve().parent
F=R/'frozen'
OUT=R/'bf16_kernels'
OUT.mkdir(exist_ok=True)
MC='/opt/dtk/aillvm/bin/llvm-mc'
LD='/opt/dtk/aillvm/bin/ld.lld'
OD='/opt/dtk/aillvm/bin/llvm-objdump'
COMMON=F/'gemm_asm'
PLAN=json.loads((F/'integrated_validation/timing-plan.json').read_text())

def elf_symbols(path):
    data=Path(path).read_bytes()
    shoff=struct.unpack_from('<Q',data,40)[0]
    entsize,num=struct.unpack_from('<HH',data,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*entsize) for i in range(num)]
    result={}
    for sh in sections:
        if sh[1] not in (2,11):continue
        strings=sections[sh[6]]
        st=data[strings[4]:strings[4]+strings[5]]
        for off in range(sh[4],sh[4]+sh[5],sh[9]):
            name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',data,off)
            name=st[name:st.find(b'\0',name)].decode()
            if index and index<len(sections):
                sec=sections[index]
                result[name]={'value':value,'size':size,'body':data[sec[4]+value-sec[3]:sec[4]+value-sec[3]+size]}
    return result

def command(args):
    q=subprocess.run(args,capture_output=True,text=True)
    if q.returncode:raise RuntimeError(' '.join(args)+'\n'+q.stdout+q.stderr)
    return q.stdout

def compile_source(s,path):
    path.write_text(s)
    command([MC,'-I',str(COMMON),'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(path),'-o',str(path.with_suffix('.o'))])
    command([LD,'-shared',str(path.with_suffix('.o')),'-o',str(path.with_suffix('.hsaco'))])
    return path.with_suffix('.hsaco')

def metadata(s,extra_sgpr=False):
    s=re.sub(r'(\.amdhsa_kernarg_size\s+)40\b',r'\g<1>56',s)
    if extra_sgpr:
        s=re.sub(r'(\.amdhsa_next_free_sgpr\s+)\d+',r'\g<1>28',s)
    if '.amdgpu_metadata' in s:
        a,rest=s.split('.amdgpu_metadata',1)
        doc,b=rest.split('.end_amdgpu_metadata',1)
        m=yaml.safe_load(doc.expandtabs(8))
        for rec in m['amdhsa.kernels']:
            for key in ['.args','.unfolded_args']:
                if key in rec:
                    rec[key]+=[{'.address_space':'global','.offset':o,'.size':8,'.value_kind':'global_buffer'} for o in [40,48]]
            rec['.kernarg_segment_size']=56
            if extra_sgpr:rec['.sgpr_count']=32
        s=a+'.amdgpu_metadata\n---\n'+yaml.safe_dump(m,sort_keys=False)+'...\n.end_amdgpu_metadata'+b
    return s

def conversion(a,sx,sw,tmp,addr,offset,flags='glc slc'):
    out=[]
    for e in range(4):
        v=a+e
        out += [f'v_cvt_f32_i32 v{v}, v{v}',
                f'v_mul_f32_e32 v{tmp}, v{sx}, v{sw+e}',
                f'v_mul_f32_e32 v{v}, v{tmp}, v{v}',
                f'v_lshrrev_b32_e32 v{tmp}, 16, v{v}',
                f'v_and_b32_e32 v{tmp}, 1, v{tmp}',
                f'v_add_u32_e32 v{v}, 0x7fff, v{v}',
                f'v_add_u32_e32 v{v}, v{tmp}, v{v}']
    out += [f'v_lshrrev_b32_e32 v{a}, 16, v{a}',
            f'v_and_b32_e32 v{a+1}, 0xffff0000, v{a+1}',
            f'v_or_b32_e32 v{a}, v{a}, v{a+1}',
            f'v_lshrrev_b32_e32 v{a+2}, 16, v{a+2}',
            f'v_and_b32_e32 v{a+3}, 0xffff0000, v{a+3}',
            f'v_or_b32_e32 v{a+1}, v{a+2}, v{a+3}',
            f'global_store_dwordx2 v[{addr}:{addr+1}], v[{a}:{a+1}], off offset:{offset//2} {flags}']
    return '\n'.join(out)+'\n'

def mark(s,label,needle):
    if s.count(needle)==0 and needle=='GEMM_WAIT_VM 0\nv_mov_b32_e32':
        needle='GEMM_WAIT_VM 0\ns_load_dwordx4 s[0:3], s[4:5], 0x28'
    assert s.count(needle)==1,(label,needle)
    return s.replace(needle,f'.globl {label}\n{label}:\n'+needle,1)

def patch_generated(source,rec):
    # All K-loop instructions remain verbatim. Only the final output region changes.
    addr=list(range(rec['address_registers'][0],rec['address_registers'][-1]+1))
    col,row,offset,yptr=addr[3],addr[7],addr[8],addr[5]
    t=rec['accumulator_VGPR']
    stores=re.findall(r'GEMM_EPILOGUE_STORE_GLC_SLC v\[(\d+):\d+\], v\[(\d+):\d+\], (\w+)',source)
    offsets=sorted(set(int(z[2],0) for z in stores))
    sx=t+4*len(offsets);to=sx+1;tmp=sx+2
    assert tmp<addr[0],(rec['family'],tmp,addr)
    pos=source.rfind('GEMM_WAIT_VM 0\nv_mov_b32_e32')
    assert pos>=0
    pre,ep=source[:pos],source[pos:]
    ep=ep.replace('GEMM_WAIT_VM 0\n','GEMM_WAIT_VM 0\ns_load_dwordx4 s[0:3], s[4:5], 0x28\nGEMM_WAIT_LGKM 0\n',1)
    line=f'v_add_u32_e32 v{col}, s23, v{col}\n'
    assert ep.count(line)==1
    loads=''.join(f'global_load_dwordx4 v[{t+4*i}:{t+4*i+3}], v{col}, s[2:3] offset:{o}\n' for i,o in enumerate(offsets))
    ep=ep.replace(line,line+loads,1)
    pattern=rf'(v_mul_u32_u24_e32 v{offset}, 0x11000, v{row}\n)'
    ep,num=re.subn(pattern,f'v_lshlrev_b32_e32 v{to}, 2, v{row}\nglobal_load_dword v{sx}, v{to}, s[0:1]\n'+r'\1',ep)
    assert num==rec['BM']//16 if rec['direction']=='N' else num==rec['BM']//64
    line=f'v_add_u32_e32 v{offset}, v{col}, v{offset}\n'
    assert ep.count(line)==num
    ep=ep.replace(line,line+f'v_lshrrev_b32_e32 v{offset}, 1, v{offset}\n')
    pat=r'GEMM_EPILOGUE_STORE_GLC_SLC v\[(\d+):\d+\], v\[(\d+):\d+\], (\w+)\n'
    call=[0]
    def repl(m):
        ptr,a,o=int(m[1]),int(m[2]),int(m[3],0)
        prefix='GEMM_WAIT_VM 0\n' if call[0]%len(offsets)==0 else ''
        call[0]+=1
        return prefix+conversion(a,sx,t+4*offsets.index(o),tmp,ptr,o)
    ep=re.sub(pat,repl,ep)
    assert call[0]==len(stores)
    return pre+ep,'GEMM_WAIT_VM 0\nv_mov_b32_e32',pos

def epilogue(family,groups,sw,sx,tmp,row,col,colbyte,addr,mreg,yreg,row_base=None,wave=None):
    # Scalar scale addresses occupy s24:s27. All temporary VGPRs were dead after the K loop.
    code=['s_waitcnt vmcnt(0)',
          f'v_and_b32_e32 v{row}, 15, v0',
          f'v_lshrrev_b32_e32 v{col}, 4, v0',
          f'v_and_b32_e32 v{col}, 3, v{col}',
          f'v_lshlrev_b32_e32 v{col}, 2, v{col}']
    if family=='E030':
        code += [f'v_add_u32_e32 v{row}, s5, v{row}',f'v_add_u32_e32 v{col}, s4, v{col}']
    else:
        code += ['s_lshl_b32 s2, s6, 7',f'v_add_u32_e32 v{col}, s2, v{col}']
        if wave is not None:
            code += [f'v_lshlrev_b32_e32 v{tmp}, 5, v{wave}',f'v_add_u32_e32 v{row}, v{tmp}, v{row}']
        else:code += [f'v_add_u32_e32 v{row}, v{row_base}, v{row}']
    code += [f'v_lshlrev_b32_e32 v{colbyte}, 2, v{col}']
    for j in range(len(groups[0])):
        code += [f'global_load_dwordx4 v[{sw+4*j}:{sw+4*j+3}], v{colbyte}, s[26:27] offset:{j*64}']
    text='\n'.join(code)+'\n'
    for i,accs in enumerate(groups):
        skip=f'.L_{family}_bf16_skip_{i}'
        text+=f'v_cmp_gt_u32_e32 vcc, {mreg}, v{row}\ns_and_saveexec_b64 s[2:3], vcc\ns_cbranch_execz {skip}\n'
        text+=f'v_lshlrev_b32_e32 v{tmp}, 2, v{row}\nglobal_load_dword v{sx}, v{tmp}, s[24:25]\n'
        text+=f'v_mul_u32_u24_e32 v{tmp}, 17408, v{row}\nv_add_u32_e32 v{tmp}, v{col}, v{tmp}\nv_lshlrev_b32_e32 v{tmp}, 1, v{tmp}\n'
        text+=f'v_add_co_u32_e32 v{addr}, vcc, s{yreg}, v{tmp}\nv_mov_b32_e32 v{addr+1}, s{yreg+1}\nv_addc_co_u32_e32 v{addr+1}, vcc, 0, v{addr+1}, vcc\ns_waitcnt vmcnt(0)\n'
        for j,a in enumerate(accs):text+=conversion(a,sx,sw+4*j,tmp,addr,j*64)
        text+=f'{skip}:\ns_or_b64 exec, exec, s[2:3]\n'
        if i+1<len(groups):text+=f'v_add_u32_e32 v{row}, 16, v{row}\n'
    return text

def patch_e047(source):
    maps=[
        ('.LBB0_4:',[[57,61,65,69,53,49,41,33],[29,25,21,17,13,9,5,1]],
         dict(family='E047_fixed',sw=84,sx=116,tmp=117,row=120,col=121,colbyte=122,addr=118,mreg='128',yreg=8,wave=83)),
        ('.LBB1_12:',[[77,69,61,57,53,49,45,41],[37,33,21,17,13,9,5,1]],
         dict(family='E047_generic',sw=86,sx=118,tmp=119,row=122,col=123,colbyte=124,addr=120,mreg='s0',yreg=16,row_base=85))]
    s=source
    for needle,groups,kwargs in maps:
        start=s.index(needle)
        end=s.index('s_endpgm',start)
        s=s[:start]+needle+'\n'+epilogue(groups=groups,**kwargs)+s[end:]
    names=re.findall(r'^\s*\.globl\s+(\S+)',source,re.M)
    for name in names:
        s=re.sub(r'^('+re.escape(name)+r':.*\n)',r'\1s_load_dwordx4 s[24:27], s[4:5], 0x28\n',s,count=1,flags=re.M)
    return s,maps,names

def patch_e030(source):
    start=source.index('; %bb.9:')
    end=source.index('.LBB0_13:',start)
    # Preserve the K loop and the existing cross-wave publication/barrier.
    reduction=['; %bb.9:','v_lshlrev_b32_e32 v65, 4, v61']
    groups=[[17,21,25,29],[5,9,13,1]]
    accs=groups[0]+groups[1]
    for j in range(8):reduction.append(f'ds_read_b128 v[{33+j*4}:{36+j*4}], v65 offset:{j*1024}')
    reduction.append('s_waitcnt lgkmcnt(0)')
    for j,a in enumerate(accs):
        for e in range(4):reduction.append(f'v_add_u32_e32 v{a+e}, v{33+4*j+e}, v{a+e}')
    ep=epilogue('E030',groups,33,49,56,51,52,53,54,'s8',12)
    s=source[:start]+'\n'.join(reduction)+'\n'+ep+source[end:]
    name=re.search(r'^\s*\.globl\s+(\S+)',source,re.M)[1]
    s=re.sub(r'^('+re.escape(name)+r':.*\n)',r'\1s_load_dwordx4 s[24:27], s[4:5], 0x28\n',s,count=1,flags=re.M)
    return s,name

def audit_build(family,source,changed,gold,markers,extra_sgpr,entry_load):
    d=OUT/family;d.mkdir(exist_ok=True)
    control=source;candidate=changed
    for label,needle in markers:
        control=mark(control,label,needle)
        candidate=mark(candidate,label,needle)
    control_co=compile_source(control,d/'int32-control.s')
    candidate_co=compile_source(metadata(candidate,extra_sgpr),d/'bf16.s')
    old=elf_symbols(control_co);new=elf_symbols(candidate_co);goldsyms=elf_symbols(gold)
    records=[]
    for name in [n for n,z in goldsyms.items() if z['size'] and n in old and n in new and not n.endswith('.kd')]:
        if not old[name]['body'] or old[name]['body']!=goldsyms[name]['body']:continue
        label=next((l for l,_ in markers if old[name]['value']<=old[l]['value']<old[name]['value']+old[name]['size']),None)
        if label is None:continue
        length=old[label]['value']-old[name]['value']
        added=8 if entry_load else 0
        a=old[name]['body'][:length]
        b=new[name]['body'][added:new[label]['value']-new[name]['value']]
        assert len(a)==len(b),(family,name,len(a),len(b))
        diffs=[]
        for i in range(0,len(a),4):
            wa,wb=struct.unpack_from('<I',a,i)[0],struct.unpack_from('<I',b,i)[0]
            if wa!=wb:
                assert wa>>16==wb>>16 and 0xbf82<=wa>>16<=0xbf89,(family,name,i,hex(wa),hex(wb))
                diffs.append({'offset':i,'old':hex(wa),'new':hex(wb),'reason':'SOPP branch displacement to changed epilogue'})
        records.append({'function':name,'preserved_K_loop_bytes':length,'relocated_branches':diffs,'original_device_code_matches_frozen':True})
    assert len(records)==len(markers),(family,records,markers)
    (d/'device.disasm').write_text(command([OD,'-d','--mcpu=gfx936',str(candidate_co)]))
    return {'family':family,'path':str(candidate_co),'hsaco_sha256':hashlib.sha256(candidate_co.read_bytes()).hexdigest(),'audit':records}

results=[]
for rec in PLAN['records']:
    if rec['family'] not in set(PLAN['after'].values()):continue
    gold=F/'integrated_validation'/Path(rec['path']).relative_to('/home/metic/gemm-split-prefetch-integrated-locked-20261114')
    source=gold.with_suffix('.s').read_text()
    changed,needle,pos=patch_generated(source,rec)
    result=audit_build(rec['family'],source,changed,gold,[('audit_epilogue',needle)],False,False)
    result.update({k:rec[k] for k in ['function','BM','BN','NW','VGPR','SGPR','LDS','direction']})
    results.append(result)
    print('BUILT',rec['family'],flush=True)
source=(F/'gemm_asm/e047.s').read_text()
changed,maps,names=patch_e047(source)
results.append(audit_build('E047',source,changed,F/'gemm_asm/build/E047/kernel.hsaco',[(f'audit_epilogue_{i}',q[0]) for i,q in enumerate(maps)],True,True))
results[-1].update(functions=names,BM=128,BN=128,NW=4,LDS=16384)
print('BUILT E047',flush=True)
source=(F/'E030_assembly/kernel.s').read_text()
changed,name=patch_e030(source)
results.append(audit_build('E030',source,changed,F/'E030_assembly/device.co',[('audit_epilogue','; %bb.9:')],True,True))
results[-1].update(function=name,BM=32,BN=64,NW=2,LDS=8192)
print('BUILT E030',flush=True)
(OUT/'manifest.json').write_text(json.dumps(results,indent=2)+'\n')
print('BUILD_DONE',len(results),flush=True)
