"""Frozen gfx936 INT8 GEMM with per-row/per-column scales and fused BF16 output.

Scope: M=1..256, N=17408, K=5120; no bias. Static W is explicitly packed once.
The public B tensor retains shape [K,N], stride (1,K). All GPU work uses the
current PyTorch stream. Original source and binaries remain in frozen/.
"""
from pathlib import Path
from dataclasses import dataclass
import ctypes as C
import hashlib,json,math
import torch
import triton
import triton.language as tl
R=Path(__file__).resolve().parent
N,K=17408,5120

@triton.jit
def _pack_kernel(SRC,DST,rows,PAD:tl.constexpr,K:tl.constexpr,PI:tl.constexpr,BLOCK:tl.constexpr):
    z=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    rr=(z//16)%16
    if PI:rr=4*(rr%4)+rr//4
    row=((z//1024)%(PAD//16))*16+rr
    col=(z//(PAD*64))*64+((z//256)%4)*16+z%16
    v=tl.load(SRC+row*K+col,(z<PAD*K)&(row<rows),other=0)
    tl.store(DST+z,v,z<PAD*K)

def pack_a(a,mp,out=None):
    m,k=a.shape
    if out is None:out=torch.empty((K//64,mp//16,4,16,16),device=a.device,dtype=torch.int8)
    _pack_kernel[(triton.cdiv(mp*K,4096),)](a,out,m,mp,K,False,4096,num_warps=4)
    return out

def _pack_w(b,out=None):
    if out is None:out=torch.empty((K//64,N//16,4,16,16),device=b.device,dtype=torch.int8)
    _pack_kernel[(triton.cdiv(N*K,4096),)](b,out,N,N,K,True,4096,num_warps=4)
    return out

HIP=C.CDLL('libamdhip64.so')
HIP.hipGetErrorString.restype=C.c_char_p
HIP.hipModuleLoad.argtypes=[C.POINTER(C.c_void_p),C.c_char_p]
HIP.hipModuleGetFunction.argtypes=[C.POINTER(C.c_void_p),C.c_void_p,C.c_char_p]
HIP.hipModuleLaunchKernel.argtypes=[C.c_void_p]+[C.c_uint]*7+[C.c_void_p,C.POINTER(C.c_void_p),C.c_void_p]
HIP.hipFuncGetAttribute.argtypes=[C.POINTER(C.c_int),C.c_int,C.c_void_p]

def ok(rc):
    if rc:raise RuntimeError((rc,HIP.hipGetErrorString(rc).decode()))

class DeviceKernel:
    def __init__(self,path,name,nw,bm,bn,mp=None):
        self.path=str(path);self.name=name;self.nw=nw;self.bm=bm;self.bn=bn;self.fixed_mp=mp
        self.module=C.c_void_p();ok(HIP.hipModuleLoad(C.byref(self.module),self.path.encode()))
        self.fn=C.c_void_p();ok(HIP.hipModuleGetFunction(C.byref(self.fn),self.module,name.encode()))
        self.attributes={}
        for attr in [0,1,2,3,4]:
            v=C.c_int();ok(HIP.hipFuncGetAttribute(C.byref(v),attr,self.fn));self.attributes[str(attr)]=v.value
        if self.attributes['3']!=0:raise RuntimeError('Unexpected scratch allocation')
    def mp_for(self,m):return self.fixed_mp or math.ceil(m/self.bm)*self.bm
    def launch(self,xp,wp,y,m,sx=None,sw=None):
        mp=self.mp_for(m)
        vals=[C.c_void_p(t.data_ptr()) for t in [xp,wp,y]]+[C.c_int(v) for v in [m,N,K,mp]]
        if sx is not None:vals += [C.c_void_p(sx.data_ptr()),C.c_void_p(sw.data_ptr())]
        args=(C.c_void_p*len(vals))(*[C.addressof(x) for x in vals])
        ok(HIP.hipModuleLaunchKernel(self.fn,N//self.bn,math.ceil(m/self.bm),1,self.nw*64,1,1,0,C.c_void_p(torch.cuda.current_stream().cuda_stream),args,None))

class Engine:
    def __init__(self):
        plan=json.loads((R/'frozen/integrated_validation/timing-plan.json').read_text())
        manifest=json.loads((R/'bf16_kernels/manifest.json').read_text())
        self.routes=plan['after'];self.kernels={};self.raw={}
        for rec in manifest:
            path=R/'bf16_kernels'/rec['family']/'bf16.hsaco'
            if hashlib.sha256(path.read_bytes()).hexdigest()!=rec['hsaco_sha256']:
                raise RuntimeError('BF16 module hash mismatch')
            fam=rec['family']
            if fam=='E047':
                for name in rec['functions']:
                    key='E047_fixed' if 'Li128ELi17408ELi5120' in name else 'E047'
                    self.kernels[key]=DeviceKernel(path,name,4,128,128)
                    self.raw[key]=DeviceKernel(R/'frozen/gemm_asm/build/E047/kernel.hsaco',name,4,128,128)
            elif fam=='E030':
                self.kernels[fam]=DeviceKernel(path,rec['function'],2,32,64)
                self.raw[fam]=DeviceKernel(R/'frozen/E030_assembly/device.co',rec['function'],2,32,64)
            else:
                self.kernels[fam]=DeviceKernel(path,rec['function'],rec['NW'],rec['BM'],rec['BN'],256)
                original=next(q for q in plan['records'] if q['family']==fam)
                rawpath=R/'frozen/integrated_validation'/Path(original['path']).relative_to('/home/metic/gemm-split-prefetch-integrated-locked-20261114')
                self.raw[fam]=DeviceKernel(rawpath,rec['function'],rec['NW'],rec['BM'],rec['BN'],256)
    def key(self,m):
        if not 1<=m<=256:raise ValueError('Supported M is 1..256')
        f=self.routes[str(m)]
        return 'E047_fixed' if f=='E047' and m==128 else f
    def kernel(self,m,raw=False):return (self.raw if raw else self.kernels)[self.key(m)]
    def launch_packed(self,xp,wp,sx,sw,y,m):
        self.kernel(m).launch(xp,wp,y,m,sx,sw)
    def scaled_mm(self,a,prepared,sx,sw,out=None):
        validate(a,prepared.original,sx,sw,torch.bfloat16,None,None)
        prepared.check()
        m=a.shape[0]
        xp=pack_a(a,self.kernel(m).mp_for(m))
        if out is None:out=torch.empty((m,N),device=a.device,dtype=torch.bfloat16)
        elif out.shape!=(m,N) or out.dtype!=torch.bfloat16 or not out.is_contiguous() or out.device!=a.device:
            raise ValueError('Invalid output tensor')
        self.launch_packed(xp,prepared.packed,sx,sw,out,m)
        return out

_ENGINE=None
def engine():
    global _ENGINE
    if _ENGINE is None:_ENGINE=Engine()
    return _ENGINE

def _version(t):
    try:return t._version
    except RuntimeError:return None

def validate(a,b,sx,sw,out_dtype,bias,best_config):
    if out_dtype!=torch.bfloat16 or bias is not None or best_config is not None:
        raise ValueError('This validated specialization requires BF16, bias=None, best_config=None')
    if a.ndim!=2 or a.shape[1]!=K or not 1<=a.shape[0]<=256 or a.dtype!=torch.int8 or not a.is_contiguous() or not a.is_cuda:
        raise ValueError('A must be contiguous INT8 CUDA [M,5120], M=1..256')
    if b.shape!=(K,N) or b.stride()!=(1,K) or b.dtype!=torch.int8 or b.device!=a.device:
        raise ValueError('B must be INT8 [5120,17408], stride=(1,5120), on A device')
    if sx.shape!=(a.shape[0],1) or sw.shape!=(N,1) or sx.dtype!=torch.float32 or sw.dtype!=torch.float32 or not sx.is_contiguous() or not sw.is_contiguous() or sx.device!=a.device or sw.device!=a.device:
        raise ValueError('Scales must be contiguous FP32 [M,1] and [17408,1] on A device')

@dataclass
class PreparedWeight:
    original:torch.Tensor
    packed:torch.Tensor
    version:object
    def check(self):
        if _version(self.original)!=self.version:raise ValueError('Weight changed; prepare_weight again')
    def scaled_mm(self,a,b,scale_a,scale_b,out_dtype=torch.bfloat16,bias=None,best_config=None):
        validate(a,b,scale_a,scale_b,out_dtype,bias,best_config)
        if b.data_ptr()!=self.original.data_ptr() or b.shape!=self.original.shape or b.stride()!=self.original.stride():
            raise ValueError('PreparedWeight belongs to another B')
        return engine().scaled_mm(a,self,scale_a,scale_b)

def prepare_weight(b):
    if b.shape!=(K,N) or b.stride()!=(1,K) or b.dtype!=torch.int8 or not b.is_cuda:
        raise ValueError('Expected INT8 [5120,17408] with stride (1,5120)')
    return PreparedWeight(b,_pack_w(b),_version(b))

def triton_scaled_mm(a,b,scale_a,scale_b,out_dtype=torch.bfloat16,bias=None,best_config=None,*,prepared_weight=None):
    validate(a,b,scale_a,scale_b,out_dtype,bias,best_config)
    prepared=prepared_weight if prepared_weight is not None else prepare_weight(b)
    return prepared.scaled_mm(a,b,scale_a,scale_b,out_dtype,bias,best_config)
