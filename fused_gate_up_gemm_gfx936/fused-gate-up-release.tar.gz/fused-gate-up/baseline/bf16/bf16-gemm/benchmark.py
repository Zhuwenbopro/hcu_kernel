from tune import *
import threading,datetime,inspect,ctypes as C,hashlib,os
ROUNDS=7
LIGHTOP_POINTS={1,4,8,16,32,64,65,96,128,129,160,176,192,193,208,224,240,256}
SEEDS=[202611149931,202611149932,202611149933]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def clocks(stop):
    root=Path('/sys/bus/pci/devices/0000:c1:00.0')
    with (R/'clocks.jsonl').open('w') as out:
        while not stop.is_set():
            rec={'time':now()}
            for n in ['pp_dpm_sclk','pp_dpm_mclk','power_dpm_force_performance_level','mem_info_vram_used']:
                try:rec[n]=(root/n).read_text().strip()
                except OSError:pass
            for p in (root/'hwmon').glob('hwmon*/*'):
                if p.name in ['freq1_input','freq2_input','temp1_input','power1_average']:
                    try:rec[p.name]=p.read_text().strip()
                    except OSError:pass
            out.write(json.dumps(rec)+'\n');out.flush();stop.wait(1)

def main():
    assert json.loads((R/'tuning-result.json').read_text())['status']=='complete'
    eng=bg.engine()
    pci=C.create_string_buffer(64);bg.ok(bg.HIP.hipDeviceGetPCIBusId(pci,64,0))
    props=torch.cuda.get_device_properties(0)
    env={'torch':torch.__version__,'HIP':torch.version.hip,'device':str(props),'PCI':pci.value.decode(),'node':'bw47','GPU':5,'input_dtype':'bf16','output_dtype':'bf16','lightop_gemm':inspect.getsource(lightop_mm),'lightop_gemm_file':inspect.getfile(lightop_mm),'tuning_seed':202611149921,'formal_seeds':SEEDS,'rounds':ROUNDS,'copies':COPIES,'LightOp_points':sorted(LIGHTOP_POINTS),'policy_sha256':hashlib.sha256((R/'bf16-policy.json').read_bytes()).hexdigest(),'env':{k:v for k,v in os.environ.items() if k in ['TORCH_BLAS_PREFER_HIPBLASLT','PYTORCH_TUNABLEOP_ENABLED','PYTORCH_TUNABLEOP_TUNING','HIP_VISIBLE_DEVICES']}}
    for name in ['allow_tf32','allow_bf16_reduced_precision_reduction']:
        try:env[name]=bool(getattr(torch.backends.cuda.matmul,name))
        except Exception:pass
    save('environment.json',env)
    stop=threading.Event();thread=threading.Thread(target=clocks,args=(stop,),daemon=True);thread.start()
    groups=[];preparation=[]
    save('benchmark-status.json',{'status':'running','groups':0,'time':now()})
    try:
        for si,seed in enumerate(SEEDS):
            x,weights,prepared,ref64=pool(seed)
            print('POOL_READY',seed,flush=True)
            # Common BLAS/module initialization is outside all captured/timed graphs.
            tmp=torch.mm(x,weights[0]);tmp=lightop_mm(x,weights[0],torch.bfloat16);tmp=prepared[0].mm(x)
            torch.cuda.synchronize();del tmp
            wg,unused=capture(lambda:[bg.pack_w(w,out=p.packed) for w,p in zip(weights,prepared)])
            wg.replay();torch.cuda.synchronize()
            samples=[measure(wg) for _ in range(ROUNDS)]
            preparation.append({'seed':seed,'median_us':statistics.median(samples),'samples_us':samples,'weight_bytes':bg.N*bg.K*2})
            del wg,unused
            orderM=list(range(1,257));random.Random(seed).shuffle(orderM)
            with (R/f'benchmark-seed-{seed}.jsonl').open('w') as out:
                for mi,m in enumerate(orderM):
                    a=x[:m]
                    kernel=eng.kernel(m)
                    xp=bg.pack_a(a,kernel.mp_for(m))
                    # Warm each external baseline's shape/handle before capture.
                    tmp=torch.mm(a,weights[0])
                    if m in LIGHTOP_POINTS:tmp=lightop_mm(a,weights[0],torch.bfloat16)
                    torch.cuda.synchronize();del tmp
                    ours_graph,ours_y=capture(lambda:[pw.mm(a,b) for pw,b in zip(prepared,weights)])
                    lo_graph,lo_y=None,None
                    if m in LIGHTOP_POINTS:lo_graph,lo_y=capture(lambda:[lightop_mm(a,b,torch.bfloat16) for b in weights])
                    torch_graph,torch_y=capture(lambda:[torch.mm(a,b) for b in weights])
                    fused_graph,unused=capture(lambda:[eng.launch_packed(xp,pw.packed,y,m) for pw,y in zip(prepared,ours_y)])
                    graphs={'torch_mm':torch_graph,'ours_with_activation_pack':ours_graph,'ours_prepacked_activation':fused_graph}
                    if lo_graph is not None:graphs['lightop']=lo_graph
                    for _ in range(2):
                        for g in graphs.values():g.replay()
                    torch.cuda.synchronize()
                    for ys in [ours_y,torch_y]+([lo_y] if lo_y is not None else []):close_bf16(ys[-1],ref64[:m])
                    group={'seed':seed,'M':m,'family':eng.key(m),'MP':kernel.mp_for(m),'samples':[],'addresses':{'A':a.data_ptr(),'XP':xp.data_ptr(),'W0':weights[0].data_ptr(),'W71':weights[-1].data_ptr(),'WP0':prepared[0].packed.data_ptr(),'WP71':prepared[-1].packed.data_ptr(),'ours_Y71':ours_y[-1].data_ptr(),'lightop_Y71':lo_y[-1].data_ptr() if lo_y is not None else None,'torch_Y71':torch_y[-1].data_ptr()}}
                    rng=random.Random(seed+m)
                    for rnd in range(ROUNDS):
                        order=list(graphs);rng.shuffle(order)
                        row={'round':rnd,'order':order,'us':{}}
                        for f in order:
                            row['us'][f]=measure(graphs[f])
                            ys=lo_y if f=='lightop' else torch_y if f=='torch_mm' else ours_y
                            close_bf16(ys[-1],ref64[:m])
                        group['samples'].append(row)
                    group['accuracy']={f:metrics(ys[-1],ref64[:m]) for f,ys in [('ours',ours_y),('lightop',lo_y),('torch_mm',torch_y)] if ys is not None}
                    groups.append(group)
                    out.write(json.dumps(group,separators=(',',':'))+'\n');out.flush()
                    med={f:statistics.median(q['us'][f] for q in group['samples']) for f in graphs}
                    save('benchmark-status.json',{'status':'running','groups':len(groups),'seed':seed,'seed_index':si,'completed_M_this_seed':mi+1,'M':m,'family':eng.key(m),'median_us':med,'speedup_vs_lightop':med['lightop']/med['ours_with_activation_pack'] if 'lightop' in med else None,'speedup_vs_torch':med['torch_mm']/med['ours_with_activation_pack']})
                    if (mi+1)%16==0 or m in [1,32,64,128,129,192,193,256]:
                        print('TIMING',seed,mi+1,m,eng.key(m),{k:round(v,3) for k,v in med.items()},flush=True)
                    del graphs,ours_graph,lo_graph,torch_graph,fused_graph,ours_y,lo_y,torch_y,unused,xp
                    if mi%16==15:gc.collect()
            del x,weights,prepared,ref64
            gc.collect();torch.cuda.empty_cache()
        save('benchmark-raw.json',{'status':'complete','finished':now(),'groups':groups,'preparation':preparation,'seeds':SEEDS,'rounds':ROUNDS,'copies':COPIES,'environment':env})
        save('benchmark-status.json',{'status':'complete','groups':len(groups),'time':now()})
        print('BENCHMARK_DONE',len(groups),flush=True)
    finally:stop.set();thread.join(timeout=3)
if __name__=='__main__':
    try:main()
    except BaseException as e:
        save('benchmark-failure.json',{'error':str(e),'traceback':traceback.format_exc()});traceback.print_exc();sys.exit(1)
