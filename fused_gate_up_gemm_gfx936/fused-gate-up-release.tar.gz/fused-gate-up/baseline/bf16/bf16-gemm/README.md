# BF16 GEMM extension

A: contiguous BF16 [M,5120], M=1..256. B: BF16 [5120,17408], stride=(1,5120). Native BF16 MMAC with FP32 accumulation; BF16 RNE output.

```python
from bf16_gemm import prepare_weight, matmul
prepared = prepare_weight(w)  # once for static W
y = matmul(a, w, prepared_weight=prepared)
```

An optional out_dtype=torch.float32 returns the unrounded FP32 result. No quantization or scales are used. Warm up required shapes before Graph capture. The packed weight adds170 MiB if original W is retained. Omitting prepared_weight repacks W each call. Changing W requires prepare_weight again.

Use the same environment as the saved run. Build: python3 bf16_generator.py --build-all. Check: python3 smoke.py, then python3 validate.py. Select candidates: python3 tune.py. Formal benchmark: python3 benchmark.py. Analyze: python3 analyze.py.

Validation and benchmark scripts select physical GPU5 on BW47; review that setting before another node. The adapter inherits the caller's device mapping. Supported dimensions and complete accuracy/performance evidence are in REPORT.md / RESULT.json. This directory is independent of the preserved INT8 implementation.
