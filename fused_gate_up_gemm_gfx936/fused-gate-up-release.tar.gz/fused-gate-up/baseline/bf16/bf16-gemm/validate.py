from smoke import *
import numpy as np,statistics
POINTS={1,10,11,12,13,32,64,128,129,160,176,192,193,202,208,212,224,240,241,256}
def metrics(y,ref64):
    err=y.double()-ref64
    norm=float(torch.linalg.vector_norm(err).item()/max(torch.linalg.vector_norm(ref64).item(),1e-30))
    return {'max_abs_error':float(err.abs().max().item()),'relative_L2':norm,'finite':bool(torch.isfinite(y).all().item())}
def close_bf16(y,ref64):
    torch.testing.assert_close(y,ref64.bfloat16(),rtol=1/128,atol=1/256)
def main():
    assert json.loads((R/'smoke.json').read_text())['status']=='complete'
    eng=bg.engine();records=[]
    torch.backends.cuda.matmul.allow_tf32=False
    for seed in [202611149911,202611149912]:
        torch.manual_seed(seed)
        x=torch.randn((256,bg.K),device='cuda',dtype=torch.bfloat16)
        w=torch.randn((bg.N,bg.K),device='cuda',dtype=torch.bfloat16);b=w.t()
        pw=bg.prepare_weight(b)
        ref64=x.double()@w.double().T
        rs=[0,15,16,127,128,255];cs=[0,15,16,8703,8704,17407]
        cpu=x[rs].double().cpu().numpy()@w[cs].double().cpu().numpy().T
        np.testing.assert_allclose(cpu,ref64[rs][:,cs].cpu().numpy(),rtol=1e-12,atol=1e-12)
        for m in range(1,257):
            a=x[:m];kernel=eng.kernel(m)
            xp=bg.pack_a(a,kernel.mp_for(m))
            q,y=guard(m,torch.bfloat16)
            eng.launch_packed(xp,pw.packed,y,m)
            f=torch.empty((m,bg.N),device='cuda',dtype=torch.float32)
            eng.launch_packed(xp,pw.packed,f,m)
            check_guard(q)
            assert torch.equal(y.view(torch.int16),f.bfloat16().view(torch.int16)),('BF16 RNE',seed,m)
            fm=metrics(f,ref64[:m]);bm=metrics(y,ref64[:m])
            assert fm['max_abs_error']<.01 and fm['relative_L2']<5e-6 and fm['finite'],(seed,m,fm)
            close_bf16(y,ref64[:m])
            rec={'seed':seed,'M':m,'family':eng.key(m),'FP32':fm,'BF16':bm,'BF16_RNE_bit_exact':True,'BF16_diff_from_FP64_rounded':int((y!=ref64[:m].bfloat16()).sum().item()),'elements':y.numel(),'guards':True}
            # Both baselines are checked on all M for the first independent input.
            if seed==202611149911 or m in POINTS:
                lo=lightop_mm(a,b,torch.bfloat16);pt=torch.mm(a,b)
                close_bf16(lo,ref64[:m]);close_bf16(pt,ref64[:m])
                rec['LightOp']=metrics(lo,ref64[:m]);rec['torch_mm']=metrics(pt,ref64[:m])
            if m in POINTS:
                g=torch.cuda.CUDAGraph()
                with torch.cuda.graph(g):gy=bg.matmul(a,b,prepared_weight=pw)
                for _ in range(3):g.replay()
                torch.cuda.synchronize()
                assert torch.equal(gy.view(torch.int16),y.view(torch.int16))
                del g,gy
            records.append(rec)
            if m%32==0 or m in [1,128,129,193,256]:
                print('VALIDATE',seed,m,round(fm['max_abs_error'],7),round(bm['relative_L2'],7),flush=True)
                save('validation-progress.json',{'status':'running','seed':seed,'M':m,'cases':len(records)})
        del x,w,b,pw,ref64,q,y,f,xp
        torch.cuda.empty_cache()
    # IEEE nonfinite classes, without requiring a particular NaN payload.
    torch.manual_seed(202611149913)
    x=torch.randn((1,bg.K),device='cuda',dtype=torch.bfloat16)
    w=torch.randn((bg.N,bg.K),device='cuda',dtype=torch.bfloat16)
    x[0,0]=float('inf');w[0,0]=0;w[1,0]=float('nan')
    pw=bg.prepare_weight(w.t());y=pw.mm(x)
    ref64=x.double()@w.double().T
    assert torch.equal(torch.isnan(y),torch.isnan(ref64))
    assert torch.equal(torch.isposinf(y),torch.isposinf(ref64))
    assert torch.equal(torch.isneginf(y),torch.isneginf(ref64))
    save('validation.json',{'status':'complete','records':records,'FP64_reference':True,'CPU_spots_per_seed':36,'BF16_RNE_bit_exact':True,'BF16_tolerance':{'rtol':1/128,'atol':1/256},'IEEE_nonfinite_classes':True})
    save('validation-progress.json',{'status':'complete','cases':len(records)})
    print('VALIDATION_DONE',len(records),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException as e:
        save('validation-failure.json',{'error':str(e),'traceback':traceback.format_exc()});traceback.print_exc();sys.exit(1)
