
from pathlib import Path
import json,subprocess,hashlib,sys,collections,re
R=Path(__file__).resolve().parent
MC='/opt/dtk/aillvm/bin/llvm-mc';LD='/opt/dtk/aillvm/bin/ld.lld';OD='/opt/dtk/aillvm/bin/llvm-objdump'
sys.path.insert(0,str(R));from elf_tools import elf


DEFAULT_OUTPUT = R / 'generated-tiles'

def scale_u32(dst, src, factor):
 """Emit an exact constant multiply for the wave/CTA coordinates used here."""
 if type(factor) is not int or factor <= 0:
  raise ValueError('scale factor must be a positive integer')
 vector = dst.startswith('v')
 if not (vector and src.startswith('v') or dst.startswith('s') and src.startswith('s')):
  raise ValueError('scale operands must be vector/vector or scalar/scalar')
 if factor & (factor - 1) == 0:
  shift = factor.bit_length() - 1
  return f'v_lshlrev_b32_e32 {dst}, {shift}, {src}' if vector else f's_lshl_b32 {dst}, {src}, {shift}'
 # Vector callers supply only wave_id in0..3; both operands fit unsigned24bit.
 if vector:
  if factor >= 1 << 24:
   raise ValueError('vector wave-coordinate scale must fit unsigned24bit')
  return f'v_mul_u32_u24_e32 {dst}, {factor}, {src}'
 return f's_mul_i32 {dst}, {src}, {factor}'

def shared_copy_rounds(sf):
 """Each active wave copies one 1KiB fragment per round."""
 return [(q, min(4, sf - 4*q)) for q in range((sf + 3)//4)]

ADDRESS_MODES = ('none','private','shared','both')
PREFETCH_ORDERS = ('legacy','private_first','split_private_then_shared')

def kernel_layout(direction, bm, read_first=0, scalar_address='none', prefetch_order='legacy'):
 if direction not in ('M', 'N'):
  raise ValueError('direction must be M or N')
 if type(bm) is not int or bm <= 0:
  raise ValueError('BM must be a positive integer')
 align = 64 if direction == 'M' else 16
 if bm % align:
  raise ValueError(f'{direction}-split BM must be a multiple of{align}: four waves must own whole16-row MMAC fragments')
 pf = bm//64 if direction == 'M' else 2
 sf = 8 if direction == 'M' else bm//16
 if type(read_first) is not int or not 0 <= read_first <= sf:
  raise ValueError(f'read_first must be an integer in0..{sf}')
 if sf > 16:
  raise ValueError('current full LDS-read window supports at most16 fragments; change the read-window schedule before increasing this bound')
 if scalar_address not in ADDRESS_MODES:
  raise ValueError(f'scalar_address must be one of {ADDRESS_MODES}')
 if prefetch_order not in PREFETCH_ORDERS:
  raise ValueError(f'prefetch_order must be one of {PREFETCH_ORDERS}')
 if prefetch_order=='private_first' and read_first:
  raise ValueError('private_first has a full LDS read batch; specify read_first=0')
 if scalar_address in ('private','both') and pf>4:
  raise ValueError('scalar private SADDR supports at most4 fragments per wave')
 ac = 4*pf*sf
 p0=ac; p1=p0+4*pf; ds=p1+4*pf; t=ds+4*sf
 vgpr=t+12; lds=2*sf*1024
 if vgpr > 256:
  raise ValueError(f'VGPR budget{vgpr} exceeds256; reduce the operand/read window or tile')
 if lds > 65536:
  raise ValueError(f'LDS budget{lds} exceeds64KiB')
 by_wave = [len(range(wave, sf, 4)) for wave in range(4)]
 fam=f'{direction}{bm}'+(f'_SP{read_first}' if prefetch_order=='split_private_then_shared' else f'_RF{read_first}' if read_first else '')
 if prefetch_order=='private_first':fam+='_PF'
 if scalar_address!='none':fam+='_SA'+{'private':'P','shared':'S','both':'B'}[scalar_address]
 return dict(family=fam, read_first_fragments=read_first, scalar_address=scalar_address,
             prefetch_order=prefetch_order,
             current_reads_before_private=0 if prefetch_order=='private_first' else read_first,
             current_reads_before_shared=sf if prefetch_order in ('private_first','split_private_then_shared') else read_first,
             private_operand='X' if direction=='M' else 'W', shared_operand='W' if direction=='M' else 'X',
             BM=bm, BN=128, NW=4, PF=pf, SF=sf,
             VGPR=vgpr, SGPR=36, LDS=lds, scratch=0, accumulator_VGPR=ac,
             private_slot0=[p0,p1-1], private_slot1=[p1,ds-1],
             shared_fragments=[ds,t-1], address_registers=[t,t+11],
             MMAC_per_wave_K64=2*pf*sf, DS_read_per_wave_K64=sf,
             direct_load_per_wave_K64=pf,
             LDS_global_load_per_wave_K64=by_wave[0] if len(set(by_wave))==1 else by_wave,
             LDS_global_loads_by_wave_K64=by_wave,
             LDS_copy_rounds=shared_copy_rounds(sf))


def _advance_source(cfg):
 t=cfg['address_registers'][0]
 if cfg['scalar_address'] in ('private','both'):
  lo,hi=(8,9) if cfg['family'].startswith('M') else (10,11)
  return f's_add_u32 s{lo}, s{lo}, s18\ns_addc_u32 s{hi}, s{hi}, 0\nv_add_u32_e32 v{t+3}, s19, v{t+3}\n'
 return f'v_add_u32_e32 v{t+2}, s18, v{t+2}\nv_add_u32_e32 v{t+3}, s19, v{t+3}\n'

def _private_first_source(src,cfg):
 """P(next), D(current), S(next), compute; last D is unconditional."""
 sf=cfg['SF'];t=cfg['address_registers'][0];pitch=sf*1024;advance=_advance_source(cfg)
 pat=r'; issue private and shared stage to slot([01])\n(.*?)('+re.escape(advance)+')'
 stages=list(re.finditer(pat,src,re.S));assert len(stages)==3
 packets=[]
 for m in stages:
  body=m[2];loads=list(re.finditer(r'GEMM_[XW]_GLOBAL_(?:SADDR_)?TO_REG [^\n]+\n',body));assert len(loads)==cfg['PF']
  cut=loads[-1].end();packets.append({'P':body[:cut],'S':body[cut:],'advance':m[3]})
 pat=fr'v_add_u32_e32 v{t+9}, (0|{pitch}), v{t}\n(?:(?:GEMM_LDS_TO_REG|GEMM_WAIT_LGKM|GEMM_MMA_I8)[^\n]*\n)+'
 cons=list(re.finditer(pat,src));assert len(cons)==2;reads=[];maths=[]
 for m in cons:
  ls=m[0].splitlines(keepends=True);assert all('GEMM_LDS_TO_REG' in x for x in ls[1:sf+1])
  reads.append(''.join(ls[:sf+1]));maths.append(''.join(ls[sf+1:]))
 ready='GEMM_WAIT_VM 0\nGEMM_WAIT_LGKM 0\nGEMM_CTA_BARRIER\n'
 out=[ready,packets[1]['P'],reads[0],packets[1]['S'],packets[1]['advance'],maths[0],ready,'s_sub_u32 s24, s24, 1\n']
 for token in ['P','D','S']:
  if token=='D':out.append(reads[1]);continue
  label='.L_last_skip_'+token;out.extend([f's_cmp_eq_u32 s24, 0\ns_cbranch_scc1 {label}\n',packets[2][token],label+':\n'])
 out.extend([packets[2]['advance'],maths[1],'s_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0'])
 a=src.index('.L_pair:\n')+len('.L_pair:\n');marker='s_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0';b=src.index(marker,a)+len(marker)
 return src[:a]+''.join(out)+src[b:]


def _split_prefetch_source(src,cfg):
 """D_prefix(current), P(next), D_rest(current), S(next), compute.

 Both current-slot read groups remain unconditional in the final K64 pair.
 P and S use the existing, disjoint private/address/shared register windows.
 """
 sf=cfg['SF'];k=cfg['read_first_fragments'];t=cfg['address_registers'][0]
 advance=_advance_source(cfg)
 stages=list(re.finditer(r'; issue private and shared stage to slot([01])\n(.*?)('+re.escape(advance)+')',src,re.S))
 assert len(stages)==3
 packets=[]
 for m in stages:
  body=m[2]
  loads=list(re.finditer(r'GEMM_[XW]_GLOBAL_(?:SADDR_)?TO_REG [^\n]+\n',body))
  assert len(loads)==cfg['PF']
  cut=loads[-1].end()
  packets.append(dict(P=body[:cut],S=body[cut:],advance=m[3]))
 pattern=fr'v_add_u32_e32 v{t+9}, (0|{sf*1024}), v{t}\n(?:(?:GEMM_LDS_TO_REG|GEMM_WAIT_LGKM|GEMM_MMA_I8)[^\n]*\n)+'
 consumers=list(re.finditer(pattern,src))
 assert len(consumers)==2
 prefix=[];rest=[];math=[]
 for m in consumers:
  ls=m[0].splitlines(keepends=True)
  assert all('GEMM_LDS_TO_REG' in z for z in ls[1:sf+1])
  prefix.append(''.join(ls[:k+1]))
  rest.append(''.join(ls[k+1:sf+1]))
  math.append(''.join(ls[sf+1:]))
 ready='GEMM_WAIT_VM 0\nGEMM_WAIT_LGKM 0\nGEMM_CTA_BARRIER\n'
 out=[ready,prefix[0],packets[1]['P'],rest[0],packets[1]['S'],packets[1]['advance'],
      math[0],ready,'s_sub_u32 s24, s24, 1\n',prefix[1],
      's_cmp_eq_u32 s24, 0\ns_cbranch_scc1 .L_custom_skip_P\n',packets[2]['P'],
      '.L_custom_skip_P:\n',rest[1],
      's_cmp_eq_u32 s24, 0\ns_cbranch_scc1 .L_custom_skip_S\n',packets[2]['S'],
      packets[2]['advance'],'.L_custom_skip_S:\n',math[1],
      's_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0']
 a=src.index('.L_pair:\n')+len('.L_pair:\n')
 marker='s_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0'
 b=src.index(marker,a)+len(marker)
 return src[:a]+''.join(out)+src[b:]

def render_kernel(direction,bm,read_first=0,scalar_address='none',prefetch_order='legacy'):
 cfg=kernel_layout(direction,bm,read_first,scalar_address,prefetch_order)
 if prefetch_order=='split_private_then_shared':
  source,parent=render_kernel(direction,bm,0,scalar_address,'legacy')
  source=re.sub(r'\b'+re.escape(parent['family'])+r'\b',cfg['family'],source)
  return _split_prefetch_source(source,cfg),cfg
 sp=scalar_address in ('private','both');ss=scalar_address in ('shared','both')
 fam=cfg['family'];pf=cfg['PF'];sf=cfg['SF']
 ac=cfg['accumulator_VGPR'];p0=cfg['private_slot0'][0];p1=cfg['private_slot1'][0]
 ds=cfg['shared_fragments'][0];t=cfg['address_registers'][0]
 vgpr=cfg['VGPR'];lds=cfg['LDS'];slotbytes=sf*1024
 L=[]
 def w(s):L.append(s)
 def vr(i):return f'v{i}'
 def v4(i):return f'v[{i}:{i+3}]'
 def v2(i):return f'v[{i}:{i+1}]'
 w('; Physical-register gfx936 kernel, generated deterministically. No device compiler.')
 w('.include "common_gfx936.inc"\n.text\n.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"')
 w(f'.section .text.{fam},#alloc,#execinstr\n.protected {fam}\n.globl {fam}\n.p2align 8\n.type {fam},@function\n{fam}:')
 w('s_load_dwordx4 s[8:11], s[4:5], 0\ns_load_dwordx2 s[12:13], s[4:5], 0x10\ns_load_dword s14, s[4:5], 0x18\ns_load_dword s15, s[4:5], 0x24')
 w(f'v_and_b32_e32 {vr(t)}, 63, v0\nv_lshlrev_b32_e32 {vr(t)}, 4, {vr(t)}\nv_lshrrev_b32_e32 {vr(t+1)}, 6, v0\nv_lshlrev_b32_e32 {vr(t+3)}, 4, v0\nv_lshlrev_b32_e32 {vr(t+4)}, 10, {vr(t+1)}')
 w('GEMM_WAIT_LGKM 0\ns_lshl_b32 s16, s15, 6\ns_mov_b32 s17, 0x110000')
 # packedX CTA offset(tileM*BM*64), W CTA offset(tileN*128*64)
 w(scale_u32('s22','s7',bm))
 w('s_lshl_b32 s23, s6, 9')
 w('s_lshl_b32 s20, s6, 13')
 w(scale_u32('s21','s7',bm*64))
 if direction=='M':
  w('s_mov_b32 s0, s10\ns_add_u32 s1, s11, 0x40800000\ns_mov_b32 s18, s16\ns_mov_b32 s19, s17')
  plo,phi=8,9
 else:
  w('s_mov_b32 s0, s8\ns_add_u32 s1, s9, 0x40800000\ns_mov_b32 s18, s17\ns_mov_b32 s19, s16')
  # swap static CTA offsets; sharedX in s20, privateW in s21
  w('s_mov_b32 s26, s20\ns_mov_b32 s20, s21\ns_mov_b32 s21, s26');plo,phi=10,11
 w('s_mov_b32 s2, 0x80000000\ns_mov_b32 s3, 0x20000')
 w(scale_u32(vr(t+2),vr(t+1),pf*1024))
 if sp:w(f's_add_u32 s{plo}, s{plo}, s21\ns_addc_u32 s{phi}, s{phi}, 0')
 else:w(f'v_add_u32_e32 {vr(t+2)}, s21, {vr(t+2)}')
 w(f'v_add_u32_e32 {vr(t+2)}, {vr(t+2)}, {vr(t)}\nv_add_u32_e32 {vr(t+3)}, s20, {vr(t+3)}')
 if sf%4:
  w(f'v_readfirstlane_b32 s25, {vr(t+1)}')
 issue_serial=[0]
 def issue(slot):
  serial=issue_serial[0];issue_serial[0]+=1
  pr=p0 if slot==0 else p1
  w(f'; issue private and shared stage to slot{slot}')
  if sp:
   macro='GEMM_X_GLOBAL_SADDR_TO_REG' if direction=='M' else 'GEMM_W_GLOBAL_SADDR_TO_REG'
   for p in range(pf):w(f'{macro} {v4(pr+4*p)}, {vr(t+2)}, s[{plo}:{phi}], {p*1024}')
  else:
   w(f'v_add_co_u32_e32 {vr(t+5)}, vcc, s{plo}, {vr(t+2)}\nv_addc_co_u32_e32 {vr(t+6)}, vcc, 0, {vr(t+11)}, vcc')
   for p in range(pf):
    ad=t+5
    if p:
     w(f'v_add_co_u32_e32 {vr(t+7)}, vcc, {p*1024}, {vr(t+5)}\nv_addc_co_u32_e32 {vr(t+8)}, vcc, 0, {vr(t+6)}, vcc');ad=t+7
    macro='GEMM_X_GLOBAL_TO_REG' if direction=='M' else 'GEMM_W_GLOBAL_TO_REG'
    w(f'{macro} {v4(pr+4*p)}, {v2(ad)}')
  for q,active_waves in shared_copy_rounds(sf):
   label=f'.L_copy_skip_{serial}_{q}'
   if active_waves<4:
    w(f's_cmp_lt_u32 s25, {active_waves}\ns_cbranch_scc0 {label}')
   macro='GEMM_W_GLOBAL_TO_LDS' if direction=='M' else 'GEMM_X_GLOBAL_TO_LDS'
   if ss:
    dest=slot*slotbytes+q*4096
    w('s_mov_b32 m0, s26' if dest==0 else f's_add_u32 m0, s26, {dest}')
    off='0' if q==0 else f's{26+q}'
    w(f'{macro} {vr(t+3)}, s[0:3], {off}')
   else:
    w(f'v_add_u32_e32 {vr(t+7)}, {slot*slotbytes+q*4096}, {vr(t+4)}\nv_readfirstlane_b32 s26, {vr(t+7)}\ns_mov_b32 m0, s26')
    w(f'v_add_u32_e32 {vr(t+10)}, {q*4096}, {vr(t+3)}')
    w(f'{macro} {vr(t+10)}, s[0:3], 0')
   if active_waves<4:w(label+':')
  w(_advance_source(cfg).rstrip('\n'))
 def ready():w('GEMM_WAIT_VM 0\nGEMM_WAIT_LGKM 0\nGEMM_CTA_BARRIER')
 def read_shared(slot, first, stop):
  # Prefix loads are issued only after this slot has passed ready().
  if first==0:w(f'v_add_u32_e32 {vr(t+9)}, {slot*slotbytes}, {vr(t)}')
  for sh in range(first,stop):w(f'GEMM_LDS_TO_REG {v4(ds+4*sh)}, {vr(t+9)}, {sh*1024}')
 def consume(slot, already_read=0):
  pr=p0 if slot==0 else p1
  if already_read<sf:read_shared(slot,already_read,sf)
  for sh in range(sf):
   w(f'GEMM_WAIT_LGKM {sf-1-sh}')
   for h in range(2):
    for pp in range(pf):
     acc=4*(sh*pf+pp);xs=pr+4*pp+2*h if direction=='M' else ds+4*sh+2*h;ws=ds+4*sh+2*h if direction=='M' else pr+4*pp+2*h
     w(f'GEMM_MMA_I8 {v4(acc)}, {v2(xs)}, {v2(ws)}, {v4(acc)}')
 w(f'v_mov_b32_e32 {vr(t+11)}, s{phi}')
 if ss:w(f'v_readfirstlane_b32 s26, {vr(t+4)}\ns_mov_b32 s27, 4096\ns_mov_b32 s28, 8192\ns_mov_b32 s29, 12288')
 issue(0)
 for a in range(ac):w(f'v_mov_b32_e32 v{a}, 0')
 w('s_mov_b32 s24, 40\n.p2align 5\n.L_pair:')
 ready()
 if read_first:read_shared(0,0,read_first)
 issue(1);consume(0,read_first);ready()
 if read_first:read_shared(1,0,read_first)
 w('s_sub_u32 s24, s24, 1\ns_cmp_eq_u32 s24, 0\ns_cbranch_scc1 .L_skip_next')
 issue(0)
 w('.L_skip_next:');consume(1,read_first)
 w('s_cmp_lg_u32 s24, 0\ns_cbranch_scc1 .L_pair\nGEMM_WAIT_VM 0')
 # Epilogue: row strip for M direction, column strip for N direction.
 w(f'v_mov_b32_e32 {vr(t+11)}, s13')
 w(f'v_lshrrev_b32_e32 {vr(t+2)}, 4, {vr(t)}\nv_and_b32_e32 {vr(t+2)}, 15, {vr(t+2)}\nv_lshrrev_b32_e32 {vr(t+3)}, 8, {vr(t)}\nv_lshlrev_b32_e32 {vr(t+3)}, 4, {vr(t+3)}')
 w(scale_u32(vr(t+4),vr(t+1),pf*16))
 if direction=='M':w(f'v_add_u32_e32 {vr(t+2)}, {vr(t+4)}, {vr(t+2)}')
 else:w(f'v_lshlrev_b32_e32 {vr(t+4)}, 2, {vr(t+4)}\nv_add_u32_e32 {vr(t+3)}, {vr(t+4)}, {vr(t+3)}')
 w(f'v_add_u32_e32 {vr(t+2)}, s22, {vr(t+2)}\nv_add_u32_e32 {vr(t+3)}, s23, {vr(t+3)}')
 rows=pf if direction=='M' else sf
 for row in range(rows):
  w(f'v_add_u32_e32 {vr(t+7)}, {row*16}, {vr(t+2)}\nv_cmp_gt_u32_e32 vcc, s14, {vr(t+7)}\ns_and_saveexec_b64 s[28:29], vcc\ns_cbranch_execz .L_store_skip_{row}')
  w(f'v_mul_u32_u24_e32 {vr(t+8)}, 0x11000, {vr(t+7)}\nv_add_u32_e32 {vr(t+8)}, {vr(t+3)}, {vr(t+8)}\nv_add_co_u32_e32 {vr(t+5)}, vcc, s12, {vr(t+8)}\nv_addc_co_u32_e32 {vr(t+6)}, vcc, 0, {vr(t+11)}, vcc')
  cols=sf if direction=='M' else pf
  for col in range(cols):
   sh,pr=(col,row) if direction=='M' else (row,col);acc=4*(sh*pf+pr)
   w(f'GEMM_EPILOGUE_STORE_GLC_SLC {v2(t+5)}, {v4(acc)}, {col*64}')
  w(f'.L_store_skip_{row}:\ns_or_b64 exec, exec, s[28:29]')
 w('s_endpgm\n.L_func_end:')
 w(f'.size {fam}, .L_func_end-{fam}\n.section .rodata,#alloc\n.p2align 6\n.amdhsa_kernel {fam}')
 directives={'group_segment_fixed_size':lds,'private_segment_fixed_size':0,'kernarg_size':40,'user_sgpr_count':6,'user_sgpr_private_segment_buffer':1,'user_sgpr_dispatch_ptr':0,'user_sgpr_queue_ptr':0,'user_sgpr_kernarg_segment_ptr':1,'user_sgpr_dispatch_id':0,'user_sgpr_flat_scratch_init':0,'user_sgpr_private_segment_size':0,'uses_dynamic_stack':0,'system_sgpr_private_segment_wavefront_offset':0,'system_sgpr_workgroup_id_x':1,'system_sgpr_workgroup_id_y':1,'system_sgpr_workgroup_id_z':0,'system_sgpr_workgroup_info':0,'system_vgpr_workitem_id':0,'next_free_vgpr':vgpr,'next_free_sgpr':32,'reserve_flat_scratch':0,'reserve_xnack_mask':1,'float_round_mode_32':0,'float_round_mode_16_64':0,'float_denorm_mode_32':3,'float_denorm_mode_16_64':3,'dx10_clamp':1,'ieee_mode':1,'fp16_overflow':0}
 for k,v in directives.items():w(f'.amdhsa_{k} {v}')
 w('.end_amdhsa_kernel')
 old=(R/'e047_int8.s').read_text().split('.amdgpu_metadata',1)[1]
 kernel=old.split('amdhsa.kernels:',1)[1].split('  - .args:',2)[1]
 kernel='  - .args:'+kernel
 oldname='_Z8reg_E047ILi128ELi17408ELi5120EEvPKaS1_Piiiii'
 kernel=kernel.replace(oldname,fam).replace('.group_segment_fixed_size: 16384',f'.group_segment_fixed_size: {lds}').replace('.sgpr_count:     24','.sgpr_count:     36').replace('.vgpr_count:     123',f'.vgpr_count:     {vgpr}')
 target=old[old.index('amdhsa.target:'):old.index('...',old.index('amdhsa.target:'))]
 w('.amdgpu_metadata\n---\namdhsa.kernels:\n'+kernel+target+'...\n.end_amdgpu_metadata')
 src='\n'.join(L)+'\n'
 if prefetch_order=='private_first':src=_private_first_source(src,cfg)
 return src,cfg

def emit(direction,bm,output_dir=None,read_first=0,scalar_address='none',prefetch_order='legacy'):
 source,rec=render_kernel(direction,bm,read_first,scalar_address,prefetch_order);fam=rec['family']
 base=Path(output_dir or DEFAULT_OUTPUT).resolve()
 if base==R.resolve():
  raise ValueError('choose a separate output directory; historical measured artifacts are protected')
 out=base/fam;out.mkdir(parents=True,exist_ok=False)
 (out/'kernel.s').write_text(source)
 for cmd in [[MC,'--save-temp-labels','-I',str(R),'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(out/'kernel.s'),'-o',str(out/'kernel.o')],[LD,'-shared',str(out/'kernel.o'),'-o',str(out/'kernel.hsaco')]]:
  p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert p.returncode==0,(fam,p.stdout)
 dis=subprocess.check_output([OD,'-d','--mcpu=gfx936',str(out/'kernel.hsaco')],text=True);(out/'device.disasm').write_text(dis)
 note=subprocess.check_output(['/opt/dtk/aillvm/bin/llvm-readelf','--notes',str(out/'kernel.hsaco')],text=True);(out/'notes.txt').write_text(note)
 _,syms=elf((out/'kernel.hsaco').read_bytes());assert fam in syms,syms.keys()
 rec=dict(rec,path=str(out/'kernel.hsaco'),function=fam,hsaco_sha256=hashlib.sha256((out/'kernel.hsaco').read_bytes()).hexdigest())
 print('BUILT',json.dumps(rec),flush=True);return rec

def parse_variant(value):
 try:
  direction, bm = value.split(':')
  bm=int(bm)
 except (ValueError, TypeError):
  raise ValueError('variant must be M:192 or N:144, for example')
 kernel_layout(direction,bm)
 return direction,bm


def select_for_m(m,policy_path=None):
 """Return the validated exact-M choice. This fixed-N/K tile policy is M129..256."""
 if type(m) is not int:
  raise ValueError('M must be an integer')
 policy=policy_path if isinstance(policy_path,dict) else json.loads(Path(policy_path or R/'tile_schedule_policy.json').read_text())
 scope=policy['scope']
 if (scope['N'],scope['K'])!=(17408,5120):
  raise ValueError('policy shape does not match this fixed-N/K generator')
 lo,hi=scope['M_range']
 if not lo<=m<=hi:
  raise ValueError(f'M must be in the measured policy range {lo}..{hi}')
 if str(m) not in policy['best_by_M']:
  raise ValueError(f'policy has no measured entry for M={m}')
 choice=dict(policy['best_by_M'][str(m)])
 cfg=kernel_layout(choice['direction'],choice['BM'],choice.get('read_first',0),
                   choice.get('scalar_address','none'),choice.get('prefetch_order','legacy'))
 for key in ['family','BN','VGPR','LDS']:
  if key in choice and choice[key]!=cfg[key]:
   raise ValueError(f'policy {key} disagrees with generated layout at M={m}')
 mp=scope['MP']
 if ((m+cfg['BM']-1)//cfg['BM'])*cfg['BM']>mp:
  raise ValueError('policy MP does not cover the selected CTA grid')
 choice.update(M=m,N=scope['N'],K=scope['K'],MP=mp)
 return choice

def main(argv=None):
 import argparse
 ap=argparse.ArgumentParser(description='Generate gfx936 INT8 GEMM CTA tiles; four waves, BN128, N17408, K5120. Does not launch GPU kernels.')
 specs_args=ap.add_mutually_exclusive_group()
 specs_args.add_argument('--variant',action='append',metavar='DIRECTION:BM',help='repeatable, e.g. --variant M:192 --variant N:144')
 specs_args.add_argument('--M',dest='actual_M',action='append',type=int,metavar='M',help='select exact measured best_by_M entry; repeatable and deduplicates shared kernels; defaults to bundled policy')
 ap.add_argument('--output-dir',type=Path,default=DEFAULT_OUTPUT)
 schedule_args=ap.add_mutually_exclusive_group()
 schedule_args.add_argument('--schedule-policy',type=Path,help='measured per-tile or exact-M policy JSON')
 schedule_args.add_argument('--read-first',type=int,default=None,help='legacy: current LDS reads before both prefetches; split: before private prefetch; range 0..SF')
 ap.add_argument('--scalar-address',choices=ADDRESS_MODES,default=None,help='scalarize private/shared/both address paths; default follows policy or none')
 ap.add_argument('--prefetch-order',choices=PREFETCH_ORDERS,default=None,help='legacy, private_first (read-first 0), or split_private_then_shared (Dk,P,Drest,S)')
 ap.add_argument('--check-only',action='store_true',help='print validated resource budgets without writing or assembling files')
 args=ap.parse_args(argv)
 try:
  selected={}
  if args.actual_M:
   if len(args.actual_M)!=len(set(args.actual_M)):raise ValueError('duplicate M values')
   if any(v is not None for v in [args.read_first,args.scalar_address,args.prefetch_order]):
    raise ValueError('--M uses the measured policy; use --variant for manual overrides')
   policy=json.loads((args.schedule_policy or R/'tile_schedule_policy.json').read_text())
   unique={}
   for m in args.actual_M:
    choice=select_for_m(m,policy)
    setting=dict(read_first=choice.get('read_first',0),scalar_address=choice.get('scalar_address','none'),prefetch_order=choice.get('prefetch_order','legacy'))
    cfg=kernel_layout(choice['direction'],choice['BM'],**setting)
    selected[m]=cfg['family']
    unique[cfg['family']]=((choice['direction'],choice['BM']),setting)
   specs=[v[0] for v in unique.values()]
   settings=[v[1] for v in unique.values()]
  else:
   specs=[parse_variant(v) for v in args.variant] if args.variant else [(d,b) for b in [128,256] for d in ['M','N']]
   if len(specs)!=len(set(specs)):raise ValueError('duplicate variants')
   policy={}
   if args.schedule_policy:
    config=json.loads(args.schedule_policy.read_text())
    if (config['scope']['N'],config['scope']['K'])!=(17408,5120):raise ValueError('policy shape does not match this fixed-N/K generator')
    policy=config['tiles']
   settings=[]
   for d,b in specs:
    v=policy.get(f'{d}{b}',{})
    settings.append(dict(read_first=args.read_first if args.read_first is not None else int(v.get('read_first',0)),
                         scalar_address=args.scalar_address if args.scalar_address is not None else v.get('scalar_address','none'),
                         prefetch_order=args.prefetch_order if args.prefetch_order is not None else v.get('prefetch_order','legacy')))
  budgets=[kernel_layout(d,b,**v) for (d,b),v in zip(specs,settings)]
  if selected:
   for v in budgets:v['selected_Ms']=[m for m,f in selected.items() if f==v['family']]
  if args.check_only:
   print(json.dumps(budgets,indent=2));return 0
  base=args.output_dir.resolve()
  if base==R.resolve():raise ValueError('choose a separate output directory; historical measured artifacts are protected')
  if (base/'variants.json').exists():raise ValueError('output variants.json already exists; select a fresh output directory')
  if any((base/v['family']).exists() for v in budgets):raise ValueError('output variant already exists; select a fresh output directory')
  out=[emit(d,b,base,**v) for (d,b),v in zip(specs,settings)]
  if selected:
   for v in out:v['selected_Ms']=[m for m,f in selected.items() if f==v['family']]
   (base/'selection_by_M.json').write_text(json.dumps(dict(scope=policy['scope'],policy=str(args.schedule_policy or R/'tile_schedule_policy.json'),best_by_M=selected),indent=2)+'\n')
  (base/'variants.json').write_text(json.dumps(out,indent=2)+'\n')
  return 0
 except (ValueError,KeyError) as e:
  ap.error(str(e))

if __name__=='__main__':
 raise SystemExit(main())
