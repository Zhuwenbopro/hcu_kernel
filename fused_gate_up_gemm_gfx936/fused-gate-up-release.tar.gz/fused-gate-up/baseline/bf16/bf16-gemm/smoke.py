import os
os.environ['HIP_VISIBLE_DEVICES']='5'
for k in ['CUDA_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL']:os.environ.pop(k,None)
os.environ['OMP_NUM_THREADS']='8'
from pathlib import Path
import json,traceback,sys
import torch
torch.set_num_threads(8)
import bf16_gemm as bg
from lightop.gemmopt import gemm as lightop_mm
R=Path(__file__).resolve().parent
def save(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
def ref_pack(t,pad,pi=False):
    rows,k=t.shape
    if pi:
        perm=torch.tensor([4*(p%4)+p//4 for p in range(16)],device=t.device)
        t=t.view(rows//16,16,k)[:,perm,:].reshape(rows,k)
    if pad>rows:t=torch.cat([t,torch.zeros((pad-rows,k),device=t.device,dtype=t.dtype)],dim=0)
    return t.view(pad//16,16,k//32,4,8).permute(2,0,3,1,4).contiguous()
def guard(m,dtype):
    q=torch.full((m*bg.N+2048,),0x5a5a,dtype=torch.int16 if dtype==torch.bfloat16 else torch.int32,device='cuda')
    y=q[1024:-1024].view(dtype).view(m,bg.N)
    return q,y
def check_guard(q):
    assert bool((q[:1024]==0x5a5a).all().item() and (q[-1024:]==0x5a5a).all().item())
def main():
    torch.manual_seed(202611149901)
    eng=bg.engine()
    save('kernel-attributes.json',{f'{key[0]}:{key[1]}':k.info for key,k in eng.kernels.items()})
    x=torch.randint(-3,4,(256,bg.K),device='cuda').to(torch.bfloat16)
    w=torch.randint(-3,4,(bg.N,bg.K),device='cuda').to(torch.bfloat16);b=w.t()
    pw=bg.prepare_weight(b)
    assert torch.equal(pw.packed,ref_pack(w,bg.N,True))
    ref=x.float()@w.float().T
    records=[]
    for key,kernel in eng.kernels.items():
        fam,kind=key;dtype=torch.bfloat16 if kind=='bf16' else torch.float32
        if fam=='E047_fixed':ms=[128]
        elif fam in ['E030','E047']:ms=[1,12,32,64,128,129,256]
        elif kernel.bm==128:ms=[1,128,129,256]
        else:ms=sorted(set([1,kernel.bm-15,kernel.bm]))
        for m in ms:
            xp=bg.pack_a(x[:m],kernel.mp_for(m))
            assert torch.equal(xp,ref_pack(x[:m],kernel.mp_for(m)))
            q,y=guard(m,dtype)
            kernel.launch(xp,pw.packed,y,m)
            torch.cuda.synchronize()
            expected=ref[:m].to(dtype)
            bad=int((y!=expected).sum().item())
            if bad:
                ix=torch.nonzero(y!=expected)[:5].cpu().tolist()
                raise RuntimeError({'family':fam,'dtype':kind,'M':m,'bad':bad,'first':[(v,float(y[tuple(v)]),float(expected[tuple(v)])) for v in ix]})
            check_guard(q);records.append({'family':fam,'dtype':kind,'M':m,'elements':y.numel(),'bad':0,'guards':True})
        print('SMOKE',fam,kind,ms,flush=True)
    # Distinguish both K half-waves and the last K32 block with one-hot inputs.
    positions=[0,3,7,8,15,16,31,32,63,64,2559,2560,5088,5119]
    x.zero_()
    for i in range(256):x[i,positions[i%len(positions)]]=1
    ref=x.float()@w.float().T
    for m in [1,12,13,64,128,129,192,193,256]:
        y=pw.mm(x[:m])
        assert torch.equal(y,ref[:m].bfloat16()),('one-hot',m)
    baselines=[]
    for m in [1,16,32,64,128,129,256]:
        lo=lightop_mm(x[:m],b,torch.bfloat16)
        pt=torch.mm(x[:m],b)
        lb=int((lo!=ref[:m].bfloat16()).sum().item())
        pb=int((pt!=ref[:m].bfloat16()).sum().item())
        baselines.append({'M':m,'lightop_bad':lb,'torch_bad':pb})
        assert lb==0 and pb==0,baselines[-1]
    save('smoke.json',{'status':'complete','records':records,'baselines':baselines,'one_hot_K_positions':positions,'input_dtype':'bf16','accumulator':'fp32','output_dtype':['bf16','fp32']})
    print('SMOKE_DONE',len(records),baselines,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException as e:
        save('smoke-failure.json',{'error':str(e),'traceback':traceback.format_exc()});traceback.print_exc();sys.exit(1)
