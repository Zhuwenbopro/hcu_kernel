from pathlib import Path
import json,statistics,csv,collections,math,hashlib,os,sys
R=Path(__file__).resolve().parent
raw=json.loads((R/'benchmark-raw.json').read_text())
assert raw['status']=='complete' and len(raw['groups'])==768
for seed in raw['seeds']:assert {g['M'] for g in raw['groups'] if g['seed']==seed}==set(range(1,257))
F=['torch_mm','ours_with_activation_pack','ours_prepacked_activation']
points=[]
for m in range(1,257):
    gs=[g for g in raw['groups'] if g['M']==m]
    row={'M':m,'family':gs[0]['family'],'MP':gs[0]['MP']}
    perseed={g['seed']:{f:statistics.median(s['us'][f] for s in g['samples']) for f in F} for g in gs}
    for f in F:row[f+'_us']=statistics.median(p[f] for p in perseed.values())
    row['speedup_vs_torch']=row['torch_mm_us']/row['ours_with_activation_pack_us']
    row['latency_reduction_vs_torch_pct']=(1-1/row['speedup_vs_torch'])*100
    row['paired_speedup_vs_torch']=statistics.median(statistics.median(s['us']['torch_mm']/s['us']['ours_with_activation_pack'] for s in g['samples']) for g in gs)
    row['seed_speedups_vs_torch']={str(s):p['torch_mm']/p['ours_with_activation_pack'] for s,p in perseed.items()}
    if all('lightop' in g['samples'][0]['us'] for g in gs):
        row['lightop_us']=statistics.median(statistics.median(s['us']['lightop'] for s in g['samples']) for g in gs)
        row['speedup_vs_lightop']=row['lightop_us']/row['ours_with_activation_pack_us']
    else:row['lightop_us']=None;row['speedup_vs_lightop']=None
    row['measured_pack_difference_us']=row['ours_with_activation_pack_us']-row['ours_prepacked_activation_us']
    row['accuracy_relative_L2_max']=max(g['accuracy']['ours']['relative_L2'] for g in gs)
    points.append(row)
fields=[k for k in points[0] if k!='seed_speedups_vs_torch']
with (R/'latency-M1-256.csv').open('w',newline='') as out:
    w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows({k:v for k,v in p.items() if k in fields} for p in points)
native=[p for p in points if p['lightop_us'] is not None]
with (R/'lightop-representative-points.csv').open('w',newline='') as out:
    w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows({k:v for k,v in p.items() if k in fields} for p in native)
ranges=[]
for lo,hi in [(1,32),(33,64),(65,128),(129,192),(193,256),(1,256)]:
    ps=[p for p in points if lo<=p['M']<=hi]
    ranges.append({'M_range':[lo,hi],'points':len(ps),'wins_vs_torch':sum(p['speedup_vs_torch']>1 for p in ps),'torch_mean_us':statistics.mean(p['torch_mm_us'] for p in ps),'ours_mean_us':statistics.mean(p['ours_with_activation_pack_us'] for p in ps),'min_speedup_vs_torch':min(p['speedup_vs_torch'] for p in ps),'max_speedup_vs_torch':max(p['speedup_vs_torch'] for p in ps),'median_speedup_vs_torch':statistics.median(p['speedup_vs_torch'] for p in ps)})
v=json.loads((R/'validation.json').read_text());smoke=json.loads((R/'smoke.json').read_text())
accuracy={'normal_cases':len(v['records']),'BF16_elements':sum(z['elements'] for z in v['records']),'FP32_max_abs_error_vs_FP64':max(z['FP32']['max_abs_error'] for z in v['records']),'FP32_max_relative_L2_vs_FP64':max(z['FP32']['relative_L2'] for z in v['records']),'BF16_max_relative_L2_vs_FP64':max(z['BF16']['relative_L2'] for z in v['records']),'BF16_RNE_matches_FP32_cast':all(z['BF16_RNE_bit_exact'] for z in v['records']),'all_guards':all(z['guards'] for z in v['records']),'one_hot_and_integer_cases':len(smoke['records']),'IEEE_nonfinite_classes':v['IEEE_nonfinite_classes'],'FP64_reference_CPU_spots_per_seed':v['CPU_spots_per_seed'],'BF16_comparison_tolerance':v['BF16_tolerance'],'timed_groups':len(raw['groups']),'timed_replays_checked':sum(len(g['samples'])*len(g['samples'][0]['us']) for g in raw['groups'])}
clockrows=[json.loads(z) for z in (R/'clocks.jsonl').read_text().splitlines()]
clocks={k:dict(collections.Counter(z.get(k,'missing') for z in clockrows)) for k in ['freq1_input','freq2_input','power_dpm_force_performance_level']}
prep=statistics.median(p['median_us'] for p in raw['preparation'])
policy=json.loads((R/'bf16-policy.json').read_text())
counts=dict(collections.Counter(policy['by_M'].values()))
near_ties=[p['M'] for p in points if abs(p['speedup_vs_torch']-1)<.005]
clear_wins=sum(p['speedup_vs_torch']>=1.005 for p in points)
clear_losses=sum(p['speedup_vs_torch']<=.995 for p in points)
summary={'near_tie_M':near_ties,'clear_wins_vs_torch':clear_wins,'clear_losses_vs_torch':clear_losses,'status':'complete','scope':{'M':[1,256],'N':17408,'K':5120,'A':'BF16 contiguous [M,K]','B':'BF16 [K,N] stride (1,K)','accumulation':'native BF16 MMAC with FP32 accumulation','output':'BF16 with RNE; FP32 debug output also available'},'method':{'node':'bw47','container':'zhuwenbo_sgl_0522','GPU':5,'formal_seeds':raw['seeds'],'rounds':raw['rounds'],'copies':raw['copies'],'tuning_seed':policy['training_seed'],'weight_bytes_each':17408*5120*2,'weight_pool_bytes_each_layout':72*17408*5120*2,'main_scope':'BF16 activation pack + BF16 GEMM + fused BF16 output; static weight preparation excluded','torch_points':256,'LightOp_points':[p['M'] for p in native],'aggregation':'median rounds per seed, then median of three independent holdout seeds'},'environment':raw['environment'],'ranges':ranges,'points':points,'accuracy':accuracy,'clocks':clocks,'clock_samples':len(clockrows),'weight_preparation_us':prep,'weight_preparation':raw['preparation'],'policy_counts':counts,'instruction_audit':json.loads((R/'instruction-audit.json').read_text()),'prior_preserved':json.loads((R/'PRESERVED.json').read_text())}
(R/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
# Existing, server-side plotting dependencies; no installation or environment mutation.
sys.path.insert(0,'/home/zmoe/experiments/int8-bw90-20261110/nodes/S001/plot-deps')
os.environ['MPLCONFIGDIR']=str(R/'mpl-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,1,figsize=(12,7.7),sharex=True,gridspec_kw={'height_ratios':[2.1,1]})
ms=[p['M'] for p in points]
axs[0].plot(ms,[p['torch_mm_us'] for p in points],label='torch.mm: BF16 -> BF16',color='#d45041',lw=1.6)
axs[0].plot(ms,[p['ours_with_activation_pack_us'] for p in points],label='Ours: activation pack + BF16 GEMM',color='#1e70bd',lw=1.8)
axs[0].plot(ms,[p['ours_prepacked_activation_us'] for p in points],label='Ours: BF16 GEMM only',color='#279976',lw=1.3)
axs[0].set_ylabel('GPU latency per call (us)');axs[0].legend(frameon=False,loc='upper left')
axs[1].plot(ms,[p['speedup_vs_torch'] for p in points],color='#1e70bd',lw=1.6)
axs[1].axhline(1,color='gray',ls='--',lw=1);axs[1].set_ylabel('torch.mm / ours');axs[1].set_xlabel('M (token rows)')
for ax in axs:
    ax.grid(alpha=.18);ax.set_xlim(1,256)
    for n in [32,64,128,192]:ax.axvline(n,color='gray',alpha=.25,ls=':',lw=.8)
axs[1].set_xticks([1,32,64,96,128,160,192,224,256])
fig.suptitle('BF16 x BF16 -> BF16: N=17408, K=5120',fontsize=16,y=.975)
fig.text(.5,.928,'BW47 gfx936 GPU 5 | 1499/1800 MHz | 3 seeds x 7 rounds x 72 weights | ours: static W packed offline',ha='center',fontsize=10,color='#444')
fig.tight_layout(rect=[.015,.015,.995,.91])
fig.savefig(R/'bf16-vs-torch.png',dpi=180);fig.savefig(R/'bf16-vs-torch.svg');plt.close(fig)
fig,ax=plt.subplots(figsize=(11,5))
for key,label,color in [('lightop_us','LightOp current BF16 entry','#888888'),('torch_mm_us','torch.mm','#d45041'),('ours_with_activation_pack_us','Ours including activation pack','#1e70bd')]:
    ax.plot([p['M'] for p in native],[p[key] for p in native],marker='o',ms=3,label=label,color=color)
ax.set_yscale('log');ax.set_xlabel('M');ax.set_ylabel('GPU latency per call (us, log scale)');ax.legend(frameon=False);ax.grid(alpha=.2)
ax.set_title('BF16 comparison: 18 measured representative points')
fig.tight_layout();fig.savefig(R/'bf16-lightop-representative.png',dpi=180);plt.close(fig)
fence=chr(96)*3
def table(ps):
    a=['| M | torch.mm us | LightOp us | Ours incl. X pack us | Ours GEMM only us | Speedup vs torch |','|---:|---:|---:|---:|---:|---:|']
    for p in ps:
        lo='-' if p['lightop_us'] is None else f"{p['lightop_us']:.3f}"
        a.append(f"| {p['M']} | {p['torch_mm_us']:.3f} | {lo} | {p['ours_with_activation_pack_us']:.3f} | {p['ours_prepacked_activation_us']:.3f} | {p['speedup_vs_torch']:.3f}x |")
    return '\n'.join(a)
selected=[p for p in points if p['M'] in [1,2,4,8,16,32,64,65,96,128,129,160,176,192,193,208,224,240,256]]
report=f"""# BF16 输入、BF16 输出：模块化汇编扩展

实测 bw47 / zhuwenbo_sgl_0522 / GPU5。范围为 M1..256、N17408、K5120；A、B均为BF16，使用原生 BF16 MMAC，FP32累加，BF16输出。B外部布局仍为[K,N]、stride=(1,K)，W可提前重排。本轮为独立适配版，未替换模型服务入口。

## 实测结果

包含每次调用的BF16激活重排，静态W提前重排。torch.mm全256点，当前LightOp BF16入口抽测18点。训练候选选择使用单独seed，正式结果来自三个未参与选路的seed，每组七轮、每图72份W轮转；先取每seed中位，再取三个seed中位。

{table(selected)}

对torch.mm，中位数比值范围 {min(p['speedup_vs_torch'] for p in points):.3f}–{max(p['speedup_vs_torch'] for p in points):.3f}x。接近持平（比值距1不足0.5%）的M为 {near_ties}；其余 {clear_wins} 点更快、{clear_losses} 点更慢。区间统计及同轮配对比值见RESULT.json和latency-M1-256.csv。LightOp数据来自已安装gemmopt.gemm -> op.gemm_opt入口，使用当前二进制而非根据仓库旧代码推测；它在这组形状明显慢于torch.mm，因此主图以torch.mm作更强基线。18点完整对照见lightop-representative-points.csv。

这些是Graph内GPU时间；CPU调用、首次模块加载/JIT、Graph构建、一次性W重排不计入。不是模型请求端到端加速。

## 真正的BF16计算路径

BF16 A -> GPU K32重排及M补零 -> BF16 MMAC / FP32 accumulators -> BF16 RNE写回。没有INT8量化、scale或完整FP32中间矩阵。FP32输出变体仅用于精度检查。

核心指令为 v_mmac_f32_16x16x16_bf16。INT8每行K64字节与BF16每行K32元素均为64字节，因此每lane16B加载、1KiB片段、LDS双槽和私有双缓冲可沿用；K5120需要160个K32段，原INT8为80个K64段。生成器的固定pair计数40改80；E047固定入口的末段边界同步调整；运行时packed ABI以K字节数10240传递，公开API仍以5120个BF16元素理解K。E030 split-K归约由整数add改FP32 add。BF16输出执行RNE并正确处理NaN分类，直接按两个dword写四个BF16。

28个模块包含FP32和BF16两种输出、每种输出类型15个函数入口。反汇编确认不存在INT8 MMAC。FP32与BF16输出版本的K主循环字节一致，只有指向不同尾部的合法分支位移变化；详见instruction-audit.json。公共寄存器和LDS预算未因输入改为BF16增加，因为每段K元素数减半。默认路由的M1..128选择N128_SAB，使用124 VGPR、16KiB LDS、4 wave、BN128。大M沿用这组候选内实测选择，完整逐M策略在bf16-policy.json。

选路在14类既有/派生候选中进行，不代表所有tile和流水的全局最优。本轮没有逐因素消融，不把相对BLAS的总收益单独归因于布局、tile、资源或某条指令。

## 正确性

106组小整数/one-hot/尾行检查，对应FP32及BF16输出均通过完整结果与guard。one-hot覆盖K分区两半和最后K32段。

初始路由使用两组随机BF16输入逐M覆盖全部256点，共 {accuracy['BF16_elements']:,} 个BF16元素。FP64完整矩阵乘作为参考，并用CPU FP64点检；FP32累加最大绝对误差 {accuracy['FP32_max_abs_error_vs_FP64']:.9g}，最大相对L2误差 {accuracy['FP32_max_relative_L2_vs_FP64']:.9g}。BF16输出与自身FP32结果的RNE转换逐位一致；其相对FP64最大L2误差 {accuracy['BF16_max_relative_L2_vs_FP64']:.9g}，主要处于BF16舍入精度范围。尾部guard、Graph重复回放、NaN/Inf分类均通过。

本轮浮点累加顺序与BLAS可不同，不承诺与LightOp或torch.mm逐位相同。BF16对FP64舍入结果的检查阈值 rtol=1/128、atol=1/256；报告同时保留误差实测值。原始精度数据在validation.json；正式计时的768个组、共 {accuracy['timed_replays_checked']} 次主图回放检查最后一份W的完整输出，均通过。

## 计时与准备成本

每份W为170 MiB，72份原W与72份对应packed W每种布局约11.95 GiB，远大于卡上8 MiB L2。各实现共用同一组数值和轮转顺序；同轮随机实现顺序。候选包含激活重排与纯GEMM两图共享BF16输出地址，外部基线按各自公开接口分配输出。每次候选激活重排都计时。一次性W重排中位数 {prep:.3f} us/权重；保留原W时packed副本额外占170 MiB。

频率采样 {len(clockrows)} 次，分布 {json.dumps(clocks,ensure_ascii=False)}。torch.mm/LightOp版本、入口及Torch选项见environment.json和baseline-manifest.json。

## 保存与使用

代码与工件均在本目录。上一轮INT8成果包SHA256在PRESERVED.json中，本轮没有覆盖它。接口bf16_gemm.py，生成器bf16_generator.py，策略bf16-policy.json；验证smoke.py/validate.py；选路tune.py；正式计时benchmark.py；全部原始样本benchmark-raw.json和benchmark-seed-*.jsonl。

{fence}python
import torch
from bf16_gemm import prepare_weight, matmul

# a: BF16 [M,5120] contiguous
# w: BF16 [5120,17408], stride=(1,5120)
prepared = prepare_weight(w)  # static weight, prepare once
y = matmul(a, w, prepared_weight=prepared)  # BF16 [M,17408]
# Optional FP32 debug output:
y32 = matmul(a, w, prepared_weight=prepared, out_dtype=torch.float32)
{fence}

热身所需M后可捕获Graph。省略prepared_weight会在每次调用重排W。修改W后需重新prepare。默认输出为BF16；当前支持M1..256和固定N/K，非匹配形状会报错。验证、调优及benchmark脚本显式使用BW47物理GPU5；适配模块本身继承调用方的GPU映射。
"""
(R/'REPORT.md').write_text(report)
readme=f"""# BF16 GEMM extension

A: contiguous BF16 [M,5120], M=1..256. B: BF16 [5120,17408], stride=(1,5120). Native BF16 MMAC with FP32 accumulation; BF16 RNE output.

{fence}python
from bf16_gemm import prepare_weight, matmul
prepared = prepare_weight(w)  # once for static W
y = matmul(a, w, prepared_weight=prepared)
{fence}

An optional out_dtype=torch.float32 returns the unrounded FP32 result. No quantization or scales are used. Warm up required shapes before Graph capture. The packed weight adds170 MiB if original W is retained. Omitting prepared_weight repacks W each call. Changing W requires prepare_weight again.

Use the same environment as the saved run. Build: python3 bf16_generator.py --build-all. Check: python3 smoke.py, then python3 validate.py. Select candidates: python3 tune.py. Formal benchmark: python3 benchmark.py. Analyze: python3 analyze.py.

Validation and benchmark scripts select physical GPU5 on BW47; review that setting before another node. The adapter inherits the caller's device mapping. Supported dimensions and complete accuracy/performance evidence are in REPORT.md / RESULT.json. This directory is independent of the preserved INT8 implementation.
"""
(R/'README.md').write_text(readme)
print(json.dumps({'ranges':ranges,'accuracy':accuracy,'weight_preparation_us':prep,'clocks':clocks,'points':[p for p in points if p['M'] in [1,8,16,32,64,128,129,192,193,256]],'selected_counts':counts},indent=2))
