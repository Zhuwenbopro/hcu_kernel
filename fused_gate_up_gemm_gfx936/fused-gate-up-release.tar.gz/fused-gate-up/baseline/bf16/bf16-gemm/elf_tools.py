from pathlib import Path
import re,struct,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent
OLD=Path('/home/zmoe/experiments/int8-bw90-20261110')
MC='/opt/dtk/aillvm/bin/llvm-mc';LD='/opt/dtk/aillvm/bin/ld.lld';OD='/opt/dtk/aillvm/bin/llvm-objdump'
def elf(b):
 h=struct.unpack_from('<16sHHIQQQIHHHHHH',b);ss=[struct.unpack_from('<IIQQQQIIQQ',b,h[6]+i*h[11]) for i in range(h[12])];st=ss[h[13]];names=b[st[4]:st[4]+st[5]]
 sections={names[s[0]:].split(b'\0')[0].decode():b[s[4]:s[4]+s[5]] for s in ss if s[1]!=8}
 syms={}
 for se in ss:
  if se[1] not in [2,11]:continue
  t=ss[se[6]];ns=b[t[4]:t[4]+t[5]]
  for off in range(se[4],se[4]+se[5],se[9]):
   y=struct.unpack_from('<IBBHQQ',b,off);n=ns[y[0]:].split(b'\0')[0].decode()
   if y[1]&15!=2:continue
   s=ss[y[3]];a=s[4]+y[4]-s[3];syms[n]={'address':y[4],'size':y[5],'body':b[a:a+y[5]]}
 return sections,syms
def assemble(src,out):
 p=out.with_suffix('.o')
 for cmd in [[MC,'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(src),'-o',str(p)],[LD,'-shared',str(p),'-o',str(out)]]:
  q=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  assert q.returncode==0,q.stdout
def disasm(p):
 s=subprocess.check_output([OD,'-d','--mcpu=gfx936',str(p)],text=True)
 p.with_suffix('.disasm').write_text(s)
 rr=[]
 for line in s.splitlines():
  m=re.search(r'//\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{8}(?:\s+|$))+)',line)
  if m:rr.append({'pc':int(m[1],16),'words':[int(w,16) for w in m[2].split()],'op':line.split('//')[0].strip()})
 return rr
def audit(old,new,offsets,pads):
 a,aa=elf(old.read_bytes());b,bb=elf(new.read_bytes());assert a['.note']==b['.note'],'metadata changed'
 rec=disasm(old);newrec={x['pc']:x for x in disasm(new)};total=0
 for name,orig in aa.items():
  dest=bb[name];off=offsets[name];pad=pads[name];assert dest['size']==orig['size']+pad
  def mp(x):return x+pad if x>=off else x
  assert dest['body'][off:off+pad]==struct.pack('<I',0xbf800000)*(pad//4)
  for x in rec:
   rel=x['pc']-orig['address']
   if not 0<=rel<orig['size']:continue
   n=newrec[dest['address']+mp(rel)]
   op=x['op'].split()[0]
   if op=='s_branch' or op.startswith('s_cbranch_'):
    w=x['words'][0];imm=w&65535;imm=imm-65536 if imm>=32768 else imm
    target=rel+4+imm*4;newimm=(mp(target)-mp(rel)-4)//4
    want=(w&0xffff0000)|(newimm&65535)
    assert n['words']==[want],(name,rel,n,x)
   else:assert n['words']==x['words'],(name,rel,n,x)
   total+=1
 return dict(instructions_checked=total,register_operands_identical=True,instruction_order_identical=True,branch_destinations_mapped=True,metadata_identical=True)