"""gfx936 BF16 x BF16 -> FP32/BF16 assembly extension.

Packing uses K32 BF16 blocks (the same 64 bytes per logical row as K64 INT8).
All instruction scheduling is inherited from a frozen INT8 generator, then
MMAC, K-stage count and output operations are explicitly changed.
"""
from pathlib import Path
import re,json,subprocess,hashlib,struct,ast,sys,argparse
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import int8_tile_generator as i8
MC='/opt/dtk/aillvm/bin/llvm-mc';LD='/opt/dtk/aillvm/bin/ld.lld';OD='/opt/dtk/aillvm/bin/llvm-objdump'
OUT=R/'kernels';OUT.mkdir(exist_ok=True)
STAGE_K=32;K=5120;N=17408

def run(args):
    q=subprocess.run(args,capture_output=True,text=True)
    if q.returncode:raise RuntimeError(' '.join(args)+'\n'+q.stdout+q.stderr)
    return q.stdout

def rounding(a,tmp,ptr,offset,flags='glc slc'):
    out=[f'v_mov_b32_e32 v{tmp+1}, 0x7fff0000']
    for v in range(a,a+4):
        out += [f'v_cmp_u_f32_e32 vcc, v{v}, v{v}',
                f'v_lshrrev_b32_e32 v{tmp}, 16, v{v}',
                f'v_and_b32_e32 v{tmp}, 1, v{tmp}',
                f'v_add_u32_e32 v{v}, 0x7fff, v{v}',
                f'v_add_u32_e32 v{v}, v{tmp}, v{v}',
                f'v_cndmask_b32_e32 v{v}, v{v}, v{tmp+1}, vcc']
    out += [f'v_lshrrev_b32_e32 v{a}, 16, v{a}',
            f'v_and_b32_e32 v{a+1}, 0xffff0000, v{a+1}',
            f'v_or_b32_e32 v{a}, v{a}, v{a+1}',
            f'v_lshrrev_b32_e32 v{a+2}, 16, v{a+2}',
            f'v_and_b32_e32 v{a+3}, 0xffff0000, v{a+3}',
            f'v_or_b32_e32 v{a+1}, v{a+2}, v{a+3}',
            f'global_store_dwordx2 v[{ptr}:{ptr+1}], v[{a}:{a+1}], off offset:{offset//2} {flags}']
    return '\n'.join(out)+'\n'

def convert_generated_output(source,cfg,dtype):
    if dtype=='fp32':return source
    t=cfg['address_registers'][0];tmp=cfg['accumulator_VGPR']
    assert tmp<t
    needle=f'v_add_u32_e32 v{t+8}, v{t+3}, v{t+8}\n'
    assert needle in source
    source=source.replace(needle,needle+f'v_lshrrev_b32_e32 v{t+8}, 1, v{t+8}\n')
    pat=r'GEMM_EPILOGUE_STORE_GLC_SLC v\[(\d+):\d+\], v\[(\d+):\d+\], (\w+)\n'
    n=[0]
    def repl(m):
        n[0]+=1
        return rounding(int(m[2]),tmp,int(m[1]),int(m[3],0))
    source=re.sub(pat,repl,source)
    assert n[0]>0
    return source

def render(direction,bm,read_first=0,scalar_address='both',prefetch_order='legacy',out_dtype='bf16'):
    if out_dtype not in ['bf16','fp32']:raise ValueError('Output dtype must be bf16 or fp32')
    source,cfg=i8.render_kernel(direction,bm,read_first,scalar_address,prefetch_order)
    old=cfg['family'];new=old+'_BF16_'+out_dtype.upper()
    source=re.sub(r'\b'+re.escape(old)+r'\b',new,source)
    assert source.count('s_mov_b32 s24, 40\n')==1
    source=source.replace('s_mov_b32 s24, 40\n',f's_mov_b32 s24, {K//STAGE_K//2}\n')
    source=source.replace('GEMM_MMA_I8','GEMM_MMA_BF16')
    source=convert_generated_output(source,cfg,out_dtype)
    cfg.update(base_family=old,family=new,function=new,input_dtype='bf16',accumulator_dtype='fp32',output_dtype=out_dtype,stage_K=STAGE_K,K=K,N=N,K_bytes=K*2,total_stages=K//STAGE_K,direction=direction)
    cfg['MMAC_per_wave_K32']=cfg.pop('MMAC_per_wave_K64')
    return source,cfg

def epilogue(family,groups,row,col,tmp,addr,mreg,yreg,out_dtype,row_base=None,wave=None):
    code=['s_waitcnt vmcnt(0)',f'v_and_b32_e32 v{row}, 15, v0',
          f'v_lshrrev_b32_e32 v{col}, 4, v0',f'v_and_b32_e32 v{col}, 3, v{col}',
          f'v_lshlrev_b32_e32 v{col}, 2, v{col}']
    if family=='E030':
        code += [f'v_add_u32_e32 v{row}, s5, v{row}',f'v_add_u32_e32 v{col}, s4, v{col}']
    else:
        code += ['s_lshl_b32 s2, s6, 7',f'v_add_u32_e32 v{col}, s2, v{col}']
        if wave is not None:
            code += [f'v_lshlrev_b32_e32 v{tmp}, 5, v{wave}',f'v_add_u32_e32 v{row}, v{tmp}, v{row}']
        else:code += [f'v_add_u32_e32 v{row}, v{row_base}, v{row}']
    text='\n'.join(code)+'\n'
    for i,accs in enumerate(groups):
        skip=f'.L_{family}_{out_dtype}_skip_{i}'
        text+=f'v_cmp_gt_u32_e32 vcc, {mreg}, v{row}\ns_and_saveexec_b64 s[2:3], vcc\ns_cbranch_execz {skip}\n'
        text+=f'v_mul_u32_u24_e32 v{tmp}, 17408, v{row}\nv_add_u32_e32 v{tmp}, v{col}, v{tmp}\nv_lshlrev_b32_e32 v{tmp}, {1 if out_dtype=="bf16" else 2}, v{tmp}\n'
        text+=f'v_add_co_u32_e32 v{addr}, vcc, s{yreg}, v{tmp}\nv_mov_b32_e32 v{addr+1}, s{yreg+1}\nv_addc_co_u32_e32 v{addr+1}, vcc, 0, v{addr+1}, vcc\n'
        for j,a in enumerate(accs):
            if out_dtype=='bf16':text+=rounding(a,tmp,addr,j*64)
            else:text+=f'global_store_dwordx4 v[{addr}:{addr+1}], v[{a}:{a+3}], off offset:{j*64} glc slc\n'
        text+=f'{skip}:\ns_or_b64 exec, exec, s[2:3]\n'
        if i+1<len(groups):text+=f'v_add_u32_e32 v{row}, 16, v{row}\n'
    return text

def e047(out_dtype):
    source=(R/'frozen_int8/gemm_asm/e047.s').read_text()
    source=source.replace('GEMM_MMA_I8','GEMM_MMA_BF16')
    # K blocks increase from 80 K64-byte blocks to 160 K32-BF16 blocks.
    assert source.count('s_cmpk_lt_u32 s4, 0x4d')==1
    assert source.count('s_cmpk_gt_u32 s10, 0x4e')==1
    source=source.replace('s_cmpk_lt_u32 s4, 0x4d','s_cmpk_lt_u32 s4, 0x9d').replace('s_cmpk_gt_u32 s10, 0x4e','s_cmpk_gt_u32 s10, 0x9e')
    maps=[
        ('.LBB0_4:',[[57,61,65,69,53,49,41,33],[29,25,21,17,13,9,5,1]],dict(family='E047_fixed',row=90,col=91,tmp=92,addr=94,mreg='128',yreg=8,wave=83)),
        ('.LBB1_12:',[[77,69,61,57,53,49,45,41],[37,33,21,17,13,9,5,1]],dict(family='E047_generic',row=90,col=91,tmp=92,addr=94,mreg='s0',yreg=16,row_base=85))]
    for marker,groups,kwargs in maps:
        start=source.index(marker);end=source.index('s_endpgm',start)
        source=source[:start]+marker+'\n'+epilogue(groups=groups,out_dtype=out_dtype,**kwargs)+source[end:]
    names=re.findall(r'^\s*\.globl\s+(\S+)',source,re.M)
    newnames=[]
    for name in names:
        new='E047_BF16_'+('fixed_' if 'Li128ELi17408ELi5120' in name else 'generic_')+out_dtype
        source=source.replace(name,new);newnames.append(new)
    return source,dict(family='E047_BF16_'+out_dtype.upper(),base_family='E047',functions=newnames,input_dtype='bf16',output_dtype=out_dtype,accumulator_dtype='fp32',stage_K=32,K=K,K_bytes=K*2,N=N,BM=128,BN=128,NW=4,LDS=16384)

def e030(out_dtype):
    source=(R/'frozen_int8/E030_assembly/kernel.s').read_text()
    source=source.replace('v_mmac_i32_16x16x32_i8','v_mmac_f32_16x16x16_bf16')
    start=source.index('; %bb.9:');end=source.index('.LBB0_13:',start)
    groups=[[17,21,25,29],[5,9,13,1]];accs=groups[0]+groups[1]
    reduction=['; %bb.9:','v_lshlrev_b32_e32 v65, 4, v61']
    for j in range(8):reduction.append(f'ds_read_b128 v[{33+j*4}:{36+j*4}], v65 offset:{j*1024}')
    reduction.append('s_waitcnt lgkmcnt(0)')
    for j,a in enumerate(accs):
        for e in range(4):reduction.append(f'v_add_f32_e32 v{a+e}, v{33+4*j+e}, v{a+e}')
    ep=epilogue('E030',groups,51,52,56,54,'s8',12,out_dtype)
    source=source[:start]+'\n'.join(reduction)+'\n'+ep+source[end:]
    name=re.search(r'^\s*\.globl\s+(\S+)',source,re.M)[1]
    new='E030_BF16_'+out_dtype
    source=source.replace(name,new)
    return source,dict(family='E030_BF16_'+out_dtype.upper(),base_family='E030',function=new,input_dtype='bf16',output_dtype=out_dtype,accumulator_dtype='fp32',stage_K=32,K=K,K_bytes=K*2,N=N,BM=32,BN=64,NW=2,LDS=8192)

def emit(source,record,output_dir=OUT):
    d=Path(output_dir)/record['family'];d.mkdir(parents=True,exist_ok=True)
    (d/'kernel.s').write_text(source)
    run([MC,'--save-temp-labels','-I',str(R),'-triple=amdgcn-amd-amdhsa','-mcpu=gfx936','-mattr=+sramecc','-filetype=obj',str(d/'kernel.s'),'-o',str(d/'kernel.o')])
    run([LD,'-shared',str(d/'kernel.o'),'-o',str(d/'kernel.hsaco')])
    dis=run([OD,'-d','--mcpu=gfx936',str(d/'kernel.hsaco')]);(d/'device.disasm').write_text(dis)
    assert 'v_mmac_f32_16x16x16_bf16' in dis and 'v_mmac_i32' not in dis
    (d/'notes.txt').write_text(run(['/opt/dtk/aillvm/bin/llvm-readelf','--notes',str(d/'kernel.hsaco')]))
    record.update(path=str(d/'kernel.hsaco'),hsaco_sha256=hashlib.sha256((d/'kernel.hsaco').read_bytes()).hexdigest())
    (d/'plan.json').write_text(json.dumps(record,indent=2)+'\n')
    return record

def build_all():
    plan=json.loads((R/'frozen_int8/integrated_validation/timing-plan.json').read_text())
    configs={}
    for rec in plan['records']:
        if rec['family'] in set(plan['after'].values()):
            configs[rec['family']]={k:rec[k] for k in ['direction','BM','read_first_fragments','scalar_address','prefetch_order']}
    # Additional small/mid-M tiles are candidates, not presumed BF16 winners.
    for direction,bm in [('M',128),('N',128)]:
        key=f'{direction}{bm}_SAB'
        configs[key]=dict(direction=direction,BM=bm,read_first_fragments=0,scalar_address='both',prefetch_order='legacy')
    results=[]
    for cfg in configs.values():
        for dtype in ['fp32','bf16']:
            source,rec=render(cfg['direction'],cfg['BM'],cfg['read_first_fragments'],cfg['scalar_address'],cfg['prefetch_order'],dtype)
            results.append(emit(source,rec));print('BUILT',rec['family'],flush=True)
    for dtype in ['fp32','bf16']:
        for fn in [e047,e030]:
            source,rec=fn(dtype);results.append(emit(source,rec));print('BUILT',rec['family'],flush=True)
    (OUT/'manifest.json').write_text(json.dumps(results,indent=2)+'\n')
    (R/'initial-policy.json').write_text(json.dumps({'scope':{'M':[1,256],'N':N,'K':K},'origin':'initial reuse of the frozen INT8 policy; no BF16 optimality claim','by_M':plan['after']},indent=2)+'\n')
    print('BUILD_DONE',len(results),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--build-all',action='store_true')
    ap.add_argument('--direction',choices=['M','N'],default='N')
    ap.add_argument('--BM',type=int,default=256)
    ap.add_argument('--read-first',type=int,default=0)
    ap.add_argument('--prefetch-order',choices=i8.PREFETCH_ORDERS,default='legacy')
    ap.add_argument('--scalar-address',choices=i8.ADDRESS_MODES,default='both')
    ap.add_argument('--out-dtype',choices=['bf16','fp32'],default='bf16')
    ap.add_argument('--output-dir',type=Path,default=OUT)
    args=ap.parse_args()
    if args.build_all:build_all()
    else:
        source,rec=render(args.direction,args.BM,args.read_first,args.scalar_address,args.prefetch_order,args.out_dtype)
        print(json.dumps(emit(source,rec,args.output_dir),indent=2))
