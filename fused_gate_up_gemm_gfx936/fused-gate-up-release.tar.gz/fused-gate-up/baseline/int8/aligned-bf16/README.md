# Aligned BF16 GEMM

gfx936 specialization: INT8 A [M,5120], M=1..256; INT8 B [5120,17408], stride (1,5120); FP32 scales [M,1] and [17408,1]; BF16 output. Bias and best_config must be None. All operations use the current PyTorch stream.

```python
from aligned_gemm import prepare_weight, triton_scaled_mm

# Prepare static W once, before Graph capture. Warm up each required M.
prepared = prepare_weight(w)
gate_up = triton_scaled_mm(
    xq, w, sx, sw, out_dtype=torch.bfloat16,
    bias=None, best_config=None, prepared_weight=prepared,
)
# prepared.scaled_mm also supports the original positional signature.
```

W retains its external transpose layout. Changing W invalidates the prepared copy. Prepared storage adds85 MiB/weight if original storage is retained. Omitting prepared_weight is correct but repacks W every call.

The epilogue computes FP32(acc)*(sx*sw) with BF16 RNE. Validated with finite BF16 activations, full-range random INT8 W, positive finite FP32 scales, zero rows and split-K one-hot controls. See REPORT.md for measurements and scope.

Commands in the current environment: python3 build_bf16.py; python3 validate_bf16.py; python3 benchmark.py; python3 analyze.py. The validation/benchmark scripts explicitly select physical GPU5 on BW47 and must be reviewed before use on another node. The adapter inherits the caller's GPU mapping. No production LightOp registration is replaced.
