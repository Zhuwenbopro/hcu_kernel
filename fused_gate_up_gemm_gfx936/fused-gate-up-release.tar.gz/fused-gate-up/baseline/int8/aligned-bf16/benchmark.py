import os
os.environ['HIP_VISIBLE_DEVICES']='5'
for k in ['CUDA_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES','GPU_DEVICE_ORDINAL']:os.environ.pop(k,None)
os.environ['OMP_NUM_THREADS']='8'
from pathlib import Path
import sys,json,time,statistics,random,gc,traceback,threading,datetime
sys.path[:0]=['/home/sglang-plugin-das','/home/adapter-das','/home/sglang/python']
import torch
torch.set_num_threads(8)
from lightop.quant import per_token_quant_int8
from hcu_sglang.layers.quantization.quant_ops import triton_scaled_mm as lightop_mm
import aligned_gemm as ag
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'frozen'))
from common import reference
COPIES=72
ROUNDS=7
SEEDS=[202611148201,202611148202,202611148203]
QPOINTS={1,4,8,16,32,64,65,96,128,129,160,176,192,193,208,224,240,256}
def save(name,x):(R/name).write_text(json.dumps(x,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def measure(g,count=COPIES):
    a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
    a.record();g.replay();b.record();b.synchronize()
    return a.elapsed_time(b)*1000/count
def exact(y,ref):
    if not torch.equal(y.view(torch.int16),ref.view(torch.int16)):raise RuntimeError('Candidate graph output mismatch')
def lightop_check(y,ref):
    diff=(y.view(torch.int16).to(torch.int32)-ref.view(torch.int16).to(torch.int32)).abs()
    if int(diff.max().item())!=0:raise RuntimeError('LightOp graph output mismatch')
def capture(fn):
    g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):out=fn()
    return g,out
def clocks(stop):
    root=Path('/sys/bus/pci/devices/0000:c1:00.0')
    with (R/'clocks.jsonl').open('w') as out:
        while not stop.is_set():
            rec={'time':now()}
            for n in ['pp_dpm_sclk','pp_dpm_mclk','power_dpm_force_performance_level','gpu_busy_percent','mem_info_vram_used']:
                p=root/n
                try:rec[n]=p.read_text().strip()
                except OSError:pass
            for p in (root/'hwmon').glob('hwmon*/*'):
                if p.name in ['freq1_input','freq2_input','temp1_input','power1_average']:
                    try:rec[p.name]=p.read_text().strip()
                    except OSError:pass
            out.write(json.dumps(rec)+'\n');out.flush()
            stop.wait(1)

def main():
    correctness=json.loads((R/'correctness.json').read_text())
    assert correctness['status']=='complete'
    eng=ag.engine()
    stop=threading.Event();sampler=threading.Thread(target=clocks,args=(stop,),daemon=True);sampler.start()
    groups=[];components=[];preparation=[]
    save('benchmark-status.json',{'status':'running','started':now(),'groups':0,'seeds':SEEDS,'copies':COPIES,'rounds':ROUNDS})
    try:
        for si,seed in enumerate(SEEDS):
            torch.manual_seed(seed)
            x=torch.randn((256,ag.K),device='cuda',dtype=torch.bfloat16)
            aq,sxa=per_token_quant_int8(x)
            weights=[];prepared=[];sws=[]
            for i in range(COPIES):
                w=torch.randint(-128,128,(ag.N,ag.K),device='cuda',dtype=torch.int8)
                b=w.t();pw=ag.prepare_weight(b)
                sw=torch.rand((ag.N,1),device='cuda',dtype=torch.float32)*0.03+0.00001
                weights.append(b);prepared.append(pw);sws.append(sw)
                if i in [0,COPIES-1]:
                    ref=reference(aq,w)
                    xp=ag.pack_a(aq,256)
                    y=torch.empty((256,ag.N),device='cuda',dtype=torch.bfloat16)
                    eng.launch_packed(xp,pw.packed,sxa,sw,y,256)
                    exact(y,(ref.float()*(sxa*sw.T)).to(torch.bfloat16))
                    if i==COPIES-1:ref_last=ref
                del w,b,pw,sw
            print('POOL_READY',seed,flush=True)
            torch.cuda.synchronize()
            wg,unused=capture(lambda:[ag._pack_w(w,out=p.packed) for w,p in zip(weights,prepared)])
            wg.replay();torch.cuda.synchronize()
            wp_samples=[measure(wg) for _ in range(ROUNDS)]
            preparation.append({'seed':seed,'weight_pack_us':wp_samples,'median_us':statistics.median(wp_samples),'bytes_per_weight':ag.N*ag.K,'storage':'89,128,960 extra bytes per static weight'})
            del wg,unused
            orderM=list(range(1,257));random.Random(seed).shuffle(orderM)
            shard=R/f'benchmark-seed-{seed}.jsonl'
            with shard.open('w') as stream:
                for mi,m in enumerate(orderM):
                    a=aq[:m];sx=sxa[:m];mp=eng.kernel(m).mp_for(m)
                    xp=ag.pack_a(a,mp)
                    ref=(ref_last[:m].float()*(sx*sws[-1].T)).to(torch.bfloat16)
                    main_graph,main_y=capture(lambda:[pw.scaled_mm(a,b,sx,sw,torch.bfloat16) for pw,b,sw in zip(prepared,weights,sws)])
                    baseline_graph,baseline_y=capture(lambda:[lightop_mm(a,b,sx,sw,torch.bfloat16,None,None) for b,sw in zip(weights,sws)])
                    fused_graph,unused=capture(lambda:[eng.launch_packed(xp,pw.packed,sx,sw,y,m) for pw,sw,y in zip(prepared,sws,main_y)])
                    graphs={'lightop':baseline_graph,'ours_with_activation_pack':main_graph,'ours_prepacked_activation':fused_graph}
                    # Same values and 72 corresponding static W allocations throughout each paired group.
                    for _ in range(2):
                        for g in graphs.values():g.replay()
                    torch.cuda.synchronize()
                    exact(main_y[-1],ref);lightop_check(baseline_y[-1],ref)
                    group={'seed':seed,'M':m,'N':ag.N,'K':ag.K,'family':eng.key(m),'MP':mp,'copies':COPIES,'samples':[],'addresses':{'A':a.data_ptr(),'XP':xp.data_ptr(),'W0':weights[0].data_ptr(),'W71':weights[-1].data_ptr(),'WP0':prepared[0].packed.data_ptr(),'WP71':prepared[-1].packed.data_ptr(),'ours_Y71':main_y[-1].data_ptr(),'lightop_Y71':baseline_y[-1].data_ptr()}}
                    rng=random.Random(seed+m)
                    for rnd in range(ROUNDS):
                        order=list(graphs);rng.shuffle(order)
                        sample={'round':rnd,'order':order,'us':{}}
                        for f in order:
                            sample['us'][f]=measure(graphs[f])
                            if f=='lightop':lightop_check(baseline_y[-1],ref)
                            else:exact(main_y[-1],ref)
                        group['samples'].append(sample)
                    if m in QPOINTS:
                        xf=x[:m]
                        def q_ours():
                            ys=[]
                            for pw,b,sw in zip(prepared,weights,sws):
                                q,qs=per_token_quant_int8(xf)
                                ys.append(pw.scaled_mm(q,b,qs,sw,torch.bfloat16))
                            return ys
                        def q_lightop():
                            ys=[]
                            for b,sw in zip(weights,sws):
                                q,qs=per_token_quant_int8(xf)
                                ys.append(lightop_mm(q,b,qs,sw,torch.bfloat16,None,None))
                            return ys
                        oqg,oqy=capture(q_ours);lqg,lqy=capture(q_lightop)
                        pg,pgy=capture(lambda:[ag.pack_a(a,mp,out=xp) for _ in range(COPIES)])
                        qg,qgy=capture(lambda:[per_token_quant_int8(xf) for _ in range(COPIES)])
                        extra={'ours_quant_pack_gemm':oqg,'lightop_quant_gemm':lqg,'activation_pack_only':pg,'quantization_only':qg}
                        for g in extra.values():g.replay()
                        torch.cuda.synchronize()
                        exact(oqy[-1],ref);lightop_check(lqy[-1],ref)
                        rows=[]
                        for rnd in range(ROUNDS):
                            order=list(extra);rng.shuffle(order)
                            rows.append({'round':rnd,'order':order,'us':{f:measure(extra[f]) for f in order}})
                        group['components']=rows
                        del oqg,oqy,lqg,lqy,pg,pgy,qg,qgy,extra
                    groups.append(group)
                    stream.write(json.dumps(group,separators=(',',':'))+'\n');stream.flush()
                    med={f:statistics.median(t['us'][f] for t in group['samples']) for f in graphs}
                    save('benchmark-status.json',{'status':'running','seed':seed,'seed_index':si,'completed_M_this_seed':mi+1,'groups':len(groups),'M':m,'median_us':med,'speedup':med['lightop']/med['ours_with_activation_pack']})
                    if (mi+1)%16==0 or m in [1,32,64,128,129,192,193,256]:
                        print('TIMING',seed,mi+1,m,{k:round(v,3) for k,v in med.items()},flush=True)
                    del graphs,main_graph,baseline_graph,fused_graph,main_y,baseline_y,unused,xp,ref
                    if mi%32==31:gc.collect()
            del x,aq,sxa,weights,prepared,sws,ref_last,y
            gc.collect();torch.cuda.empty_cache()
        save('benchmark-raw.json',{'status':'complete','finished':now(),'seeds':SEEDS,'rounds':ROUNDS,'copies':COPIES,'groups':groups,'preparation':preparation})
        save('benchmark-status.json',{'status':'complete','groups':len(groups),'finished':now()})
        print('BENCHMARK_DONE',len(groups),flush=True)
    finally:stop.set();sampler.join(timeout=3)
if __name__=='__main__':
    try:main()
    except BaseException as e:
        save('benchmark-failure.json',{'error':str(e),'traceback':traceback.format_exc()})
        traceback.print_exc();sys.exit(1)
