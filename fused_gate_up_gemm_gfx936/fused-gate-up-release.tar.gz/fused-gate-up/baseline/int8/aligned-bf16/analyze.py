from pathlib import Path
import json,statistics,csv,collections,os,hashlib
R=Path(__file__).resolve().parent
raw=json.loads((R/'benchmark-raw.json').read_text())
assert raw['status']=='complete' and len(raw['groups'])==768
seeds=raw['seeds']
for seed in seeds:assert {z['M'] for z in raw['groups'] if z['seed']==seed}==set(range(1,257))
F=['lightop','ours_with_activation_pack','ours_prepacked_activation']
points=[];quant=[]
for m in range(1,257):
    groups=[g for g in raw['groups'] if g['M']==m]
    rec={'M':m,'family':groups[0]['family'],'MP':groups[0]['MP']}
    perseed={g['seed']:{f:statistics.median(s['us'][f] for s in g['samples']) for f in F} for g in groups}
    for f in F:rec[f+'_us']=statistics.median(v[f] for v in perseed.values())
    rec['speedup']=rec['lightop_us']/rec['ours_with_activation_pack_us']
    rec['latency_reduction_pct']=(1-rec['ours_with_activation_pack_us']/rec['lightop_us'])*100
    rec['paired_speedup']=statistics.median(statistics.median(s['us']['lightop']/s['us']['ours_with_activation_pack'] for s in g['samples']) for g in groups)
    rec['seed_speedups']={str(seed):v['lightop']/v['ours_with_activation_pack'] for seed,v in perseed.items()}
    rec['measured_pack_difference_us']=rec['ours_with_activation_pack_us']-rec['ours_prepacked_activation_us']
    points.append(rec)
    if 'components' in groups[0]:
        q={'M':m}
        for f in groups[0]['components'][0]['us']:
            q[f+'_us']=statistics.median(statistics.median(s['us'][f] for s in g['components']) for g in groups)
        q['speedup']=q['lightop_quant_gemm_us']/q['ours_quant_pack_gemm_us']
        quant.append(q)
fields=[x for x in points[0] if x!='seed_speedups']
with (R/'latency-M1-256.csv').open('w',newline='') as out:
    w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows({k:v for k,v in p.items() if k in fields} for p in points)
with (R/'quantized-pipeline.csv').open('w',newline='') as out:
    w=csv.DictWriter(out,fieldnames=list(quant[0]));w.writeheader();w.writerows(quant)
clocks=[json.loads(x) for x in (R/'clocks.jsonl').read_text().splitlines()]
clock_summary={k:dict(collections.Counter(c.get(k,'missing') for c in clocks)) for k in ['freq1_input','freq2_input','power_dpm_force_performance_level']}
correctness=json.loads((R/'correctness.json').read_text())
preserved=json.loads((R/'PRESERVED.json').read_text())
audit=json.loads((R/'bf16_kernels/manifest.json').read_text())
sections=[]
for lo,hi in [(1,64),(65,128),(129,192),(193,256),(1,256)]:
    ps=[p for p in points if lo<=p['M']<=hi]
    sections.append({'M_range':[lo,hi],'lightop_mean_us':statistics.mean(p['lightop_us'] for p in ps),'ours_mean_us':statistics.mean(p['ours_with_activation_pack_us'] for p in ps),'speedup_min':min(p['speedup'] for p in ps),'speedup_max':max(p['speedup'] for p in ps),'median_speedup':statistics.median(p['speedup'] for p in ps),'wins':sum(p['speedup']>1 for p in ps),'points':len(ps)})
summary={'status':'complete','root':str(R),'scope':{'M':[1,256],'N':17408,'K':5120,'weight_stride':[1,5120],'dtype':'INT8 x INT8 -> INT32 -> FP32(acc)*(sx*sw) -> BF16 RNE'},'method':{'GPU':5,'node':'bw47','container':'zhuwenbo_sgl_0522','seeds':seeds,'rounds':7,'weight_copies':72,'weight_bytes_each':17408*5120,'source_weight_pool_bytes':72*17408*5120,'packed_weight_pool_bytes':72*17408*5120,'graph_calls_per_sample':72,'main_scope':'INT8 activation packing + fused scaled BF16 GEMM; static W packing excluded','aggregation':'median of 7 rounds per seed, then median of 3 seeds; paired ratios also in CSV'},'clock_samples':len(clocks),'clocks':clock_summary,'correctness':{'candidate_cases':len(correctness['checks']),'candidate_elements':sum(z['candidate']['elements'] for z in correctness['checks']),'candidate_bad':sum(z['candidate']['bad'] for z in correctness['checks']),'initial_LightOp_cases':sum('lightop_combined' in z for z in correctness['checks']),'initial_LightOp_bad':sum(z.get('lightop_combined',{}).get('bad',0) for z in correctness['checks']),'timed_graph_groups':len(raw['groups']),'timed_main_replays_checked':768*7*3,'all_guards':all(z['guard'] for z in correctness['checks']),'extra_one_hot_cases':correctness['one_hot']},'ranges':sections,'points':points,'quant_pipeline':quant,'weight_preparation':raw['preparation'],'weight_preparation_median_us':statistics.median(p['median_us'] for p in raw['preparation']),'preserved':preserved,'device_audit':audit}
(R/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest=json.loads((R/'frozen/manifest.json').read_text())
diff=[]
for name,rec in manifest.items():
    p=Path(rec['original'])
    h=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    if h!=rec['sha256']:diff.append({'path':str(p),'frozen_sha256':rec['sha256'],'current_sha256':h})
(R/'source-postflight.json').write_text(json.dumps({'files':len(manifest),'differences':diff},indent=2)+'\n')
os.environ['MPLCONFIGDIR']=str(R/'mpl-cache')
import sys
sys.path.insert(0,'/home/zmoe/experiments/int8-bw90-20261110/nodes/S001/plot-deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,1,figsize=(12,7.7),sharex=True,gridspec_kw={'height_ratios':[2.1,1]})
x=[p['M'] for p in points]
axs[0].plot(x,[p['lightop_us'] for p in points],label='LightOp current wrapper -> BF16',color='#d45041',lw=1.8)
axs[0].plot(x,[p['ours_with_activation_pack_us'] for p in points],label='Ours: activation pack + fused BF16 GEMM',color='#1e70bd',lw=1.8)
axs[0].plot(x,[p['ours_prepacked_activation_us'] for p in points],label='Ours: fused BF16 GEMM only',color='#279976',lw=1.3,alpha=.85)
axs[0].set_ylabel('GPU latency per call (us)');axs[0].legend(loc='upper left',frameon=False)
axs[1].plot(x,[p['speedup'] for p in points],color='#1e70bd',lw=1.7)
axs[1].axhline(1,color='gray',ls='--',lw=1);axs[1].set_ylabel('LightOp / ours');axs[1].set_xlabel('M (token rows)')
for ax in axs:
    ax.grid(alpha=.18);ax.set_xlim(1,256)
    for xx in [64,128,192]:ax.axvline(xx,color='gray',alpha=.3,lw=.8,ls=':')
axs[1].set_xticks([1,32,64,96,128,160,192,224,256])
fig.suptitle('W8A8 gate/up: N=17408, K=5120, BF16 output',fontsize=16,y=.975)
fig.text(.5,.928,'BW47 gfx936 GPU 5 | 1499/1800 MHz | 3 seeds x 7 rounds x 72 weights | static W packed offline',ha='center',fontsize=10,color='#444')
fig.tight_layout(rect=[.015,.015,.995,.91]);fig.savefig(R/'lightop-vs-ours-BF16.png',dpi=180);fig.savefig(R/'lightop-vs-ours-BF16.svg');plt.close(fig)
def table(ps):
    out=['| M | LightOp us | Ours incl. X pack us | Ours GEMM only us | Speedup | Latency reduction |','|---:|---:|---:|---:|---:|---:|']
    for p in ps:out.append(f"| {p['M']} | {p['lightop_us']:.3f} | {p['ours_with_activation_pack_us']:.3f} | {p['ours_prepacked_activation_us']:.3f} | {p['speedup']:.3f}x | {p['latency_reduction_pct']:.2f}% |")
    return '\n'.join(out)
chosen=[p for p in points if p['M'] in [1,8,16,32,64,65,96,128,129,160,176,192,193,208,224,240,256]]
report=f"""# LightOp 与现有优化：W8A8 / BF16 输出对齐

实测节点 bw47，容器 zhuwenbo_sgl_0522，GPU5；固定 N=17408、K=5120、M=1..256。当前 LightOp 包和 hcu_sglang 包装接口作为基线；适配版保留冻结逐 M 选择，在 K 循环后融合 FP32 scale 与 BF16 输出。

## 结果

包含每次调用的激活重排，静态 W 提前重排：256个M点中 {sum(p['speedup']>1 for p in points)} 个更快。逐点加速 {min(p['speedup'] for p in points):.3f}–{max(p['speedup'] for p in points):.3f}x，耗时下降 {min(p['latency_reduction_pct'] for p in points):.2f}%–{max(p['latency_reduction_pct'] for p in points):.2f}%。这是同卡独立算子的Graph内GPU时间，不是模型请求端到端延时。

{table(chosen)}

## 输入、输出与权重准备

外部 W 仍为 INT8 [5120,17408]、stride=(1,5120)。prepare_weight 生成 PI16/K64 布局，packed W 为85 MiB/权重；本实现同时保留原 W，新增85 MiB存储。一次性 W 重排中位数 {summary['weight_preparation_median_us']:.3f} us/权重，不计入主表。公开函数不传 prepared_weight 时会当次重排 W；推理调用应提前准备并复用。

每次调用：连续INT8激活 -> GPU重排并补零至MP -> 原有INT8 MMAC / INT32累加 -> FP32(acc)*(sx*sw) -> BF16 RNE -> 连续[M,17408]输出。无完整INT32中间矩阵，也没有独立dequant kernel。sx [M,1]、sw [17408,1] 均为FP32。当前验证范围要求 bias=None、best_config=None、BF16输出和上述固定N/K/M。

## 正确性

两组BF16随机激活（含零行）、全范围随机INT8 W、FP32正scale，逐M覆盖全部256点，共 {summary['correctness']['candidate_elements']:,} 个BF16元素与合并scale顺序的参考逐位一致。W/X重排与冻结pack参考完整一致；CPU INT64点检校验方向和完整K。尾部guard、独立Graph回放通过，另有跨split-K分区的one-hot检查。

LightOp采用先合并sx*sw、再乘FP32(acc)的数值行为。初始74个代表点与该顺序逐位一致；全部768个正式组的每次主路径Graph回放也检查双方最后一份W的完整输出，均逐位一致。依次乘sx、sw会有少量BF16 1 ULP差异，因此正式版本及正式计时均采用合并scale。

## 代码与资源

- 原E030/E047和最新scalar-address / split-prefetch逐M路由保留。
- 10个大M函数的prologue和K主循环字节完全不变。E047两个入口新增一条scale指针加载，此后至输出段的原字节不变。E030保留K循环、发布和barrier，归约段在输出前汇总8组LDS INT32 partial；一条分支指向新尾部的位移重定位。详见bf16_kernels/manifest.json。
- BF16 epilogue复用已死VGPR，VGPR/LDS声明不增加。E030/E047增加scale指针SGPR，next_free_sgpr=28，metadata sgpr_count=32；大M tile SGPR不变。实际属性在kernel-attributes.json。
- LightOp M<=64显式slide9：逻辑M64xN64、256线程、272 CTA；CO元数据200 VGPR、88 SGPR、32 KiB LDS。
- LightOp M65..128自动分派：逻辑M128xN256、512线程、68 CTA；255 VGPR、102 SGPR、64 KiB LDS。
- LightOp M129..256自动分派：逻辑M256xN256、768线程、68 CTA；255 VGPR、102 SGPR、64 KiB LDS。
- 我方E030：M32xN64、128线程、272 CTA、72 VGPR、8 KiB LDS；E047：M128xN128、256线程、136 CTA、固定/通用123/128运行时VGPR、16 KiB LDS；大M BM144..256、BN128、256线程、136 CTA，LDS/VGPR按原策略。

布局、tile、线程数、资源和代码路径是已核对的实现差异；本轮没有逐因素消融，不把总收益单独归因于其中一项。

## 方法与边界

三组独立seed，每M每组七轮。每轮随机实现顺序，72份W轮转；原W和对应packed W数值相同。每种布局权重池约5.98 GiB，远大于此卡8 MiB L2。主表先取每seed七轮中位数，再取三seed中位数；CSV另存同轮配对比值。输出按各自公开接口分配；候选包含重排和纯GEMM两图共享相同BF16输出地址。同一stream GPU events计时，模块加载、JIT、Graph构建、CPU Python调用开销不计入。

频率采样 {len(clocks)} 条：{json.dumps(clock_summary,ensure_ascii=False)}。18个代表点另测相同per_token_quant_int8 + 对应BF16 GEMM链路，见quantized-pipeline.csv。

## 保存与复现

原成果快照 optimized-preserved.tar.gz，SHA256={preserved['archive_sha256']}。源码、best二进制、最新逐M策略和已验证工件在frozen/。{len(manifest)} 个原文件的结束复核差异数为 {len(diff)}。

API aligned_gemm.py；构建 build_bf16.py；验证 validate_bf16.py；计时 benchmark.py；逐点 latency-M1-256.csv；原始 benchmark-raw.json 和 benchmark-seed-*.jsonl；汇总 RESULT.json；图 lightop-vs-ours-BF16.png/.svg。LightOp包/CO哈希及三个当前CO在lightop-baseline-manifest.json / lightop_baseline/。本轮为独立适配与对比，生产分派和模型服务未替换。
"""
(R/'REPORT.md').write_text(report)
fence=chr(96)*3
readme=f"""# Aligned BF16 GEMM

gfx936 specialization: INT8 A [M,5120], M=1..256; INT8 B [5120,17408], stride (1,5120); FP32 scales [M,1] and [17408,1]; BF16 output. Bias and best_config must be None. All operations use the current PyTorch stream.

{fence}python
from aligned_gemm import prepare_weight, triton_scaled_mm

# Prepare static W once, before Graph capture. Warm up each required M.
prepared = prepare_weight(w)
gate_up = triton_scaled_mm(
    xq, w, sx, sw, out_dtype=torch.bfloat16,
    bias=None, best_config=None, prepared_weight=prepared,
)
# prepared.scaled_mm also supports the original positional signature.
{fence}

W retains its external transpose layout. Changing W invalidates the prepared copy. Prepared storage adds85 MiB/weight if original storage is retained. Omitting prepared_weight is correct but repacks W every call.

The epilogue computes FP32(acc)*(sx*sw) with BF16 RNE. Validated with finite BF16 activations, full-range random INT8 W, positive finite FP32 scales, zero rows and split-K one-hot controls. See REPORT.md for measurements and scope.

Commands in the current environment: python3 build_bf16.py; python3 validate_bf16.py; python3 benchmark.py; python3 analyze.py. The validation/benchmark scripts explicitly select physical GPU5 on BW47 and must be reviewed before use on another node. The adapter inherits the caller's GPU mapping. No production LightOp registration is replaced.
"""
(R/'README.md').write_text(readme)
print(json.dumps({'ranges':sections,'weight_pack_us':summary['weight_preparation_median_us'],'quant_pipeline':quant,'source_differences':diff,'clocks':clock_summary,'points':[p for p in points if p['M'] in [1,32,64,128,129,192,193,224,256]]},indent=2))
