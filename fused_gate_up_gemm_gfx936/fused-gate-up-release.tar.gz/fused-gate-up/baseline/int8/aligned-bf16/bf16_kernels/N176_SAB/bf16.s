; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.N176_SAB,#alloc,#execinstr
.protected N176_SAB
.globl N176_SAB
.p2align 8
.type N176_SAB,@function
N176_SAB:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v148, 63, v0
v_lshlrev_b32_e32 v148, 4, v148
v_lshrrev_b32_e32 v149, 6, v0
v_lshlrev_b32_e32 v151, 4, v0
v_lshlrev_b32_e32 v152, 10, v149
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_mul_i32 s22, s7, 176
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_mul_i32 s21, s7, 11264
s_mov_b32 s0, s8
s_add_u32 s1, s9, 0x40800000
s_mov_b32 s18, s17
s_mov_b32 s19, s16
s_mov_b32 s26, s20
s_mov_b32 s20, s21
s_mov_b32 s21, s26
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v150, 11, v149
s_add_u32 s10, s10, s21
s_addc_u32 s11, s11, 0
v_add_u32_e32 v150, v150, v148
v_add_u32_e32 v151, s20, v151
v_readfirstlane_b32 s25, v149
v_mov_b32_e32 v159, s11
v_readfirstlane_b32 s26, v152
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[88:91], v150, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[92:95], v150, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s27
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_0_2
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s28
.L_copy_skip_0_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v151, s19, v151
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
v_mov_b32_e32 v64, 0
v_mov_b32_e32 v65, 0
v_mov_b32_e32 v66, 0
v_mov_b32_e32 v67, 0
v_mov_b32_e32 v68, 0
v_mov_b32_e32 v69, 0
v_mov_b32_e32 v70, 0
v_mov_b32_e32 v71, 0
v_mov_b32_e32 v72, 0
v_mov_b32_e32 v73, 0
v_mov_b32_e32 v74, 0
v_mov_b32_e32 v75, 0
v_mov_b32_e32 v76, 0
v_mov_b32_e32 v77, 0
v_mov_b32_e32 v78, 0
v_mov_b32_e32 v79, 0
v_mov_b32_e32 v80, 0
v_mov_b32_e32 v81, 0
v_mov_b32_e32 v82, 0
v_mov_b32_e32 v83, 0
v_mov_b32_e32 v84, 0
v_mov_b32_e32 v85, 0
v_mov_b32_e32 v86, 0
v_mov_b32_e32 v87, 0
s_mov_b32 s24, 40
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
; issue private and shared stage to slot1
GEMM_W_GLOBAL_SADDR_TO_REG v[96:99], v150, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[100:103], v150, s[10:11], 1024
s_add_u32 m0, s26, 11264
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], 0
s_add_u32 m0, s26, 15360
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s27
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_1_2
s_add_u32 m0, s26, 19456
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s28
.L_copy_skip_1_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v151, s19, v151
v_add_u32_e32 v157, 0, v148
GEMM_LDS_TO_REG v[104:107], v157, 0
GEMM_LDS_TO_REG v[108:111], v157, 1024
GEMM_LDS_TO_REG v[112:115], v157, 2048
GEMM_LDS_TO_REG v[116:119], v157, 3072
GEMM_LDS_TO_REG v[120:123], v157, 4096
GEMM_LDS_TO_REG v[124:127], v157, 5120
GEMM_LDS_TO_REG v[128:131], v157, 6144
GEMM_LDS_TO_REG v[132:135], v157, 7168
GEMM_LDS_TO_REG v[136:139], v157, 8192
GEMM_LDS_TO_REG v[140:143], v157, 9216
GEMM_LDS_TO_REG v[144:147], v157, 10240
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[0:3], v[104:105], v[88:89], v[0:3]
GEMM_MMA_I8 v[4:7], v[104:105], v[92:93], v[4:7]
GEMM_MMA_I8 v[0:3], v[106:107], v[90:91], v[0:3]
GEMM_MMA_I8 v[4:7], v[106:107], v[94:95], v[4:7]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[8:11], v[108:109], v[88:89], v[8:11]
GEMM_MMA_I8 v[12:15], v[108:109], v[92:93], v[12:15]
GEMM_MMA_I8 v[8:11], v[110:111], v[90:91], v[8:11]
GEMM_MMA_I8 v[12:15], v[110:111], v[94:95], v[12:15]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[16:19], v[112:113], v[88:89], v[16:19]
GEMM_MMA_I8 v[20:23], v[112:113], v[92:93], v[20:23]
GEMM_MMA_I8 v[16:19], v[114:115], v[90:91], v[16:19]
GEMM_MMA_I8 v[20:23], v[114:115], v[94:95], v[20:23]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[24:27], v[116:117], v[88:89], v[24:27]
GEMM_MMA_I8 v[28:31], v[116:117], v[92:93], v[28:31]
GEMM_MMA_I8 v[24:27], v[118:119], v[90:91], v[24:27]
GEMM_MMA_I8 v[28:31], v[118:119], v[94:95], v[28:31]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[32:35], v[120:121], v[88:89], v[32:35]
GEMM_MMA_I8 v[36:39], v[120:121], v[92:93], v[36:39]
GEMM_MMA_I8 v[32:35], v[122:123], v[90:91], v[32:35]
GEMM_MMA_I8 v[36:39], v[122:123], v[94:95], v[36:39]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[40:43], v[124:125], v[88:89], v[40:43]
GEMM_MMA_I8 v[44:47], v[124:125], v[92:93], v[44:47]
GEMM_MMA_I8 v[40:43], v[126:127], v[90:91], v[40:43]
GEMM_MMA_I8 v[44:47], v[126:127], v[94:95], v[44:47]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[48:51], v[128:129], v[88:89], v[48:51]
GEMM_MMA_I8 v[52:55], v[128:129], v[92:93], v[52:55]
GEMM_MMA_I8 v[48:51], v[130:131], v[90:91], v[48:51]
GEMM_MMA_I8 v[52:55], v[130:131], v[94:95], v[52:55]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[56:59], v[132:133], v[88:89], v[56:59]
GEMM_MMA_I8 v[60:63], v[132:133], v[92:93], v[60:63]
GEMM_MMA_I8 v[56:59], v[134:135], v[90:91], v[56:59]
GEMM_MMA_I8 v[60:63], v[134:135], v[94:95], v[60:63]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[64:67], v[136:137], v[88:89], v[64:67]
GEMM_MMA_I8 v[68:71], v[136:137], v[92:93], v[68:71]
GEMM_MMA_I8 v[64:67], v[138:139], v[90:91], v[64:67]
GEMM_MMA_I8 v[68:71], v[138:139], v[94:95], v[68:71]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[72:75], v[140:141], v[88:89], v[72:75]
GEMM_MMA_I8 v[76:79], v[140:141], v[92:93], v[76:79]
GEMM_MMA_I8 v[72:75], v[142:143], v[90:91], v[72:75]
GEMM_MMA_I8 v[76:79], v[142:143], v[94:95], v[76:79]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[80:83], v[144:145], v[88:89], v[80:83]
GEMM_MMA_I8 v[84:87], v[144:145], v[92:93], v[84:87]
GEMM_MMA_I8 v[80:83], v[146:147], v[90:91], v[80:83]
GEMM_MMA_I8 v[84:87], v[146:147], v[94:95], v[84:87]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_skip_next
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[88:91], v150, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[92:95], v150, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s27
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_2_2
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v151, s[0:3], s28
.L_copy_skip_2_2:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v151, s19, v151
.L_skip_next:
v_add_u32_e32 v157, 11264, v148
GEMM_LDS_TO_REG v[104:107], v157, 0
GEMM_LDS_TO_REG v[108:111], v157, 1024
GEMM_LDS_TO_REG v[112:115], v157, 2048
GEMM_LDS_TO_REG v[116:119], v157, 3072
GEMM_LDS_TO_REG v[120:123], v157, 4096
GEMM_LDS_TO_REG v[124:127], v157, 5120
GEMM_LDS_TO_REG v[128:131], v157, 6144
GEMM_LDS_TO_REG v[132:135], v157, 7168
GEMM_LDS_TO_REG v[136:139], v157, 8192
GEMM_LDS_TO_REG v[140:143], v157, 9216
GEMM_LDS_TO_REG v[144:147], v157, 10240
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[0:3], v[104:105], v[96:97], v[0:3]
GEMM_MMA_I8 v[4:7], v[104:105], v[100:101], v[4:7]
GEMM_MMA_I8 v[0:3], v[106:107], v[98:99], v[0:3]
GEMM_MMA_I8 v[4:7], v[106:107], v[102:103], v[4:7]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[8:11], v[108:109], v[96:97], v[8:11]
GEMM_MMA_I8 v[12:15], v[108:109], v[100:101], v[12:15]
GEMM_MMA_I8 v[8:11], v[110:111], v[98:99], v[8:11]
GEMM_MMA_I8 v[12:15], v[110:111], v[102:103], v[12:15]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[16:19], v[112:113], v[96:97], v[16:19]
GEMM_MMA_I8 v[20:23], v[112:113], v[100:101], v[20:23]
GEMM_MMA_I8 v[16:19], v[114:115], v[98:99], v[16:19]
GEMM_MMA_I8 v[20:23], v[114:115], v[102:103], v[20:23]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[24:27], v[116:117], v[96:97], v[24:27]
GEMM_MMA_I8 v[28:31], v[116:117], v[100:101], v[28:31]
GEMM_MMA_I8 v[24:27], v[118:119], v[98:99], v[24:27]
GEMM_MMA_I8 v[28:31], v[118:119], v[102:103], v[28:31]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[32:35], v[120:121], v[96:97], v[32:35]
GEMM_MMA_I8 v[36:39], v[120:121], v[100:101], v[36:39]
GEMM_MMA_I8 v[32:35], v[122:123], v[98:99], v[32:35]
GEMM_MMA_I8 v[36:39], v[122:123], v[102:103], v[36:39]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[40:43], v[124:125], v[96:97], v[40:43]
GEMM_MMA_I8 v[44:47], v[124:125], v[100:101], v[44:47]
GEMM_MMA_I8 v[40:43], v[126:127], v[98:99], v[40:43]
GEMM_MMA_I8 v[44:47], v[126:127], v[102:103], v[44:47]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[48:51], v[128:129], v[96:97], v[48:51]
GEMM_MMA_I8 v[52:55], v[128:129], v[100:101], v[52:55]
GEMM_MMA_I8 v[48:51], v[130:131], v[98:99], v[48:51]
GEMM_MMA_I8 v[52:55], v[130:131], v[102:103], v[52:55]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[56:59], v[132:133], v[96:97], v[56:59]
GEMM_MMA_I8 v[60:63], v[132:133], v[100:101], v[60:63]
GEMM_MMA_I8 v[56:59], v[134:135], v[98:99], v[56:59]
GEMM_MMA_I8 v[60:63], v[134:135], v[102:103], v[60:63]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[64:67], v[136:137], v[96:97], v[64:67]
GEMM_MMA_I8 v[68:71], v[136:137], v[100:101], v[68:71]
GEMM_MMA_I8 v[64:67], v[138:139], v[98:99], v[64:67]
GEMM_MMA_I8 v[68:71], v[138:139], v[102:103], v[68:71]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[72:75], v[140:141], v[96:97], v[72:75]
GEMM_MMA_I8 v[76:79], v[140:141], v[100:101], v[76:79]
GEMM_MMA_I8 v[72:75], v[142:143], v[98:99], v[72:75]
GEMM_MMA_I8 v[76:79], v[142:143], v[102:103], v[76:79]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[80:83], v[144:145], v[96:97], v[80:83]
GEMM_MMA_I8 v[84:87], v[144:145], v[100:101], v[84:87]
GEMM_MMA_I8 v[80:83], v[146:147], v[98:99], v[80:83]
GEMM_MMA_I8 v[84:87], v[146:147], v[102:103], v[84:87]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
.globl audit_epilogue
audit_epilogue:
GEMM_WAIT_VM 0
s_load_dwordx4 s[0:3], s[4:5], 0x28
GEMM_WAIT_LGKM 0
v_mov_b32_e32 v159, s13
v_lshrrev_b32_e32 v150, 4, v148
v_and_b32_e32 v150, 15, v150
v_lshrrev_b32_e32 v151, 8, v148
v_lshlrev_b32_e32 v151, 4, v151
v_lshlrev_b32_e32 v152, 5, v149
v_lshlrev_b32_e32 v152, 2, v152
v_add_u32_e32 v151, v152, v151
v_add_u32_e32 v150, s22, v150
v_add_u32_e32 v151, s23, v151
global_load_dwordx4 v[88:91], v151, s[2:3] offset:0
global_load_dwordx4 v[92:95], v151, s[2:3] offset:64
v_add_u32_e32 v155, 0, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v0, v0
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v0, v98, v0
v_lshrrev_b32_e32 v98, 16, v0
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v0, 0x7fff, v0
v_add_u32_e32 v0, v98, v0
v_cvt_f32_i32 v1, v1
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v1, v98, v1
v_lshrrev_b32_e32 v98, 16, v1
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v1, 0x7fff, v1
v_add_u32_e32 v1, v98, v1
v_cvt_f32_i32 v2, v2
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v2, v98, v2
v_lshrrev_b32_e32 v98, 16, v2
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v2, 0x7fff, v2
v_add_u32_e32 v2, v98, v2
v_cvt_f32_i32 v3, v3
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v3, v98, v3
v_lshrrev_b32_e32 v98, 16, v3
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v3, 0x7fff, v3
v_add_u32_e32 v3, v98, v3
v_lshrrev_b32_e32 v0, 16, v0
v_and_b32_e32 v1, 0xffff0000, v1
v_or_b32_e32 v0, v0, v1
v_lshrrev_b32_e32 v2, 16, v2
v_and_b32_e32 v3, 0xffff0000, v3
v_or_b32_e32 v1, v2, v3
global_store_dwordx2 v[153:154], v[0:1], off offset:0 glc slc
v_cvt_f32_i32 v4, v4
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v4, v98, v4
v_lshrrev_b32_e32 v98, 16, v4
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v4, 0x7fff, v4
v_add_u32_e32 v4, v98, v4
v_cvt_f32_i32 v5, v5
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v5, v98, v5
v_lshrrev_b32_e32 v98, 16, v5
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v5, 0x7fff, v5
v_add_u32_e32 v5, v98, v5
v_cvt_f32_i32 v6, v6
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v6, v98, v6
v_lshrrev_b32_e32 v98, 16, v6
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v6, 0x7fff, v6
v_add_u32_e32 v6, v98, v6
v_cvt_f32_i32 v7, v7
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v7, v98, v7
v_lshrrev_b32_e32 v98, 16, v7
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v7, 0x7fff, v7
v_add_u32_e32 v7, v98, v7
v_lshrrev_b32_e32 v4, 16, v4
v_and_b32_e32 v5, 0xffff0000, v5
v_or_b32_e32 v4, v4, v5
v_lshrrev_b32_e32 v6, 16, v6
v_and_b32_e32 v7, 0xffff0000, v7
v_or_b32_e32 v5, v6, v7
global_store_dwordx2 v[153:154], v[4:5], off offset:32 glc slc
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 16, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v8, v8
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v8, v98, v8
v_lshrrev_b32_e32 v98, 16, v8
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v8, 0x7fff, v8
v_add_u32_e32 v8, v98, v8
v_cvt_f32_i32 v9, v9
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v9, v98, v9
v_lshrrev_b32_e32 v98, 16, v9
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v9, 0x7fff, v9
v_add_u32_e32 v9, v98, v9
v_cvt_f32_i32 v10, v10
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v10, v98, v10
v_lshrrev_b32_e32 v98, 16, v10
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v10, 0x7fff, v10
v_add_u32_e32 v10, v98, v10
v_cvt_f32_i32 v11, v11
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v11, v98, v11
v_lshrrev_b32_e32 v98, 16, v11
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v11, 0x7fff, v11
v_add_u32_e32 v11, v98, v11
v_lshrrev_b32_e32 v8, 16, v8
v_and_b32_e32 v9, 0xffff0000, v9
v_or_b32_e32 v8, v8, v9
v_lshrrev_b32_e32 v10, 16, v10
v_and_b32_e32 v11, 0xffff0000, v11
v_or_b32_e32 v9, v10, v11
global_store_dwordx2 v[153:154], v[8:9], off offset:0 glc slc
v_cvt_f32_i32 v12, v12
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v12, v98, v12
v_lshrrev_b32_e32 v98, 16, v12
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v12, 0x7fff, v12
v_add_u32_e32 v12, v98, v12
v_cvt_f32_i32 v13, v13
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v13, v98, v13
v_lshrrev_b32_e32 v98, 16, v13
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v13, 0x7fff, v13
v_add_u32_e32 v13, v98, v13
v_cvt_f32_i32 v14, v14
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v14, v98, v14
v_lshrrev_b32_e32 v98, 16, v14
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v14, 0x7fff, v14
v_add_u32_e32 v14, v98, v14
v_cvt_f32_i32 v15, v15
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v15, v98, v15
v_lshrrev_b32_e32 v98, 16, v15
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v15, 0x7fff, v15
v_add_u32_e32 v15, v98, v15
v_lshrrev_b32_e32 v12, 16, v12
v_and_b32_e32 v13, 0xffff0000, v13
v_or_b32_e32 v12, v12, v13
v_lshrrev_b32_e32 v14, 16, v14
v_and_b32_e32 v15, 0xffff0000, v15
v_or_b32_e32 v13, v14, v15
global_store_dwordx2 v[153:154], v[12:13], off offset:32 glc slc
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 32, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_2
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v16, v16
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v16, v98, v16
v_lshrrev_b32_e32 v98, 16, v16
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v16, 0x7fff, v16
v_add_u32_e32 v16, v98, v16
v_cvt_f32_i32 v17, v17
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v17, v98, v17
v_lshrrev_b32_e32 v98, 16, v17
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v17, 0x7fff, v17
v_add_u32_e32 v17, v98, v17
v_cvt_f32_i32 v18, v18
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v18, v98, v18
v_lshrrev_b32_e32 v98, 16, v18
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v18, 0x7fff, v18
v_add_u32_e32 v18, v98, v18
v_cvt_f32_i32 v19, v19
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v19, v98, v19
v_lshrrev_b32_e32 v98, 16, v19
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v19, 0x7fff, v19
v_add_u32_e32 v19, v98, v19
v_lshrrev_b32_e32 v16, 16, v16
v_and_b32_e32 v17, 0xffff0000, v17
v_or_b32_e32 v16, v16, v17
v_lshrrev_b32_e32 v18, 16, v18
v_and_b32_e32 v19, 0xffff0000, v19
v_or_b32_e32 v17, v18, v19
global_store_dwordx2 v[153:154], v[16:17], off offset:0 glc slc
v_cvt_f32_i32 v20, v20
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v20, v98, v20
v_lshrrev_b32_e32 v98, 16, v20
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v20, 0x7fff, v20
v_add_u32_e32 v20, v98, v20
v_cvt_f32_i32 v21, v21
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v21, v98, v21
v_lshrrev_b32_e32 v98, 16, v21
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v21, 0x7fff, v21
v_add_u32_e32 v21, v98, v21
v_cvt_f32_i32 v22, v22
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v22, v98, v22
v_lshrrev_b32_e32 v98, 16, v22
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v22, 0x7fff, v22
v_add_u32_e32 v22, v98, v22
v_cvt_f32_i32 v23, v23
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v23, v98, v23
v_lshrrev_b32_e32 v98, 16, v23
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v23, 0x7fff, v23
v_add_u32_e32 v23, v98, v23
v_lshrrev_b32_e32 v20, 16, v20
v_and_b32_e32 v21, 0xffff0000, v21
v_or_b32_e32 v20, v20, v21
v_lshrrev_b32_e32 v22, 16, v22
v_and_b32_e32 v23, 0xffff0000, v23
v_or_b32_e32 v21, v22, v23
global_store_dwordx2 v[153:154], v[20:21], off offset:32 glc slc
.L_store_skip_2:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 48, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_3
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v24, v24
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v24, v98, v24
v_lshrrev_b32_e32 v98, 16, v24
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v24, 0x7fff, v24
v_add_u32_e32 v24, v98, v24
v_cvt_f32_i32 v25, v25
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v25, v98, v25
v_lshrrev_b32_e32 v98, 16, v25
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v25, 0x7fff, v25
v_add_u32_e32 v25, v98, v25
v_cvt_f32_i32 v26, v26
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v26, v98, v26
v_lshrrev_b32_e32 v98, 16, v26
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v26, 0x7fff, v26
v_add_u32_e32 v26, v98, v26
v_cvt_f32_i32 v27, v27
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v27, v98, v27
v_lshrrev_b32_e32 v98, 16, v27
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v27, 0x7fff, v27
v_add_u32_e32 v27, v98, v27
v_lshrrev_b32_e32 v24, 16, v24
v_and_b32_e32 v25, 0xffff0000, v25
v_or_b32_e32 v24, v24, v25
v_lshrrev_b32_e32 v26, 16, v26
v_and_b32_e32 v27, 0xffff0000, v27
v_or_b32_e32 v25, v26, v27
global_store_dwordx2 v[153:154], v[24:25], off offset:0 glc slc
v_cvt_f32_i32 v28, v28
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v28, v98, v28
v_lshrrev_b32_e32 v98, 16, v28
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v28, 0x7fff, v28
v_add_u32_e32 v28, v98, v28
v_cvt_f32_i32 v29, v29
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v29, v98, v29
v_lshrrev_b32_e32 v98, 16, v29
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v29, 0x7fff, v29
v_add_u32_e32 v29, v98, v29
v_cvt_f32_i32 v30, v30
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v30, v98, v30
v_lshrrev_b32_e32 v98, 16, v30
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v30, 0x7fff, v30
v_add_u32_e32 v30, v98, v30
v_cvt_f32_i32 v31, v31
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v31, v98, v31
v_lshrrev_b32_e32 v98, 16, v31
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v31, 0x7fff, v31
v_add_u32_e32 v31, v98, v31
v_lshrrev_b32_e32 v28, 16, v28
v_and_b32_e32 v29, 0xffff0000, v29
v_or_b32_e32 v28, v28, v29
v_lshrrev_b32_e32 v30, 16, v30
v_and_b32_e32 v31, 0xffff0000, v31
v_or_b32_e32 v29, v30, v31
global_store_dwordx2 v[153:154], v[28:29], off offset:32 glc slc
.L_store_skip_3:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 64, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_4
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v32, v32
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v32, v98, v32
v_lshrrev_b32_e32 v98, 16, v32
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v32, 0x7fff, v32
v_add_u32_e32 v32, v98, v32
v_cvt_f32_i32 v33, v33
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v33, v98, v33
v_lshrrev_b32_e32 v98, 16, v33
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v33, 0x7fff, v33
v_add_u32_e32 v33, v98, v33
v_cvt_f32_i32 v34, v34
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v34, v98, v34
v_lshrrev_b32_e32 v98, 16, v34
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v34, 0x7fff, v34
v_add_u32_e32 v34, v98, v34
v_cvt_f32_i32 v35, v35
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v35, v98, v35
v_lshrrev_b32_e32 v98, 16, v35
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v35, 0x7fff, v35
v_add_u32_e32 v35, v98, v35
v_lshrrev_b32_e32 v32, 16, v32
v_and_b32_e32 v33, 0xffff0000, v33
v_or_b32_e32 v32, v32, v33
v_lshrrev_b32_e32 v34, 16, v34
v_and_b32_e32 v35, 0xffff0000, v35
v_or_b32_e32 v33, v34, v35
global_store_dwordx2 v[153:154], v[32:33], off offset:0 glc slc
v_cvt_f32_i32 v36, v36
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v36, v98, v36
v_lshrrev_b32_e32 v98, 16, v36
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v36, 0x7fff, v36
v_add_u32_e32 v36, v98, v36
v_cvt_f32_i32 v37, v37
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v37, v98, v37
v_lshrrev_b32_e32 v98, 16, v37
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v37, 0x7fff, v37
v_add_u32_e32 v37, v98, v37
v_cvt_f32_i32 v38, v38
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v38, v98, v38
v_lshrrev_b32_e32 v98, 16, v38
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v38, 0x7fff, v38
v_add_u32_e32 v38, v98, v38
v_cvt_f32_i32 v39, v39
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v39, v98, v39
v_lshrrev_b32_e32 v98, 16, v39
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v39, 0x7fff, v39
v_add_u32_e32 v39, v98, v39
v_lshrrev_b32_e32 v36, 16, v36
v_and_b32_e32 v37, 0xffff0000, v37
v_or_b32_e32 v36, v36, v37
v_lshrrev_b32_e32 v38, 16, v38
v_and_b32_e32 v39, 0xffff0000, v39
v_or_b32_e32 v37, v38, v39
global_store_dwordx2 v[153:154], v[36:37], off offset:32 glc slc
.L_store_skip_4:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 80, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_5
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v40, v40
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v40, v98, v40
v_lshrrev_b32_e32 v98, 16, v40
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v40, 0x7fff, v40
v_add_u32_e32 v40, v98, v40
v_cvt_f32_i32 v41, v41
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v41, v98, v41
v_lshrrev_b32_e32 v98, 16, v41
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v41, 0x7fff, v41
v_add_u32_e32 v41, v98, v41
v_cvt_f32_i32 v42, v42
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v42, v98, v42
v_lshrrev_b32_e32 v98, 16, v42
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v42, 0x7fff, v42
v_add_u32_e32 v42, v98, v42
v_cvt_f32_i32 v43, v43
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v43, v98, v43
v_lshrrev_b32_e32 v98, 16, v43
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v43, 0x7fff, v43
v_add_u32_e32 v43, v98, v43
v_lshrrev_b32_e32 v40, 16, v40
v_and_b32_e32 v41, 0xffff0000, v41
v_or_b32_e32 v40, v40, v41
v_lshrrev_b32_e32 v42, 16, v42
v_and_b32_e32 v43, 0xffff0000, v43
v_or_b32_e32 v41, v42, v43
global_store_dwordx2 v[153:154], v[40:41], off offset:0 glc slc
v_cvt_f32_i32 v44, v44
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v44, v98, v44
v_lshrrev_b32_e32 v98, 16, v44
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v44, 0x7fff, v44
v_add_u32_e32 v44, v98, v44
v_cvt_f32_i32 v45, v45
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v45, v98, v45
v_lshrrev_b32_e32 v98, 16, v45
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v45, 0x7fff, v45
v_add_u32_e32 v45, v98, v45
v_cvt_f32_i32 v46, v46
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v46, v98, v46
v_lshrrev_b32_e32 v98, 16, v46
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v46, 0x7fff, v46
v_add_u32_e32 v46, v98, v46
v_cvt_f32_i32 v47, v47
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v47, v98, v47
v_lshrrev_b32_e32 v98, 16, v47
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v47, 0x7fff, v47
v_add_u32_e32 v47, v98, v47
v_lshrrev_b32_e32 v44, 16, v44
v_and_b32_e32 v45, 0xffff0000, v45
v_or_b32_e32 v44, v44, v45
v_lshrrev_b32_e32 v46, 16, v46
v_and_b32_e32 v47, 0xffff0000, v47
v_or_b32_e32 v45, v46, v47
global_store_dwordx2 v[153:154], v[44:45], off offset:32 glc slc
.L_store_skip_5:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 96, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_6
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v48, v48
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v48, v98, v48
v_lshrrev_b32_e32 v98, 16, v48
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v48, 0x7fff, v48
v_add_u32_e32 v48, v98, v48
v_cvt_f32_i32 v49, v49
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v49, v98, v49
v_lshrrev_b32_e32 v98, 16, v49
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v49, 0x7fff, v49
v_add_u32_e32 v49, v98, v49
v_cvt_f32_i32 v50, v50
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v50, v98, v50
v_lshrrev_b32_e32 v98, 16, v50
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v50, 0x7fff, v50
v_add_u32_e32 v50, v98, v50
v_cvt_f32_i32 v51, v51
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v51, v98, v51
v_lshrrev_b32_e32 v98, 16, v51
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v51, 0x7fff, v51
v_add_u32_e32 v51, v98, v51
v_lshrrev_b32_e32 v48, 16, v48
v_and_b32_e32 v49, 0xffff0000, v49
v_or_b32_e32 v48, v48, v49
v_lshrrev_b32_e32 v50, 16, v50
v_and_b32_e32 v51, 0xffff0000, v51
v_or_b32_e32 v49, v50, v51
global_store_dwordx2 v[153:154], v[48:49], off offset:0 glc slc
v_cvt_f32_i32 v52, v52
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v52, v98, v52
v_lshrrev_b32_e32 v98, 16, v52
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v52, 0x7fff, v52
v_add_u32_e32 v52, v98, v52
v_cvt_f32_i32 v53, v53
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v53, v98, v53
v_lshrrev_b32_e32 v98, 16, v53
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v53, 0x7fff, v53
v_add_u32_e32 v53, v98, v53
v_cvt_f32_i32 v54, v54
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v54, v98, v54
v_lshrrev_b32_e32 v98, 16, v54
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v54, 0x7fff, v54
v_add_u32_e32 v54, v98, v54
v_cvt_f32_i32 v55, v55
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v55, v98, v55
v_lshrrev_b32_e32 v98, 16, v55
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v55, 0x7fff, v55
v_add_u32_e32 v55, v98, v55
v_lshrrev_b32_e32 v52, 16, v52
v_and_b32_e32 v53, 0xffff0000, v53
v_or_b32_e32 v52, v52, v53
v_lshrrev_b32_e32 v54, 16, v54
v_and_b32_e32 v55, 0xffff0000, v55
v_or_b32_e32 v53, v54, v55
global_store_dwordx2 v[153:154], v[52:53], off offset:32 glc slc
.L_store_skip_6:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 112, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_7
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v56, v56
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v56, v98, v56
v_lshrrev_b32_e32 v98, 16, v56
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v56, 0x7fff, v56
v_add_u32_e32 v56, v98, v56
v_cvt_f32_i32 v57, v57
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v57, v98, v57
v_lshrrev_b32_e32 v98, 16, v57
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v57, 0x7fff, v57
v_add_u32_e32 v57, v98, v57
v_cvt_f32_i32 v58, v58
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v58, v98, v58
v_lshrrev_b32_e32 v98, 16, v58
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v58, 0x7fff, v58
v_add_u32_e32 v58, v98, v58
v_cvt_f32_i32 v59, v59
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v59, v98, v59
v_lshrrev_b32_e32 v98, 16, v59
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v59, 0x7fff, v59
v_add_u32_e32 v59, v98, v59
v_lshrrev_b32_e32 v56, 16, v56
v_and_b32_e32 v57, 0xffff0000, v57
v_or_b32_e32 v56, v56, v57
v_lshrrev_b32_e32 v58, 16, v58
v_and_b32_e32 v59, 0xffff0000, v59
v_or_b32_e32 v57, v58, v59
global_store_dwordx2 v[153:154], v[56:57], off offset:0 glc slc
v_cvt_f32_i32 v60, v60
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v60, v98, v60
v_lshrrev_b32_e32 v98, 16, v60
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v60, 0x7fff, v60
v_add_u32_e32 v60, v98, v60
v_cvt_f32_i32 v61, v61
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v61, v98, v61
v_lshrrev_b32_e32 v98, 16, v61
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v61, 0x7fff, v61
v_add_u32_e32 v61, v98, v61
v_cvt_f32_i32 v62, v62
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v62, v98, v62
v_lshrrev_b32_e32 v98, 16, v62
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v62, 0x7fff, v62
v_add_u32_e32 v62, v98, v62
v_cvt_f32_i32 v63, v63
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v63, v98, v63
v_lshrrev_b32_e32 v98, 16, v63
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v63, 0x7fff, v63
v_add_u32_e32 v63, v98, v63
v_lshrrev_b32_e32 v60, 16, v60
v_and_b32_e32 v61, 0xffff0000, v61
v_or_b32_e32 v60, v60, v61
v_lshrrev_b32_e32 v62, 16, v62
v_and_b32_e32 v63, 0xffff0000, v63
v_or_b32_e32 v61, v62, v63
global_store_dwordx2 v[153:154], v[60:61], off offset:32 glc slc
.L_store_skip_7:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 128, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_8
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v64, v64
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v64, v98, v64
v_lshrrev_b32_e32 v98, 16, v64
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v64, 0x7fff, v64
v_add_u32_e32 v64, v98, v64
v_cvt_f32_i32 v65, v65
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v65, v98, v65
v_lshrrev_b32_e32 v98, 16, v65
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v65, 0x7fff, v65
v_add_u32_e32 v65, v98, v65
v_cvt_f32_i32 v66, v66
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v66, v98, v66
v_lshrrev_b32_e32 v98, 16, v66
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v66, 0x7fff, v66
v_add_u32_e32 v66, v98, v66
v_cvt_f32_i32 v67, v67
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v67, v98, v67
v_lshrrev_b32_e32 v98, 16, v67
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v67, 0x7fff, v67
v_add_u32_e32 v67, v98, v67
v_lshrrev_b32_e32 v64, 16, v64
v_and_b32_e32 v65, 0xffff0000, v65
v_or_b32_e32 v64, v64, v65
v_lshrrev_b32_e32 v66, 16, v66
v_and_b32_e32 v67, 0xffff0000, v67
v_or_b32_e32 v65, v66, v67
global_store_dwordx2 v[153:154], v[64:65], off offset:0 glc slc
v_cvt_f32_i32 v68, v68
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v68, v98, v68
v_lshrrev_b32_e32 v98, 16, v68
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v68, 0x7fff, v68
v_add_u32_e32 v68, v98, v68
v_cvt_f32_i32 v69, v69
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v69, v98, v69
v_lshrrev_b32_e32 v98, 16, v69
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v69, 0x7fff, v69
v_add_u32_e32 v69, v98, v69
v_cvt_f32_i32 v70, v70
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v70, v98, v70
v_lshrrev_b32_e32 v98, 16, v70
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v70, 0x7fff, v70
v_add_u32_e32 v70, v98, v70
v_cvt_f32_i32 v71, v71
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v71, v98, v71
v_lshrrev_b32_e32 v98, 16, v71
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v71, 0x7fff, v71
v_add_u32_e32 v71, v98, v71
v_lshrrev_b32_e32 v68, 16, v68
v_and_b32_e32 v69, 0xffff0000, v69
v_or_b32_e32 v68, v68, v69
v_lshrrev_b32_e32 v70, 16, v70
v_and_b32_e32 v71, 0xffff0000, v71
v_or_b32_e32 v69, v70, v71
global_store_dwordx2 v[153:154], v[68:69], off offset:32 glc slc
.L_store_skip_8:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 144, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_9
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v72, v72
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v72, v98, v72
v_lshrrev_b32_e32 v98, 16, v72
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v72, 0x7fff, v72
v_add_u32_e32 v72, v98, v72
v_cvt_f32_i32 v73, v73
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v73, v98, v73
v_lshrrev_b32_e32 v98, 16, v73
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v73, 0x7fff, v73
v_add_u32_e32 v73, v98, v73
v_cvt_f32_i32 v74, v74
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v74, v98, v74
v_lshrrev_b32_e32 v98, 16, v74
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v74, 0x7fff, v74
v_add_u32_e32 v74, v98, v74
v_cvt_f32_i32 v75, v75
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v75, v98, v75
v_lshrrev_b32_e32 v98, 16, v75
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v75, 0x7fff, v75
v_add_u32_e32 v75, v98, v75
v_lshrrev_b32_e32 v72, 16, v72
v_and_b32_e32 v73, 0xffff0000, v73
v_or_b32_e32 v72, v72, v73
v_lshrrev_b32_e32 v74, 16, v74
v_and_b32_e32 v75, 0xffff0000, v75
v_or_b32_e32 v73, v74, v75
global_store_dwordx2 v[153:154], v[72:73], off offset:0 glc slc
v_cvt_f32_i32 v76, v76
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v76, v98, v76
v_lshrrev_b32_e32 v98, 16, v76
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v76, 0x7fff, v76
v_add_u32_e32 v76, v98, v76
v_cvt_f32_i32 v77, v77
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v77, v98, v77
v_lshrrev_b32_e32 v98, 16, v77
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v77, 0x7fff, v77
v_add_u32_e32 v77, v98, v77
v_cvt_f32_i32 v78, v78
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v78, v98, v78
v_lshrrev_b32_e32 v98, 16, v78
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v78, 0x7fff, v78
v_add_u32_e32 v78, v98, v78
v_cvt_f32_i32 v79, v79
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v79, v98, v79
v_lshrrev_b32_e32 v98, 16, v79
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v79, 0x7fff, v79
v_add_u32_e32 v79, v98, v79
v_lshrrev_b32_e32 v76, 16, v76
v_and_b32_e32 v77, 0xffff0000, v77
v_or_b32_e32 v76, v76, v77
v_lshrrev_b32_e32 v78, 16, v78
v_and_b32_e32 v79, 0xffff0000, v79
v_or_b32_e32 v77, v78, v79
global_store_dwordx2 v[153:154], v[76:77], off offset:32 glc slc
.L_store_skip_9:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v155, 160, v150
v_cmp_gt_u32_e32 vcc, s14, v155
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_10
v_lshlrev_b32_e32 v97, 2, v155
global_load_dword v96, v97, s[0:1]
v_mul_u32_u24_e32 v156, 0x11000, v155
v_add_u32_e32 v156, v151, v156
v_lshrrev_b32_e32 v156, 1, v156
v_add_co_u32_e32 v153, vcc, s12, v156
v_addc_co_u32_e32 v154, vcc, 0, v159, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v80, v80
v_mul_f32_e32 v98, v96, v88
v_mul_f32_e32 v80, v98, v80
v_lshrrev_b32_e32 v98, 16, v80
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v80, 0x7fff, v80
v_add_u32_e32 v80, v98, v80
v_cvt_f32_i32 v81, v81
v_mul_f32_e32 v98, v96, v89
v_mul_f32_e32 v81, v98, v81
v_lshrrev_b32_e32 v98, 16, v81
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v81, 0x7fff, v81
v_add_u32_e32 v81, v98, v81
v_cvt_f32_i32 v82, v82
v_mul_f32_e32 v98, v96, v90
v_mul_f32_e32 v82, v98, v82
v_lshrrev_b32_e32 v98, 16, v82
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v82, 0x7fff, v82
v_add_u32_e32 v82, v98, v82
v_cvt_f32_i32 v83, v83
v_mul_f32_e32 v98, v96, v91
v_mul_f32_e32 v83, v98, v83
v_lshrrev_b32_e32 v98, 16, v83
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v83, 0x7fff, v83
v_add_u32_e32 v83, v98, v83
v_lshrrev_b32_e32 v80, 16, v80
v_and_b32_e32 v81, 0xffff0000, v81
v_or_b32_e32 v80, v80, v81
v_lshrrev_b32_e32 v82, 16, v82
v_and_b32_e32 v83, 0xffff0000, v83
v_or_b32_e32 v81, v82, v83
global_store_dwordx2 v[153:154], v[80:81], off offset:0 glc slc
v_cvt_f32_i32 v84, v84
v_mul_f32_e32 v98, v96, v92
v_mul_f32_e32 v84, v98, v84
v_lshrrev_b32_e32 v98, 16, v84
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v84, 0x7fff, v84
v_add_u32_e32 v84, v98, v84
v_cvt_f32_i32 v85, v85
v_mul_f32_e32 v98, v96, v93
v_mul_f32_e32 v85, v98, v85
v_lshrrev_b32_e32 v98, 16, v85
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v85, 0x7fff, v85
v_add_u32_e32 v85, v98, v85
v_cvt_f32_i32 v86, v86
v_mul_f32_e32 v98, v96, v94
v_mul_f32_e32 v86, v98, v86
v_lshrrev_b32_e32 v98, 16, v86
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v86, 0x7fff, v86
v_add_u32_e32 v86, v98, v86
v_cvt_f32_i32 v87, v87
v_mul_f32_e32 v98, v96, v95
v_mul_f32_e32 v87, v98, v87
v_lshrrev_b32_e32 v98, 16, v87
v_and_b32_e32 v98, 1, v98
v_add_u32_e32 v87, 0x7fff, v87
v_add_u32_e32 v87, v98, v87
v_lshrrev_b32_e32 v84, 16, v84
v_and_b32_e32 v85, 0xffff0000, v85
v_or_b32_e32 v84, v84, v85
v_lshrrev_b32_e32 v86, 16, v86
v_and_b32_e32 v87, 0xffff0000, v87
v_or_b32_e32 v85, v86, v87
global_store_dwordx2 v[153:154], v[84:85], off offset:32 glc slc
.L_store_skip_10:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size N176_SAB, .L_func_end-N176_SAB
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel N176_SAB
.amdhsa_group_segment_fixed_size 22528
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 56
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 160
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
- .args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .fp64_status: 0
  .group_segment_fixed_size: 22528
  .kernarg_segment_align: 8
  .kernarg_segment_size: 56
  .language: OpenCL C
  .language_version:
  - 2
  - 0
  .max_flat_workgroup_size: 256
  .name: N176_SAB
  .private_segment_fixed_size: 0
  .sgpr_count: 36
  .sgpr_spill_count: 0
  .symbol: N176_SAB.kd
  .unfolded_args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .uniform_work_group_size: 1
  .uses_dynamic_stack: false
  .vgpr_count: 160
  .vgpr_spill_count: 0
  .wavefront_size: 64
amdhsa.target: amdgcn-amd-amdhsa--gfx936:sramecc+
amdhsa.version:
- 1
- 2
...
.end_amdgpu_metadata
