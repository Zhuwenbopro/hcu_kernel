; Physical-register gfx936 kernel, generated deterministically. No device compiler.
.include "common_gfx936.inc"
.text
.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
.section .text.N240_SP12_SAB,#alloc,#execinstr
.protected N240_SP12_SAB
.globl N240_SP12_SAB
.p2align 8
.type N240_SP12_SAB,@function
N240_SP12_SAB:
s_load_dwordx4 s[8:11], s[4:5], 0
s_load_dwordx2 s[12:13], s[4:5], 0x10
s_load_dword s14, s[4:5], 0x18
s_load_dword s15, s[4:5], 0x24
v_and_b32_e32 v196, 63, v0
v_lshlrev_b32_e32 v196, 4, v196
v_lshrrev_b32_e32 v197, 6, v0
v_lshlrev_b32_e32 v199, 4, v0
v_lshlrev_b32_e32 v200, 10, v197
GEMM_WAIT_LGKM 0
s_lshl_b32 s16, s15, 6
s_mov_b32 s17, 0x110000
s_mul_i32 s22, s7, 240
s_lshl_b32 s23, s6, 9
s_lshl_b32 s20, s6, 13
s_mul_i32 s21, s7, 15360
s_mov_b32 s0, s8
s_add_u32 s1, s9, 0x40800000
s_mov_b32 s18, s17
s_mov_b32 s19, s16
s_mov_b32 s26, s20
s_mov_b32 s20, s21
s_mov_b32 s21, s26
s_mov_b32 s2, 0x80000000
s_mov_b32 s3, 0x20000
v_lshlrev_b32_e32 v198, 11, v197
s_add_u32 s10, s10, s21
s_addc_u32 s11, s11, 0
v_add_u32_e32 v198, v198, v196
v_add_u32_e32 v199, s20, v199
v_readfirstlane_b32 s25, v197
v_mov_b32_e32 v207, s11
v_readfirstlane_b32 s26, v200
s_mov_b32 s27, 4096
s_mov_b32 s28, 8192
s_mov_b32 s29, 12288
; issue private and shared stage to slot0
GEMM_W_GLOBAL_SADDR_TO_REG v[120:123], v198, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[124:127], v198, s[10:11], 1024
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s27
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s28
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_0_3
s_add_u32 m0, s26, 12288
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s29
.L_copy_skip_0_3:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v199, s19, v199
v_mov_b32_e32 v0, 0
v_mov_b32_e32 v1, 0
v_mov_b32_e32 v2, 0
v_mov_b32_e32 v3, 0
v_mov_b32_e32 v4, 0
v_mov_b32_e32 v5, 0
v_mov_b32_e32 v6, 0
v_mov_b32_e32 v7, 0
v_mov_b32_e32 v8, 0
v_mov_b32_e32 v9, 0
v_mov_b32_e32 v10, 0
v_mov_b32_e32 v11, 0
v_mov_b32_e32 v12, 0
v_mov_b32_e32 v13, 0
v_mov_b32_e32 v14, 0
v_mov_b32_e32 v15, 0
v_mov_b32_e32 v16, 0
v_mov_b32_e32 v17, 0
v_mov_b32_e32 v18, 0
v_mov_b32_e32 v19, 0
v_mov_b32_e32 v20, 0
v_mov_b32_e32 v21, 0
v_mov_b32_e32 v22, 0
v_mov_b32_e32 v23, 0
v_mov_b32_e32 v24, 0
v_mov_b32_e32 v25, 0
v_mov_b32_e32 v26, 0
v_mov_b32_e32 v27, 0
v_mov_b32_e32 v28, 0
v_mov_b32_e32 v29, 0
v_mov_b32_e32 v30, 0
v_mov_b32_e32 v31, 0
v_mov_b32_e32 v32, 0
v_mov_b32_e32 v33, 0
v_mov_b32_e32 v34, 0
v_mov_b32_e32 v35, 0
v_mov_b32_e32 v36, 0
v_mov_b32_e32 v37, 0
v_mov_b32_e32 v38, 0
v_mov_b32_e32 v39, 0
v_mov_b32_e32 v40, 0
v_mov_b32_e32 v41, 0
v_mov_b32_e32 v42, 0
v_mov_b32_e32 v43, 0
v_mov_b32_e32 v44, 0
v_mov_b32_e32 v45, 0
v_mov_b32_e32 v46, 0
v_mov_b32_e32 v47, 0
v_mov_b32_e32 v48, 0
v_mov_b32_e32 v49, 0
v_mov_b32_e32 v50, 0
v_mov_b32_e32 v51, 0
v_mov_b32_e32 v52, 0
v_mov_b32_e32 v53, 0
v_mov_b32_e32 v54, 0
v_mov_b32_e32 v55, 0
v_mov_b32_e32 v56, 0
v_mov_b32_e32 v57, 0
v_mov_b32_e32 v58, 0
v_mov_b32_e32 v59, 0
v_mov_b32_e32 v60, 0
v_mov_b32_e32 v61, 0
v_mov_b32_e32 v62, 0
v_mov_b32_e32 v63, 0
v_mov_b32_e32 v64, 0
v_mov_b32_e32 v65, 0
v_mov_b32_e32 v66, 0
v_mov_b32_e32 v67, 0
v_mov_b32_e32 v68, 0
v_mov_b32_e32 v69, 0
v_mov_b32_e32 v70, 0
v_mov_b32_e32 v71, 0
v_mov_b32_e32 v72, 0
v_mov_b32_e32 v73, 0
v_mov_b32_e32 v74, 0
v_mov_b32_e32 v75, 0
v_mov_b32_e32 v76, 0
v_mov_b32_e32 v77, 0
v_mov_b32_e32 v78, 0
v_mov_b32_e32 v79, 0
v_mov_b32_e32 v80, 0
v_mov_b32_e32 v81, 0
v_mov_b32_e32 v82, 0
v_mov_b32_e32 v83, 0
v_mov_b32_e32 v84, 0
v_mov_b32_e32 v85, 0
v_mov_b32_e32 v86, 0
v_mov_b32_e32 v87, 0
v_mov_b32_e32 v88, 0
v_mov_b32_e32 v89, 0
v_mov_b32_e32 v90, 0
v_mov_b32_e32 v91, 0
v_mov_b32_e32 v92, 0
v_mov_b32_e32 v93, 0
v_mov_b32_e32 v94, 0
v_mov_b32_e32 v95, 0
v_mov_b32_e32 v96, 0
v_mov_b32_e32 v97, 0
v_mov_b32_e32 v98, 0
v_mov_b32_e32 v99, 0
v_mov_b32_e32 v100, 0
v_mov_b32_e32 v101, 0
v_mov_b32_e32 v102, 0
v_mov_b32_e32 v103, 0
v_mov_b32_e32 v104, 0
v_mov_b32_e32 v105, 0
v_mov_b32_e32 v106, 0
v_mov_b32_e32 v107, 0
v_mov_b32_e32 v108, 0
v_mov_b32_e32 v109, 0
v_mov_b32_e32 v110, 0
v_mov_b32_e32 v111, 0
v_mov_b32_e32 v112, 0
v_mov_b32_e32 v113, 0
v_mov_b32_e32 v114, 0
v_mov_b32_e32 v115, 0
v_mov_b32_e32 v116, 0
v_mov_b32_e32 v117, 0
v_mov_b32_e32 v118, 0
v_mov_b32_e32 v119, 0
s_mov_b32 s24, 40
.p2align 5
.L_pair:
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
v_add_u32_e32 v205, 0, v196
GEMM_LDS_TO_REG v[136:139], v205, 0
GEMM_LDS_TO_REG v[140:143], v205, 1024
GEMM_LDS_TO_REG v[144:147], v205, 2048
GEMM_LDS_TO_REG v[148:151], v205, 3072
GEMM_LDS_TO_REG v[152:155], v205, 4096
GEMM_LDS_TO_REG v[156:159], v205, 5120
GEMM_LDS_TO_REG v[160:163], v205, 6144
GEMM_LDS_TO_REG v[164:167], v205, 7168
GEMM_LDS_TO_REG v[168:171], v205, 8192
GEMM_LDS_TO_REG v[172:175], v205, 9216
GEMM_LDS_TO_REG v[176:179], v205, 10240
GEMM_LDS_TO_REG v[180:183], v205, 11264
GEMM_W_GLOBAL_SADDR_TO_REG v[128:131], v198, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[132:135], v198, s[10:11], 1024
GEMM_LDS_TO_REG v[184:187], v205, 12288
GEMM_LDS_TO_REG v[188:191], v205, 13312
GEMM_LDS_TO_REG v[192:195], v205, 14336
s_add_u32 m0, s26, 15360
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], 0
s_add_u32 m0, s26, 19456
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s27
s_add_u32 m0, s26, 23552
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s28
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_1_3
s_add_u32 m0, s26, 27648
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s29
.L_copy_skip_1_3:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v199, s19, v199
GEMM_WAIT_LGKM 14
GEMM_MMA_I8 v[0:3], v[136:137], v[120:121], v[0:3]
GEMM_MMA_I8 v[4:7], v[136:137], v[124:125], v[4:7]
GEMM_MMA_I8 v[0:3], v[138:139], v[122:123], v[0:3]
GEMM_MMA_I8 v[4:7], v[138:139], v[126:127], v[4:7]
GEMM_WAIT_LGKM 13
GEMM_MMA_I8 v[8:11], v[140:141], v[120:121], v[8:11]
GEMM_MMA_I8 v[12:15], v[140:141], v[124:125], v[12:15]
GEMM_MMA_I8 v[8:11], v[142:143], v[122:123], v[8:11]
GEMM_MMA_I8 v[12:15], v[142:143], v[126:127], v[12:15]
GEMM_WAIT_LGKM 12
GEMM_MMA_I8 v[16:19], v[144:145], v[120:121], v[16:19]
GEMM_MMA_I8 v[20:23], v[144:145], v[124:125], v[20:23]
GEMM_MMA_I8 v[16:19], v[146:147], v[122:123], v[16:19]
GEMM_MMA_I8 v[20:23], v[146:147], v[126:127], v[20:23]
GEMM_WAIT_LGKM 11
GEMM_MMA_I8 v[24:27], v[148:149], v[120:121], v[24:27]
GEMM_MMA_I8 v[28:31], v[148:149], v[124:125], v[28:31]
GEMM_MMA_I8 v[24:27], v[150:151], v[122:123], v[24:27]
GEMM_MMA_I8 v[28:31], v[150:151], v[126:127], v[28:31]
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[32:35], v[152:153], v[120:121], v[32:35]
GEMM_MMA_I8 v[36:39], v[152:153], v[124:125], v[36:39]
GEMM_MMA_I8 v[32:35], v[154:155], v[122:123], v[32:35]
GEMM_MMA_I8 v[36:39], v[154:155], v[126:127], v[36:39]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[40:43], v[156:157], v[120:121], v[40:43]
GEMM_MMA_I8 v[44:47], v[156:157], v[124:125], v[44:47]
GEMM_MMA_I8 v[40:43], v[158:159], v[122:123], v[40:43]
GEMM_MMA_I8 v[44:47], v[158:159], v[126:127], v[44:47]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[48:51], v[160:161], v[120:121], v[48:51]
GEMM_MMA_I8 v[52:55], v[160:161], v[124:125], v[52:55]
GEMM_MMA_I8 v[48:51], v[162:163], v[122:123], v[48:51]
GEMM_MMA_I8 v[52:55], v[162:163], v[126:127], v[52:55]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[56:59], v[164:165], v[120:121], v[56:59]
GEMM_MMA_I8 v[60:63], v[164:165], v[124:125], v[60:63]
GEMM_MMA_I8 v[56:59], v[166:167], v[122:123], v[56:59]
GEMM_MMA_I8 v[60:63], v[166:167], v[126:127], v[60:63]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[64:67], v[168:169], v[120:121], v[64:67]
GEMM_MMA_I8 v[68:71], v[168:169], v[124:125], v[68:71]
GEMM_MMA_I8 v[64:67], v[170:171], v[122:123], v[64:67]
GEMM_MMA_I8 v[68:71], v[170:171], v[126:127], v[68:71]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[72:75], v[172:173], v[120:121], v[72:75]
GEMM_MMA_I8 v[76:79], v[172:173], v[124:125], v[76:79]
GEMM_MMA_I8 v[72:75], v[174:175], v[122:123], v[72:75]
GEMM_MMA_I8 v[76:79], v[174:175], v[126:127], v[76:79]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[80:83], v[176:177], v[120:121], v[80:83]
GEMM_MMA_I8 v[84:87], v[176:177], v[124:125], v[84:87]
GEMM_MMA_I8 v[80:83], v[178:179], v[122:123], v[80:83]
GEMM_MMA_I8 v[84:87], v[178:179], v[126:127], v[84:87]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[88:91], v[180:181], v[120:121], v[88:91]
GEMM_MMA_I8 v[92:95], v[180:181], v[124:125], v[92:95]
GEMM_MMA_I8 v[88:91], v[182:183], v[122:123], v[88:91]
GEMM_MMA_I8 v[92:95], v[182:183], v[126:127], v[92:95]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[96:99], v[184:185], v[120:121], v[96:99]
GEMM_MMA_I8 v[100:103], v[184:185], v[124:125], v[100:103]
GEMM_MMA_I8 v[96:99], v[186:187], v[122:123], v[96:99]
GEMM_MMA_I8 v[100:103], v[186:187], v[126:127], v[100:103]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[104:107], v[188:189], v[120:121], v[104:107]
GEMM_MMA_I8 v[108:111], v[188:189], v[124:125], v[108:111]
GEMM_MMA_I8 v[104:107], v[190:191], v[122:123], v[104:107]
GEMM_MMA_I8 v[108:111], v[190:191], v[126:127], v[108:111]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[112:115], v[192:193], v[120:121], v[112:115]
GEMM_MMA_I8 v[116:119], v[192:193], v[124:125], v[116:119]
GEMM_MMA_I8 v[112:115], v[194:195], v[122:123], v[112:115]
GEMM_MMA_I8 v[116:119], v[194:195], v[126:127], v[116:119]
GEMM_WAIT_VM 0
GEMM_WAIT_LGKM 0
GEMM_CTA_BARRIER
s_sub_u32 s24, s24, 1
v_add_u32_e32 v205, 15360, v196
GEMM_LDS_TO_REG v[136:139], v205, 0
GEMM_LDS_TO_REG v[140:143], v205, 1024
GEMM_LDS_TO_REG v[144:147], v205, 2048
GEMM_LDS_TO_REG v[148:151], v205, 3072
GEMM_LDS_TO_REG v[152:155], v205, 4096
GEMM_LDS_TO_REG v[156:159], v205, 5120
GEMM_LDS_TO_REG v[160:163], v205, 6144
GEMM_LDS_TO_REG v[164:167], v205, 7168
GEMM_LDS_TO_REG v[168:171], v205, 8192
GEMM_LDS_TO_REG v[172:175], v205, 9216
GEMM_LDS_TO_REG v[176:179], v205, 10240
GEMM_LDS_TO_REG v[180:183], v205, 11264
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_P
GEMM_W_GLOBAL_SADDR_TO_REG v[120:123], v198, s[10:11], 0
GEMM_W_GLOBAL_SADDR_TO_REG v[124:127], v198, s[10:11], 1024
.L_custom_skip_P:
GEMM_LDS_TO_REG v[184:187], v205, 12288
GEMM_LDS_TO_REG v[188:191], v205, 13312
GEMM_LDS_TO_REG v[192:195], v205, 14336
s_cmp_eq_u32 s24, 0
s_cbranch_scc1 .L_custom_skip_S
s_mov_b32 m0, s26
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], 0
s_add_u32 m0, s26, 4096
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s27
s_add_u32 m0, s26, 8192
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s28
s_cmp_lt_u32 s25, 3
s_cbranch_scc0 .L_copy_skip_2_3
s_add_u32 m0, s26, 12288
GEMM_X_GLOBAL_TO_LDS v199, s[0:3], s29
.L_copy_skip_2_3:
s_add_u32 s10, s10, s18
s_addc_u32 s11, s11, 0
v_add_u32_e32 v199, s19, v199
.L_custom_skip_S:
GEMM_WAIT_LGKM 14
GEMM_MMA_I8 v[0:3], v[136:137], v[128:129], v[0:3]
GEMM_MMA_I8 v[4:7], v[136:137], v[132:133], v[4:7]
GEMM_MMA_I8 v[0:3], v[138:139], v[130:131], v[0:3]
GEMM_MMA_I8 v[4:7], v[138:139], v[134:135], v[4:7]
GEMM_WAIT_LGKM 13
GEMM_MMA_I8 v[8:11], v[140:141], v[128:129], v[8:11]
GEMM_MMA_I8 v[12:15], v[140:141], v[132:133], v[12:15]
GEMM_MMA_I8 v[8:11], v[142:143], v[130:131], v[8:11]
GEMM_MMA_I8 v[12:15], v[142:143], v[134:135], v[12:15]
GEMM_WAIT_LGKM 12
GEMM_MMA_I8 v[16:19], v[144:145], v[128:129], v[16:19]
GEMM_MMA_I8 v[20:23], v[144:145], v[132:133], v[20:23]
GEMM_MMA_I8 v[16:19], v[146:147], v[130:131], v[16:19]
GEMM_MMA_I8 v[20:23], v[146:147], v[134:135], v[20:23]
GEMM_WAIT_LGKM 11
GEMM_MMA_I8 v[24:27], v[148:149], v[128:129], v[24:27]
GEMM_MMA_I8 v[28:31], v[148:149], v[132:133], v[28:31]
GEMM_MMA_I8 v[24:27], v[150:151], v[130:131], v[24:27]
GEMM_MMA_I8 v[28:31], v[150:151], v[134:135], v[28:31]
GEMM_WAIT_LGKM 10
GEMM_MMA_I8 v[32:35], v[152:153], v[128:129], v[32:35]
GEMM_MMA_I8 v[36:39], v[152:153], v[132:133], v[36:39]
GEMM_MMA_I8 v[32:35], v[154:155], v[130:131], v[32:35]
GEMM_MMA_I8 v[36:39], v[154:155], v[134:135], v[36:39]
GEMM_WAIT_LGKM 9
GEMM_MMA_I8 v[40:43], v[156:157], v[128:129], v[40:43]
GEMM_MMA_I8 v[44:47], v[156:157], v[132:133], v[44:47]
GEMM_MMA_I8 v[40:43], v[158:159], v[130:131], v[40:43]
GEMM_MMA_I8 v[44:47], v[158:159], v[134:135], v[44:47]
GEMM_WAIT_LGKM 8
GEMM_MMA_I8 v[48:51], v[160:161], v[128:129], v[48:51]
GEMM_MMA_I8 v[52:55], v[160:161], v[132:133], v[52:55]
GEMM_MMA_I8 v[48:51], v[162:163], v[130:131], v[48:51]
GEMM_MMA_I8 v[52:55], v[162:163], v[134:135], v[52:55]
GEMM_WAIT_LGKM 7
GEMM_MMA_I8 v[56:59], v[164:165], v[128:129], v[56:59]
GEMM_MMA_I8 v[60:63], v[164:165], v[132:133], v[60:63]
GEMM_MMA_I8 v[56:59], v[166:167], v[130:131], v[56:59]
GEMM_MMA_I8 v[60:63], v[166:167], v[134:135], v[60:63]
GEMM_WAIT_LGKM 6
GEMM_MMA_I8 v[64:67], v[168:169], v[128:129], v[64:67]
GEMM_MMA_I8 v[68:71], v[168:169], v[132:133], v[68:71]
GEMM_MMA_I8 v[64:67], v[170:171], v[130:131], v[64:67]
GEMM_MMA_I8 v[68:71], v[170:171], v[134:135], v[68:71]
GEMM_WAIT_LGKM 5
GEMM_MMA_I8 v[72:75], v[172:173], v[128:129], v[72:75]
GEMM_MMA_I8 v[76:79], v[172:173], v[132:133], v[76:79]
GEMM_MMA_I8 v[72:75], v[174:175], v[130:131], v[72:75]
GEMM_MMA_I8 v[76:79], v[174:175], v[134:135], v[76:79]
GEMM_WAIT_LGKM 4
GEMM_MMA_I8 v[80:83], v[176:177], v[128:129], v[80:83]
GEMM_MMA_I8 v[84:87], v[176:177], v[132:133], v[84:87]
GEMM_MMA_I8 v[80:83], v[178:179], v[130:131], v[80:83]
GEMM_MMA_I8 v[84:87], v[178:179], v[134:135], v[84:87]
GEMM_WAIT_LGKM 3
GEMM_MMA_I8 v[88:91], v[180:181], v[128:129], v[88:91]
GEMM_MMA_I8 v[92:95], v[180:181], v[132:133], v[92:95]
GEMM_MMA_I8 v[88:91], v[182:183], v[130:131], v[88:91]
GEMM_MMA_I8 v[92:95], v[182:183], v[134:135], v[92:95]
GEMM_WAIT_LGKM 2
GEMM_MMA_I8 v[96:99], v[184:185], v[128:129], v[96:99]
GEMM_MMA_I8 v[100:103], v[184:185], v[132:133], v[100:103]
GEMM_MMA_I8 v[96:99], v[186:187], v[130:131], v[96:99]
GEMM_MMA_I8 v[100:103], v[186:187], v[134:135], v[100:103]
GEMM_WAIT_LGKM 1
GEMM_MMA_I8 v[104:107], v[188:189], v[128:129], v[104:107]
GEMM_MMA_I8 v[108:111], v[188:189], v[132:133], v[108:111]
GEMM_MMA_I8 v[104:107], v[190:191], v[130:131], v[104:107]
GEMM_MMA_I8 v[108:111], v[190:191], v[134:135], v[108:111]
GEMM_WAIT_LGKM 0
GEMM_MMA_I8 v[112:115], v[192:193], v[128:129], v[112:115]
GEMM_MMA_I8 v[116:119], v[192:193], v[132:133], v[116:119]
GEMM_MMA_I8 v[112:115], v[194:195], v[130:131], v[112:115]
GEMM_MMA_I8 v[116:119], v[194:195], v[134:135], v[116:119]
s_cmp_lg_u32 s24, 0
s_cbranch_scc1 .L_pair
.globl audit_epilogue
audit_epilogue:
GEMM_WAIT_VM 0
s_load_dwordx4 s[0:3], s[4:5], 0x28
GEMM_WAIT_LGKM 0
v_mov_b32_e32 v207, s13
v_lshrrev_b32_e32 v198, 4, v196
v_and_b32_e32 v198, 15, v198
v_lshrrev_b32_e32 v199, 8, v196
v_lshlrev_b32_e32 v199, 4, v199
v_lshlrev_b32_e32 v200, 5, v197
v_lshlrev_b32_e32 v200, 2, v200
v_add_u32_e32 v199, v200, v199
v_add_u32_e32 v198, s22, v198
v_add_u32_e32 v199, s23, v199
global_load_dwordx4 v[120:123], v199, s[2:3] offset:0
global_load_dwordx4 v[124:127], v199, s[2:3] offset:64
v_add_u32_e32 v203, 0, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_0
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v0, v0
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v0, v130, v0
v_lshrrev_b32_e32 v130, 16, v0
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v0, 0x7fff, v0
v_add_u32_e32 v0, v130, v0
v_cvt_f32_i32 v1, v1
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v1, v130, v1
v_lshrrev_b32_e32 v130, 16, v1
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v1, 0x7fff, v1
v_add_u32_e32 v1, v130, v1
v_cvt_f32_i32 v2, v2
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v2, v130, v2
v_lshrrev_b32_e32 v130, 16, v2
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v2, 0x7fff, v2
v_add_u32_e32 v2, v130, v2
v_cvt_f32_i32 v3, v3
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v3, v130, v3
v_lshrrev_b32_e32 v130, 16, v3
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v3, 0x7fff, v3
v_add_u32_e32 v3, v130, v3
v_lshrrev_b32_e32 v0, 16, v0
v_and_b32_e32 v1, 0xffff0000, v1
v_or_b32_e32 v0, v0, v1
v_lshrrev_b32_e32 v2, 16, v2
v_and_b32_e32 v3, 0xffff0000, v3
v_or_b32_e32 v1, v2, v3
global_store_dwordx2 v[201:202], v[0:1], off offset:0 glc slc
v_cvt_f32_i32 v4, v4
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v4, v130, v4
v_lshrrev_b32_e32 v130, 16, v4
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v4, 0x7fff, v4
v_add_u32_e32 v4, v130, v4
v_cvt_f32_i32 v5, v5
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v5, v130, v5
v_lshrrev_b32_e32 v130, 16, v5
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v5, 0x7fff, v5
v_add_u32_e32 v5, v130, v5
v_cvt_f32_i32 v6, v6
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v6, v130, v6
v_lshrrev_b32_e32 v130, 16, v6
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v6, 0x7fff, v6
v_add_u32_e32 v6, v130, v6
v_cvt_f32_i32 v7, v7
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v7, v130, v7
v_lshrrev_b32_e32 v130, 16, v7
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v7, 0x7fff, v7
v_add_u32_e32 v7, v130, v7
v_lshrrev_b32_e32 v4, 16, v4
v_and_b32_e32 v5, 0xffff0000, v5
v_or_b32_e32 v4, v4, v5
v_lshrrev_b32_e32 v6, 16, v6
v_and_b32_e32 v7, 0xffff0000, v7
v_or_b32_e32 v5, v6, v7
global_store_dwordx2 v[201:202], v[4:5], off offset:32 glc slc
.L_store_skip_0:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 16, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_1
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v8, v8
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v8, v130, v8
v_lshrrev_b32_e32 v130, 16, v8
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v8, 0x7fff, v8
v_add_u32_e32 v8, v130, v8
v_cvt_f32_i32 v9, v9
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v9, v130, v9
v_lshrrev_b32_e32 v130, 16, v9
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v9, 0x7fff, v9
v_add_u32_e32 v9, v130, v9
v_cvt_f32_i32 v10, v10
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v10, v130, v10
v_lshrrev_b32_e32 v130, 16, v10
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v10, 0x7fff, v10
v_add_u32_e32 v10, v130, v10
v_cvt_f32_i32 v11, v11
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v11, v130, v11
v_lshrrev_b32_e32 v130, 16, v11
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v11, 0x7fff, v11
v_add_u32_e32 v11, v130, v11
v_lshrrev_b32_e32 v8, 16, v8
v_and_b32_e32 v9, 0xffff0000, v9
v_or_b32_e32 v8, v8, v9
v_lshrrev_b32_e32 v10, 16, v10
v_and_b32_e32 v11, 0xffff0000, v11
v_or_b32_e32 v9, v10, v11
global_store_dwordx2 v[201:202], v[8:9], off offset:0 glc slc
v_cvt_f32_i32 v12, v12
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v12, v130, v12
v_lshrrev_b32_e32 v130, 16, v12
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v12, 0x7fff, v12
v_add_u32_e32 v12, v130, v12
v_cvt_f32_i32 v13, v13
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v13, v130, v13
v_lshrrev_b32_e32 v130, 16, v13
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v13, 0x7fff, v13
v_add_u32_e32 v13, v130, v13
v_cvt_f32_i32 v14, v14
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v14, v130, v14
v_lshrrev_b32_e32 v130, 16, v14
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v14, 0x7fff, v14
v_add_u32_e32 v14, v130, v14
v_cvt_f32_i32 v15, v15
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v15, v130, v15
v_lshrrev_b32_e32 v130, 16, v15
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v15, 0x7fff, v15
v_add_u32_e32 v15, v130, v15
v_lshrrev_b32_e32 v12, 16, v12
v_and_b32_e32 v13, 0xffff0000, v13
v_or_b32_e32 v12, v12, v13
v_lshrrev_b32_e32 v14, 16, v14
v_and_b32_e32 v15, 0xffff0000, v15
v_or_b32_e32 v13, v14, v15
global_store_dwordx2 v[201:202], v[12:13], off offset:32 glc slc
.L_store_skip_1:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 32, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_2
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v16, v16
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v16, v130, v16
v_lshrrev_b32_e32 v130, 16, v16
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v16, 0x7fff, v16
v_add_u32_e32 v16, v130, v16
v_cvt_f32_i32 v17, v17
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v17, v130, v17
v_lshrrev_b32_e32 v130, 16, v17
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v17, 0x7fff, v17
v_add_u32_e32 v17, v130, v17
v_cvt_f32_i32 v18, v18
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v18, v130, v18
v_lshrrev_b32_e32 v130, 16, v18
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v18, 0x7fff, v18
v_add_u32_e32 v18, v130, v18
v_cvt_f32_i32 v19, v19
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v19, v130, v19
v_lshrrev_b32_e32 v130, 16, v19
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v19, 0x7fff, v19
v_add_u32_e32 v19, v130, v19
v_lshrrev_b32_e32 v16, 16, v16
v_and_b32_e32 v17, 0xffff0000, v17
v_or_b32_e32 v16, v16, v17
v_lshrrev_b32_e32 v18, 16, v18
v_and_b32_e32 v19, 0xffff0000, v19
v_or_b32_e32 v17, v18, v19
global_store_dwordx2 v[201:202], v[16:17], off offset:0 glc slc
v_cvt_f32_i32 v20, v20
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v20, v130, v20
v_lshrrev_b32_e32 v130, 16, v20
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v20, 0x7fff, v20
v_add_u32_e32 v20, v130, v20
v_cvt_f32_i32 v21, v21
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v21, v130, v21
v_lshrrev_b32_e32 v130, 16, v21
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v21, 0x7fff, v21
v_add_u32_e32 v21, v130, v21
v_cvt_f32_i32 v22, v22
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v22, v130, v22
v_lshrrev_b32_e32 v130, 16, v22
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v22, 0x7fff, v22
v_add_u32_e32 v22, v130, v22
v_cvt_f32_i32 v23, v23
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v23, v130, v23
v_lshrrev_b32_e32 v130, 16, v23
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v23, 0x7fff, v23
v_add_u32_e32 v23, v130, v23
v_lshrrev_b32_e32 v20, 16, v20
v_and_b32_e32 v21, 0xffff0000, v21
v_or_b32_e32 v20, v20, v21
v_lshrrev_b32_e32 v22, 16, v22
v_and_b32_e32 v23, 0xffff0000, v23
v_or_b32_e32 v21, v22, v23
global_store_dwordx2 v[201:202], v[20:21], off offset:32 glc slc
.L_store_skip_2:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 48, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_3
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v24, v24
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v24, v130, v24
v_lshrrev_b32_e32 v130, 16, v24
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v24, 0x7fff, v24
v_add_u32_e32 v24, v130, v24
v_cvt_f32_i32 v25, v25
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v25, v130, v25
v_lshrrev_b32_e32 v130, 16, v25
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v25, 0x7fff, v25
v_add_u32_e32 v25, v130, v25
v_cvt_f32_i32 v26, v26
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v26, v130, v26
v_lshrrev_b32_e32 v130, 16, v26
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v26, 0x7fff, v26
v_add_u32_e32 v26, v130, v26
v_cvt_f32_i32 v27, v27
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v27, v130, v27
v_lshrrev_b32_e32 v130, 16, v27
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v27, 0x7fff, v27
v_add_u32_e32 v27, v130, v27
v_lshrrev_b32_e32 v24, 16, v24
v_and_b32_e32 v25, 0xffff0000, v25
v_or_b32_e32 v24, v24, v25
v_lshrrev_b32_e32 v26, 16, v26
v_and_b32_e32 v27, 0xffff0000, v27
v_or_b32_e32 v25, v26, v27
global_store_dwordx2 v[201:202], v[24:25], off offset:0 glc slc
v_cvt_f32_i32 v28, v28
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v28, v130, v28
v_lshrrev_b32_e32 v130, 16, v28
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v28, 0x7fff, v28
v_add_u32_e32 v28, v130, v28
v_cvt_f32_i32 v29, v29
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v29, v130, v29
v_lshrrev_b32_e32 v130, 16, v29
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v29, 0x7fff, v29
v_add_u32_e32 v29, v130, v29
v_cvt_f32_i32 v30, v30
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v30, v130, v30
v_lshrrev_b32_e32 v130, 16, v30
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v30, 0x7fff, v30
v_add_u32_e32 v30, v130, v30
v_cvt_f32_i32 v31, v31
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v31, v130, v31
v_lshrrev_b32_e32 v130, 16, v31
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v31, 0x7fff, v31
v_add_u32_e32 v31, v130, v31
v_lshrrev_b32_e32 v28, 16, v28
v_and_b32_e32 v29, 0xffff0000, v29
v_or_b32_e32 v28, v28, v29
v_lshrrev_b32_e32 v30, 16, v30
v_and_b32_e32 v31, 0xffff0000, v31
v_or_b32_e32 v29, v30, v31
global_store_dwordx2 v[201:202], v[28:29], off offset:32 glc slc
.L_store_skip_3:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 64, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_4
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v32, v32
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v32, v130, v32
v_lshrrev_b32_e32 v130, 16, v32
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v32, 0x7fff, v32
v_add_u32_e32 v32, v130, v32
v_cvt_f32_i32 v33, v33
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v33, v130, v33
v_lshrrev_b32_e32 v130, 16, v33
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v33, 0x7fff, v33
v_add_u32_e32 v33, v130, v33
v_cvt_f32_i32 v34, v34
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v34, v130, v34
v_lshrrev_b32_e32 v130, 16, v34
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v34, 0x7fff, v34
v_add_u32_e32 v34, v130, v34
v_cvt_f32_i32 v35, v35
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v35, v130, v35
v_lshrrev_b32_e32 v130, 16, v35
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v35, 0x7fff, v35
v_add_u32_e32 v35, v130, v35
v_lshrrev_b32_e32 v32, 16, v32
v_and_b32_e32 v33, 0xffff0000, v33
v_or_b32_e32 v32, v32, v33
v_lshrrev_b32_e32 v34, 16, v34
v_and_b32_e32 v35, 0xffff0000, v35
v_or_b32_e32 v33, v34, v35
global_store_dwordx2 v[201:202], v[32:33], off offset:0 glc slc
v_cvt_f32_i32 v36, v36
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v36, v130, v36
v_lshrrev_b32_e32 v130, 16, v36
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v36, 0x7fff, v36
v_add_u32_e32 v36, v130, v36
v_cvt_f32_i32 v37, v37
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v37, v130, v37
v_lshrrev_b32_e32 v130, 16, v37
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v37, 0x7fff, v37
v_add_u32_e32 v37, v130, v37
v_cvt_f32_i32 v38, v38
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v38, v130, v38
v_lshrrev_b32_e32 v130, 16, v38
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v38, 0x7fff, v38
v_add_u32_e32 v38, v130, v38
v_cvt_f32_i32 v39, v39
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v39, v130, v39
v_lshrrev_b32_e32 v130, 16, v39
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v39, 0x7fff, v39
v_add_u32_e32 v39, v130, v39
v_lshrrev_b32_e32 v36, 16, v36
v_and_b32_e32 v37, 0xffff0000, v37
v_or_b32_e32 v36, v36, v37
v_lshrrev_b32_e32 v38, 16, v38
v_and_b32_e32 v39, 0xffff0000, v39
v_or_b32_e32 v37, v38, v39
global_store_dwordx2 v[201:202], v[36:37], off offset:32 glc slc
.L_store_skip_4:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 80, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_5
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v40, v40
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v40, v130, v40
v_lshrrev_b32_e32 v130, 16, v40
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v40, 0x7fff, v40
v_add_u32_e32 v40, v130, v40
v_cvt_f32_i32 v41, v41
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v41, v130, v41
v_lshrrev_b32_e32 v130, 16, v41
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v41, 0x7fff, v41
v_add_u32_e32 v41, v130, v41
v_cvt_f32_i32 v42, v42
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v42, v130, v42
v_lshrrev_b32_e32 v130, 16, v42
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v42, 0x7fff, v42
v_add_u32_e32 v42, v130, v42
v_cvt_f32_i32 v43, v43
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v43, v130, v43
v_lshrrev_b32_e32 v130, 16, v43
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v43, 0x7fff, v43
v_add_u32_e32 v43, v130, v43
v_lshrrev_b32_e32 v40, 16, v40
v_and_b32_e32 v41, 0xffff0000, v41
v_or_b32_e32 v40, v40, v41
v_lshrrev_b32_e32 v42, 16, v42
v_and_b32_e32 v43, 0xffff0000, v43
v_or_b32_e32 v41, v42, v43
global_store_dwordx2 v[201:202], v[40:41], off offset:0 glc slc
v_cvt_f32_i32 v44, v44
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v44, v130, v44
v_lshrrev_b32_e32 v130, 16, v44
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v44, 0x7fff, v44
v_add_u32_e32 v44, v130, v44
v_cvt_f32_i32 v45, v45
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v45, v130, v45
v_lshrrev_b32_e32 v130, 16, v45
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v45, 0x7fff, v45
v_add_u32_e32 v45, v130, v45
v_cvt_f32_i32 v46, v46
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v46, v130, v46
v_lshrrev_b32_e32 v130, 16, v46
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v46, 0x7fff, v46
v_add_u32_e32 v46, v130, v46
v_cvt_f32_i32 v47, v47
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v47, v130, v47
v_lshrrev_b32_e32 v130, 16, v47
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v47, 0x7fff, v47
v_add_u32_e32 v47, v130, v47
v_lshrrev_b32_e32 v44, 16, v44
v_and_b32_e32 v45, 0xffff0000, v45
v_or_b32_e32 v44, v44, v45
v_lshrrev_b32_e32 v46, 16, v46
v_and_b32_e32 v47, 0xffff0000, v47
v_or_b32_e32 v45, v46, v47
global_store_dwordx2 v[201:202], v[44:45], off offset:32 glc slc
.L_store_skip_5:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 96, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_6
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v48, v48
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v48, v130, v48
v_lshrrev_b32_e32 v130, 16, v48
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v48, 0x7fff, v48
v_add_u32_e32 v48, v130, v48
v_cvt_f32_i32 v49, v49
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v49, v130, v49
v_lshrrev_b32_e32 v130, 16, v49
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v49, 0x7fff, v49
v_add_u32_e32 v49, v130, v49
v_cvt_f32_i32 v50, v50
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v50, v130, v50
v_lshrrev_b32_e32 v130, 16, v50
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v50, 0x7fff, v50
v_add_u32_e32 v50, v130, v50
v_cvt_f32_i32 v51, v51
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v51, v130, v51
v_lshrrev_b32_e32 v130, 16, v51
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v51, 0x7fff, v51
v_add_u32_e32 v51, v130, v51
v_lshrrev_b32_e32 v48, 16, v48
v_and_b32_e32 v49, 0xffff0000, v49
v_or_b32_e32 v48, v48, v49
v_lshrrev_b32_e32 v50, 16, v50
v_and_b32_e32 v51, 0xffff0000, v51
v_or_b32_e32 v49, v50, v51
global_store_dwordx2 v[201:202], v[48:49], off offset:0 glc slc
v_cvt_f32_i32 v52, v52
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v52, v130, v52
v_lshrrev_b32_e32 v130, 16, v52
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v52, 0x7fff, v52
v_add_u32_e32 v52, v130, v52
v_cvt_f32_i32 v53, v53
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v53, v130, v53
v_lshrrev_b32_e32 v130, 16, v53
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v53, 0x7fff, v53
v_add_u32_e32 v53, v130, v53
v_cvt_f32_i32 v54, v54
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v54, v130, v54
v_lshrrev_b32_e32 v130, 16, v54
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v54, 0x7fff, v54
v_add_u32_e32 v54, v130, v54
v_cvt_f32_i32 v55, v55
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v55, v130, v55
v_lshrrev_b32_e32 v130, 16, v55
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v55, 0x7fff, v55
v_add_u32_e32 v55, v130, v55
v_lshrrev_b32_e32 v52, 16, v52
v_and_b32_e32 v53, 0xffff0000, v53
v_or_b32_e32 v52, v52, v53
v_lshrrev_b32_e32 v54, 16, v54
v_and_b32_e32 v55, 0xffff0000, v55
v_or_b32_e32 v53, v54, v55
global_store_dwordx2 v[201:202], v[52:53], off offset:32 glc slc
.L_store_skip_6:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 112, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_7
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v56, v56
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v56, v130, v56
v_lshrrev_b32_e32 v130, 16, v56
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v56, 0x7fff, v56
v_add_u32_e32 v56, v130, v56
v_cvt_f32_i32 v57, v57
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v57, v130, v57
v_lshrrev_b32_e32 v130, 16, v57
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v57, 0x7fff, v57
v_add_u32_e32 v57, v130, v57
v_cvt_f32_i32 v58, v58
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v58, v130, v58
v_lshrrev_b32_e32 v130, 16, v58
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v58, 0x7fff, v58
v_add_u32_e32 v58, v130, v58
v_cvt_f32_i32 v59, v59
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v59, v130, v59
v_lshrrev_b32_e32 v130, 16, v59
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v59, 0x7fff, v59
v_add_u32_e32 v59, v130, v59
v_lshrrev_b32_e32 v56, 16, v56
v_and_b32_e32 v57, 0xffff0000, v57
v_or_b32_e32 v56, v56, v57
v_lshrrev_b32_e32 v58, 16, v58
v_and_b32_e32 v59, 0xffff0000, v59
v_or_b32_e32 v57, v58, v59
global_store_dwordx2 v[201:202], v[56:57], off offset:0 glc slc
v_cvt_f32_i32 v60, v60
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v60, v130, v60
v_lshrrev_b32_e32 v130, 16, v60
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v60, 0x7fff, v60
v_add_u32_e32 v60, v130, v60
v_cvt_f32_i32 v61, v61
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v61, v130, v61
v_lshrrev_b32_e32 v130, 16, v61
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v61, 0x7fff, v61
v_add_u32_e32 v61, v130, v61
v_cvt_f32_i32 v62, v62
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v62, v130, v62
v_lshrrev_b32_e32 v130, 16, v62
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v62, 0x7fff, v62
v_add_u32_e32 v62, v130, v62
v_cvt_f32_i32 v63, v63
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v63, v130, v63
v_lshrrev_b32_e32 v130, 16, v63
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v63, 0x7fff, v63
v_add_u32_e32 v63, v130, v63
v_lshrrev_b32_e32 v60, 16, v60
v_and_b32_e32 v61, 0xffff0000, v61
v_or_b32_e32 v60, v60, v61
v_lshrrev_b32_e32 v62, 16, v62
v_and_b32_e32 v63, 0xffff0000, v63
v_or_b32_e32 v61, v62, v63
global_store_dwordx2 v[201:202], v[60:61], off offset:32 glc slc
.L_store_skip_7:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 128, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_8
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v64, v64
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v64, v130, v64
v_lshrrev_b32_e32 v130, 16, v64
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v64, 0x7fff, v64
v_add_u32_e32 v64, v130, v64
v_cvt_f32_i32 v65, v65
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v65, v130, v65
v_lshrrev_b32_e32 v130, 16, v65
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v65, 0x7fff, v65
v_add_u32_e32 v65, v130, v65
v_cvt_f32_i32 v66, v66
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v66, v130, v66
v_lshrrev_b32_e32 v130, 16, v66
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v66, 0x7fff, v66
v_add_u32_e32 v66, v130, v66
v_cvt_f32_i32 v67, v67
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v67, v130, v67
v_lshrrev_b32_e32 v130, 16, v67
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v67, 0x7fff, v67
v_add_u32_e32 v67, v130, v67
v_lshrrev_b32_e32 v64, 16, v64
v_and_b32_e32 v65, 0xffff0000, v65
v_or_b32_e32 v64, v64, v65
v_lshrrev_b32_e32 v66, 16, v66
v_and_b32_e32 v67, 0xffff0000, v67
v_or_b32_e32 v65, v66, v67
global_store_dwordx2 v[201:202], v[64:65], off offset:0 glc slc
v_cvt_f32_i32 v68, v68
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v68, v130, v68
v_lshrrev_b32_e32 v130, 16, v68
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v68, 0x7fff, v68
v_add_u32_e32 v68, v130, v68
v_cvt_f32_i32 v69, v69
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v69, v130, v69
v_lshrrev_b32_e32 v130, 16, v69
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v69, 0x7fff, v69
v_add_u32_e32 v69, v130, v69
v_cvt_f32_i32 v70, v70
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v70, v130, v70
v_lshrrev_b32_e32 v130, 16, v70
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v70, 0x7fff, v70
v_add_u32_e32 v70, v130, v70
v_cvt_f32_i32 v71, v71
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v71, v130, v71
v_lshrrev_b32_e32 v130, 16, v71
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v71, 0x7fff, v71
v_add_u32_e32 v71, v130, v71
v_lshrrev_b32_e32 v68, 16, v68
v_and_b32_e32 v69, 0xffff0000, v69
v_or_b32_e32 v68, v68, v69
v_lshrrev_b32_e32 v70, 16, v70
v_and_b32_e32 v71, 0xffff0000, v71
v_or_b32_e32 v69, v70, v71
global_store_dwordx2 v[201:202], v[68:69], off offset:32 glc slc
.L_store_skip_8:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 144, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_9
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v72, v72
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v72, v130, v72
v_lshrrev_b32_e32 v130, 16, v72
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v72, 0x7fff, v72
v_add_u32_e32 v72, v130, v72
v_cvt_f32_i32 v73, v73
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v73, v130, v73
v_lshrrev_b32_e32 v130, 16, v73
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v73, 0x7fff, v73
v_add_u32_e32 v73, v130, v73
v_cvt_f32_i32 v74, v74
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v74, v130, v74
v_lshrrev_b32_e32 v130, 16, v74
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v74, 0x7fff, v74
v_add_u32_e32 v74, v130, v74
v_cvt_f32_i32 v75, v75
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v75, v130, v75
v_lshrrev_b32_e32 v130, 16, v75
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v75, 0x7fff, v75
v_add_u32_e32 v75, v130, v75
v_lshrrev_b32_e32 v72, 16, v72
v_and_b32_e32 v73, 0xffff0000, v73
v_or_b32_e32 v72, v72, v73
v_lshrrev_b32_e32 v74, 16, v74
v_and_b32_e32 v75, 0xffff0000, v75
v_or_b32_e32 v73, v74, v75
global_store_dwordx2 v[201:202], v[72:73], off offset:0 glc slc
v_cvt_f32_i32 v76, v76
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v76, v130, v76
v_lshrrev_b32_e32 v130, 16, v76
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v76, 0x7fff, v76
v_add_u32_e32 v76, v130, v76
v_cvt_f32_i32 v77, v77
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v77, v130, v77
v_lshrrev_b32_e32 v130, 16, v77
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v77, 0x7fff, v77
v_add_u32_e32 v77, v130, v77
v_cvt_f32_i32 v78, v78
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v78, v130, v78
v_lshrrev_b32_e32 v130, 16, v78
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v78, 0x7fff, v78
v_add_u32_e32 v78, v130, v78
v_cvt_f32_i32 v79, v79
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v79, v130, v79
v_lshrrev_b32_e32 v130, 16, v79
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v79, 0x7fff, v79
v_add_u32_e32 v79, v130, v79
v_lshrrev_b32_e32 v76, 16, v76
v_and_b32_e32 v77, 0xffff0000, v77
v_or_b32_e32 v76, v76, v77
v_lshrrev_b32_e32 v78, 16, v78
v_and_b32_e32 v79, 0xffff0000, v79
v_or_b32_e32 v77, v78, v79
global_store_dwordx2 v[201:202], v[76:77], off offset:32 glc slc
.L_store_skip_9:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 160, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_10
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v80, v80
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v80, v130, v80
v_lshrrev_b32_e32 v130, 16, v80
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v80, 0x7fff, v80
v_add_u32_e32 v80, v130, v80
v_cvt_f32_i32 v81, v81
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v81, v130, v81
v_lshrrev_b32_e32 v130, 16, v81
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v81, 0x7fff, v81
v_add_u32_e32 v81, v130, v81
v_cvt_f32_i32 v82, v82
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v82, v130, v82
v_lshrrev_b32_e32 v130, 16, v82
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v82, 0x7fff, v82
v_add_u32_e32 v82, v130, v82
v_cvt_f32_i32 v83, v83
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v83, v130, v83
v_lshrrev_b32_e32 v130, 16, v83
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v83, 0x7fff, v83
v_add_u32_e32 v83, v130, v83
v_lshrrev_b32_e32 v80, 16, v80
v_and_b32_e32 v81, 0xffff0000, v81
v_or_b32_e32 v80, v80, v81
v_lshrrev_b32_e32 v82, 16, v82
v_and_b32_e32 v83, 0xffff0000, v83
v_or_b32_e32 v81, v82, v83
global_store_dwordx2 v[201:202], v[80:81], off offset:0 glc slc
v_cvt_f32_i32 v84, v84
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v84, v130, v84
v_lshrrev_b32_e32 v130, 16, v84
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v84, 0x7fff, v84
v_add_u32_e32 v84, v130, v84
v_cvt_f32_i32 v85, v85
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v85, v130, v85
v_lshrrev_b32_e32 v130, 16, v85
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v85, 0x7fff, v85
v_add_u32_e32 v85, v130, v85
v_cvt_f32_i32 v86, v86
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v86, v130, v86
v_lshrrev_b32_e32 v130, 16, v86
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v86, 0x7fff, v86
v_add_u32_e32 v86, v130, v86
v_cvt_f32_i32 v87, v87
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v87, v130, v87
v_lshrrev_b32_e32 v130, 16, v87
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v87, 0x7fff, v87
v_add_u32_e32 v87, v130, v87
v_lshrrev_b32_e32 v84, 16, v84
v_and_b32_e32 v85, 0xffff0000, v85
v_or_b32_e32 v84, v84, v85
v_lshrrev_b32_e32 v86, 16, v86
v_and_b32_e32 v87, 0xffff0000, v87
v_or_b32_e32 v85, v86, v87
global_store_dwordx2 v[201:202], v[84:85], off offset:32 glc slc
.L_store_skip_10:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 176, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_11
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v88, v88
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v88, v130, v88
v_lshrrev_b32_e32 v130, 16, v88
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v88, 0x7fff, v88
v_add_u32_e32 v88, v130, v88
v_cvt_f32_i32 v89, v89
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v89, v130, v89
v_lshrrev_b32_e32 v130, 16, v89
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v89, 0x7fff, v89
v_add_u32_e32 v89, v130, v89
v_cvt_f32_i32 v90, v90
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v90, v130, v90
v_lshrrev_b32_e32 v130, 16, v90
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v90, 0x7fff, v90
v_add_u32_e32 v90, v130, v90
v_cvt_f32_i32 v91, v91
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v91, v130, v91
v_lshrrev_b32_e32 v130, 16, v91
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v91, 0x7fff, v91
v_add_u32_e32 v91, v130, v91
v_lshrrev_b32_e32 v88, 16, v88
v_and_b32_e32 v89, 0xffff0000, v89
v_or_b32_e32 v88, v88, v89
v_lshrrev_b32_e32 v90, 16, v90
v_and_b32_e32 v91, 0xffff0000, v91
v_or_b32_e32 v89, v90, v91
global_store_dwordx2 v[201:202], v[88:89], off offset:0 glc slc
v_cvt_f32_i32 v92, v92
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v92, v130, v92
v_lshrrev_b32_e32 v130, 16, v92
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v92, 0x7fff, v92
v_add_u32_e32 v92, v130, v92
v_cvt_f32_i32 v93, v93
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v93, v130, v93
v_lshrrev_b32_e32 v130, 16, v93
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v93, 0x7fff, v93
v_add_u32_e32 v93, v130, v93
v_cvt_f32_i32 v94, v94
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v94, v130, v94
v_lshrrev_b32_e32 v130, 16, v94
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v94, 0x7fff, v94
v_add_u32_e32 v94, v130, v94
v_cvt_f32_i32 v95, v95
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v95, v130, v95
v_lshrrev_b32_e32 v130, 16, v95
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v95, 0x7fff, v95
v_add_u32_e32 v95, v130, v95
v_lshrrev_b32_e32 v92, 16, v92
v_and_b32_e32 v93, 0xffff0000, v93
v_or_b32_e32 v92, v92, v93
v_lshrrev_b32_e32 v94, 16, v94
v_and_b32_e32 v95, 0xffff0000, v95
v_or_b32_e32 v93, v94, v95
global_store_dwordx2 v[201:202], v[92:93], off offset:32 glc slc
.L_store_skip_11:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 192, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_12
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v96, v96
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v96, v130, v96
v_lshrrev_b32_e32 v130, 16, v96
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v96, 0x7fff, v96
v_add_u32_e32 v96, v130, v96
v_cvt_f32_i32 v97, v97
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v97, v130, v97
v_lshrrev_b32_e32 v130, 16, v97
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v97, 0x7fff, v97
v_add_u32_e32 v97, v130, v97
v_cvt_f32_i32 v98, v98
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v98, v130, v98
v_lshrrev_b32_e32 v130, 16, v98
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v98, 0x7fff, v98
v_add_u32_e32 v98, v130, v98
v_cvt_f32_i32 v99, v99
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v99, v130, v99
v_lshrrev_b32_e32 v130, 16, v99
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v99, 0x7fff, v99
v_add_u32_e32 v99, v130, v99
v_lshrrev_b32_e32 v96, 16, v96
v_and_b32_e32 v97, 0xffff0000, v97
v_or_b32_e32 v96, v96, v97
v_lshrrev_b32_e32 v98, 16, v98
v_and_b32_e32 v99, 0xffff0000, v99
v_or_b32_e32 v97, v98, v99
global_store_dwordx2 v[201:202], v[96:97], off offset:0 glc slc
v_cvt_f32_i32 v100, v100
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v100, v130, v100
v_lshrrev_b32_e32 v130, 16, v100
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v100, 0x7fff, v100
v_add_u32_e32 v100, v130, v100
v_cvt_f32_i32 v101, v101
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v101, v130, v101
v_lshrrev_b32_e32 v130, 16, v101
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v101, 0x7fff, v101
v_add_u32_e32 v101, v130, v101
v_cvt_f32_i32 v102, v102
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v102, v130, v102
v_lshrrev_b32_e32 v130, 16, v102
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v102, 0x7fff, v102
v_add_u32_e32 v102, v130, v102
v_cvt_f32_i32 v103, v103
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v103, v130, v103
v_lshrrev_b32_e32 v130, 16, v103
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v103, 0x7fff, v103
v_add_u32_e32 v103, v130, v103
v_lshrrev_b32_e32 v100, 16, v100
v_and_b32_e32 v101, 0xffff0000, v101
v_or_b32_e32 v100, v100, v101
v_lshrrev_b32_e32 v102, 16, v102
v_and_b32_e32 v103, 0xffff0000, v103
v_or_b32_e32 v101, v102, v103
global_store_dwordx2 v[201:202], v[100:101], off offset:32 glc slc
.L_store_skip_12:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 208, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_13
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v104, v104
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v104, v130, v104
v_lshrrev_b32_e32 v130, 16, v104
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v104, 0x7fff, v104
v_add_u32_e32 v104, v130, v104
v_cvt_f32_i32 v105, v105
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v105, v130, v105
v_lshrrev_b32_e32 v130, 16, v105
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v105, 0x7fff, v105
v_add_u32_e32 v105, v130, v105
v_cvt_f32_i32 v106, v106
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v106, v130, v106
v_lshrrev_b32_e32 v130, 16, v106
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v106, 0x7fff, v106
v_add_u32_e32 v106, v130, v106
v_cvt_f32_i32 v107, v107
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v107, v130, v107
v_lshrrev_b32_e32 v130, 16, v107
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v107, 0x7fff, v107
v_add_u32_e32 v107, v130, v107
v_lshrrev_b32_e32 v104, 16, v104
v_and_b32_e32 v105, 0xffff0000, v105
v_or_b32_e32 v104, v104, v105
v_lshrrev_b32_e32 v106, 16, v106
v_and_b32_e32 v107, 0xffff0000, v107
v_or_b32_e32 v105, v106, v107
global_store_dwordx2 v[201:202], v[104:105], off offset:0 glc slc
v_cvt_f32_i32 v108, v108
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v108, v130, v108
v_lshrrev_b32_e32 v130, 16, v108
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v108, 0x7fff, v108
v_add_u32_e32 v108, v130, v108
v_cvt_f32_i32 v109, v109
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v109, v130, v109
v_lshrrev_b32_e32 v130, 16, v109
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v109, 0x7fff, v109
v_add_u32_e32 v109, v130, v109
v_cvt_f32_i32 v110, v110
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v110, v130, v110
v_lshrrev_b32_e32 v130, 16, v110
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v110, 0x7fff, v110
v_add_u32_e32 v110, v130, v110
v_cvt_f32_i32 v111, v111
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v111, v130, v111
v_lshrrev_b32_e32 v130, 16, v111
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v111, 0x7fff, v111
v_add_u32_e32 v111, v130, v111
v_lshrrev_b32_e32 v108, 16, v108
v_and_b32_e32 v109, 0xffff0000, v109
v_or_b32_e32 v108, v108, v109
v_lshrrev_b32_e32 v110, 16, v110
v_and_b32_e32 v111, 0xffff0000, v111
v_or_b32_e32 v109, v110, v111
global_store_dwordx2 v[201:202], v[108:109], off offset:32 glc slc
.L_store_skip_13:
s_or_b64 exec, exec, s[28:29]
v_add_u32_e32 v203, 224, v198
v_cmp_gt_u32_e32 vcc, s14, v203
s_and_saveexec_b64 s[28:29], vcc
s_cbranch_execz .L_store_skip_14
v_lshlrev_b32_e32 v129, 2, v203
global_load_dword v128, v129, s[0:1]
v_mul_u32_u24_e32 v204, 0x11000, v203
v_add_u32_e32 v204, v199, v204
v_lshrrev_b32_e32 v204, 1, v204
v_add_co_u32_e32 v201, vcc, s12, v204
v_addc_co_u32_e32 v202, vcc, 0, v207, vcc
GEMM_WAIT_VM 0
v_cvt_f32_i32 v112, v112
v_mul_f32_e32 v130, v128, v120
v_mul_f32_e32 v112, v130, v112
v_lshrrev_b32_e32 v130, 16, v112
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v112, 0x7fff, v112
v_add_u32_e32 v112, v130, v112
v_cvt_f32_i32 v113, v113
v_mul_f32_e32 v130, v128, v121
v_mul_f32_e32 v113, v130, v113
v_lshrrev_b32_e32 v130, 16, v113
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v113, 0x7fff, v113
v_add_u32_e32 v113, v130, v113
v_cvt_f32_i32 v114, v114
v_mul_f32_e32 v130, v128, v122
v_mul_f32_e32 v114, v130, v114
v_lshrrev_b32_e32 v130, 16, v114
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v114, 0x7fff, v114
v_add_u32_e32 v114, v130, v114
v_cvt_f32_i32 v115, v115
v_mul_f32_e32 v130, v128, v123
v_mul_f32_e32 v115, v130, v115
v_lshrrev_b32_e32 v130, 16, v115
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v115, 0x7fff, v115
v_add_u32_e32 v115, v130, v115
v_lshrrev_b32_e32 v112, 16, v112
v_and_b32_e32 v113, 0xffff0000, v113
v_or_b32_e32 v112, v112, v113
v_lshrrev_b32_e32 v114, 16, v114
v_and_b32_e32 v115, 0xffff0000, v115
v_or_b32_e32 v113, v114, v115
global_store_dwordx2 v[201:202], v[112:113], off offset:0 glc slc
v_cvt_f32_i32 v116, v116
v_mul_f32_e32 v130, v128, v124
v_mul_f32_e32 v116, v130, v116
v_lshrrev_b32_e32 v130, 16, v116
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v116, 0x7fff, v116
v_add_u32_e32 v116, v130, v116
v_cvt_f32_i32 v117, v117
v_mul_f32_e32 v130, v128, v125
v_mul_f32_e32 v117, v130, v117
v_lshrrev_b32_e32 v130, 16, v117
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v117, 0x7fff, v117
v_add_u32_e32 v117, v130, v117
v_cvt_f32_i32 v118, v118
v_mul_f32_e32 v130, v128, v126
v_mul_f32_e32 v118, v130, v118
v_lshrrev_b32_e32 v130, 16, v118
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v118, 0x7fff, v118
v_add_u32_e32 v118, v130, v118
v_cvt_f32_i32 v119, v119
v_mul_f32_e32 v130, v128, v127
v_mul_f32_e32 v119, v130, v119
v_lshrrev_b32_e32 v130, 16, v119
v_and_b32_e32 v130, 1, v130
v_add_u32_e32 v119, 0x7fff, v119
v_add_u32_e32 v119, v130, v119
v_lshrrev_b32_e32 v116, 16, v116
v_and_b32_e32 v117, 0xffff0000, v117
v_or_b32_e32 v116, v116, v117
v_lshrrev_b32_e32 v118, 16, v118
v_and_b32_e32 v119, 0xffff0000, v119
v_or_b32_e32 v117, v118, v119
global_store_dwordx2 v[201:202], v[116:117], off offset:32 glc slc
.L_store_skip_14:
s_or_b64 exec, exec, s[28:29]
s_endpgm
.L_func_end:
.size N240_SP12_SAB, .L_func_end-N240_SP12_SAB
.section .rodata,#alloc
.p2align 6
.amdhsa_kernel N240_SP12_SAB
.amdhsa_group_segment_fixed_size 30720
.amdhsa_private_segment_fixed_size 0
.amdhsa_kernarg_size 56
.amdhsa_user_sgpr_count 6
.amdhsa_user_sgpr_private_segment_buffer 1
.amdhsa_user_sgpr_dispatch_ptr 0
.amdhsa_user_sgpr_queue_ptr 0
.amdhsa_user_sgpr_kernarg_segment_ptr 1
.amdhsa_user_sgpr_dispatch_id 0
.amdhsa_user_sgpr_flat_scratch_init 0
.amdhsa_user_sgpr_private_segment_size 0
.amdhsa_uses_dynamic_stack 0
.amdhsa_system_sgpr_private_segment_wavefront_offset 0
.amdhsa_system_sgpr_workgroup_id_x 1
.amdhsa_system_sgpr_workgroup_id_y 1
.amdhsa_system_sgpr_workgroup_id_z 0
.amdhsa_system_sgpr_workgroup_info 0
.amdhsa_system_vgpr_workitem_id 0
.amdhsa_next_free_vgpr 208
.amdhsa_next_free_sgpr 32
.amdhsa_reserve_flat_scratch 0
.amdhsa_reserve_xnack_mask 1
.amdhsa_float_round_mode_32 0
.amdhsa_float_round_mode_16_64 0
.amdhsa_float_denorm_mode_32 3
.amdhsa_float_denorm_mode_16_64 3
.amdhsa_dx10_clamp 1
.amdhsa_ieee_mode 1
.amdhsa_fp16_overflow 0
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.kernels:
- .args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .fp64_status: 0
  .group_segment_fixed_size: 30720
  .kernarg_segment_align: 8
  .kernarg_segment_size: 56
  .language: OpenCL C
  .language_version:
  - 2
  - 0
  .max_flat_workgroup_size: 256
  .name: N240_SP12_SAB
  .private_segment_fixed_size: 0
  .sgpr_count: 36
  .sgpr_spill_count: 0
  .symbol: N240_SP12_SAB.kd
  .unfolded_args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .uniform_work_group_size: 1
  .uses_dynamic_stack: false
  .vgpr_count: 208
  .vgpr_spill_count: 0
  .wavefront_size: 64
amdhsa.target: amdgcn-amd-amdhsa--gfx936:sramecc+
amdhsa.version:
- 1
- 2
...
.end_amdgpu_metadata
