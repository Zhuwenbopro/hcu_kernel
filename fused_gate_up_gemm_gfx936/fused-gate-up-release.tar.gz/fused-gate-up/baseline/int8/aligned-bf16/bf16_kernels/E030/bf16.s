	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z8reg_E030PKaS0_Piiiii ; -- Begin function _Z8reg_E030PKaS0_Piiiii
	.globl	_Z8reg_E030PKaS0_Piiiii
	.p2align	8
	.type	_Z8reg_E030PKaS0_Piiiii,@function
_Z8reg_E030PKaS0_Piiiii:                ; @_Z8reg_E030PKaS0_Piiiii
s_load_dwordx4 s[24:27], s[4:5], 0x28
; %bb.0:
	s_load_dwordx4 s[8:11], s[4:5], 0x18
	s_load_dwordx4 s[16:19], s[4:5], 0x0
	s_load_dwordx2 s[12:13], s[4:5], 0x10
	s_lshl_b32 s4, s6, 6
	v_and_b32_e32 v61, 63, v0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s0, s10, 31
	s_lshr_b32 s0, s0, 26
	s_add_i32 s0, s10, s0
	s_ashr_i32 s1, s0, 6
	s_add_i32 s0, s1, 1
	s_lshr_b32 s2, s0, 31
	s_add_i32 s0, s0, s2
	s_ashr_i32 s2, s9, 31
	s_lshr_b32 s2, s2, 28
	s_add_i32 s2, s9, s2
	s_ashr_i32 s14, s2, 4
	s_ashr_i32 s2, s11, 31
	s_lshr_b32 s2, s2, 28
	s_add_i32 s2, s11, s2
	s_ashr_i32 s11, s2, 4
	s_ashr_i32 s2, s4, 4
	s_ashr_i32 s3, s2, 31
	s_ashr_i32 s15, s0, 1
	s_lshl_b32 s5, s7, 5
	s_lshl_b64 s[2:3], s[2:3], 10
	s_add_u32 s2, s18, s2
	v_lshlrev_b32_e32 v4, 4, v61
	v_lshrrev_b32_e32 v62, 6, v0
	s_addc_u32 s3, s19, s3
	v_add_co_u32_e32 v57, vcc, s2, v4
	s_ashr_i32 s2, s5, 4
	v_mul_lo_u32 v63, s15, v62
	v_mov_b32_e32 v1, s3
	s_ashr_i32 s3, s2, 31
	s_lshl_b64 s[2:3], s[2:3], 10
	s_add_u32 s16, s16, s2
	s_addc_u32 s17, s17, s3
	s_add_i32 s6, s1, -1
	v_addc_co_u32_e32 v58, vcc, 0, v1, vcc
	v_min_i32_e32 v1, s6, v63
	v_ashrrev_i32_e32 v2, 31, v1
	s_ashr_i32 s7, s14, 31
	v_lshlrev_b32_e32 v5, 10, v1
	v_alignbit_b32 v6, v2, v1, 22
	s_mov_b32 s0, 0
	v_mul_lo_u32 v7, v6, s14
	v_mul_lo_u32 v8, v5, s7
	v_mad_u64_u32 v[1:2], s[2:3], v5, s14, v[57:58]
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	v_sub_u32_e32 v3, s1, v63
	s_mov_b32 s1, s0
	v_mov_b64_e32 v[35:36], s[2:3]
	v_min_i32_e32 v65, s15, v3
	v_mov_b32_e32 v3, s17
	v_mov_b64_e32 v[33:34], s[0:1]
	v_mov_b64_e32 v[39:40], v[35:36]
	v_add_co_u32_e32 v59, vcc, s16, v4
	s_mov_b32 s10, 1
	v_max_i32_e32 v64, 0, v65
	v_add3_u32 v2, v7, v2, v8
	v_mov_b64_e32 v[37:38], v[33:34]
	v_addc_co_u32_e32 v60, vcc, 0, v3, vcc
	;;#ASMSTART
	global_load_dwordx4 v[37:40], v[1:2], off
	;;#ASMEND
	s_movk_i32 s15, 0x400
	v_add_co_u32_e32 v3, vcc, s15, v1
	v_mov_b64_e32 v[43:44], v[35:36]
	v_addc_co_u32_e32 v4, vcc, 0, v2, vcc
	v_mov_b64_e32 v[41:42], v[33:34]
	;;#ASMSTART
	global_load_dwordx4 v[41:44], v[3:4], off
	;;#ASMEND
	s_movk_i32 s16, 0x800
	v_add_co_u32_e32 v3, vcc, s16, v1
	v_mov_b64_e32 v[47:48], v[35:36]
	v_addc_co_u32_e32 v4, vcc, 0, v2, vcc
	v_mov_b64_e32 v[45:46], v[33:34]
	;;#ASMSTART
	global_load_dwordx4 v[45:48], v[3:4], off
	;;#ASMEND
	s_movk_i32 s17, 0xc00
	v_add_co_u32_e32 v1, vcc, s17, v1
	v_mov_b64_e32 v[51:52], v[35:36]
	v_addc_co_u32_e32 v2, vcc, 0, v2, vcc
	v_mov_b64_e32 v[49:50], v[33:34]
	;;#ASMSTART
	global_load_dwordx4 v[49:52], v[1:2], off
	;;#ASMEND
	s_ashr_i32 s18, s11, 31
	v_mul_lo_u32 v3, v6, s11
	v_mad_u64_u32 v[1:2], s[20:21], v5, s11, v[59:60]
	v_mul_lo_u32 v4, v5, s18
	v_mov_b64_e32 v[55:56], v[35:36]
	v_mov_b64_e32 v[53:54], v[33:34]
	v_add3_u32 v2, v3, v2, v4
	;;#ASMSTART
	global_load_dwordx4 v[53:56], v[1:2], off
	;;#ASMEND
	v_add_co_u32_e32 v1, vcc, 0x400, v1
	v_addc_co_u32_e32 v2, vcc, 0, v2, vcc
	;;#ASMSTART
	global_load_dwordx4 v[33:36], v[1:2], off
	;;#ASMEND
	v_mov_b64_e32 v[19:20], s[2:3]
	v_mov_b64_e32 v[17:18], s[0:1]
	v_mov_b64_e32 v[23:24], v[19:20]
	v_mov_b64_e32 v[27:28], v[19:20]
	v_mov_b64_e32 v[31:32], v[19:20]
	v_mov_b64_e32 v[5:6], v[17:18]
	v_mov_b64_e32 v[9:10], v[17:18]
	v_mov_b64_e32 v[13:14], v[17:18]
	v_mov_b64_e32 v[1:2], v[17:18]
	v_cmp_lt_u32_e32 vcc, 1, v64
	v_mov_b32_e32 v66, 0
	v_mov_b64_e32 v[21:22], v[17:18]
	v_mov_b64_e32 v[25:26], v[17:18]
	v_mov_b64_e32 v[29:30], v[17:18]
	v_mov_b64_e32 v[7:8], v[19:20]
	v_mov_b64_e32 v[11:12], v[19:20]
	v_mov_b64_e32 v[15:16], v[19:20]
	v_mov_b64_e32 v[3:4], v[19:20]
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB0_4
; %bb.1:
	v_max_i32_e32 v1, 1, v65
	v_mov_b32_e32 v17, 0
	v_add_u32_e32 v65, -1, v1
	s_mov_b64 s[2:3], 0
	v_mov_b32_e32 v18, v17
	v_mov_b32_e32 v19, v17
	v_mov_b32_e32 v20, v17
	v_mov_b32_e32 v21, v17
	v_mov_b32_e32 v22, v17
	v_mov_b32_e32 v23, v17
	v_mov_b32_e32 v24, v17
	v_mov_b32_e32 v25, v17
	v_mov_b32_e32 v26, v17
	v_mov_b32_e32 v27, v17
	v_mov_b32_e32 v28, v17
	v_mov_b32_e32 v29, v17
	v_mov_b32_e32 v30, v17
	v_mov_b32_e32 v31, v17
	v_mov_b32_e32 v32, v17
	v_mov_b32_e32 v5, v17
	v_mov_b32_e32 v6, v17
	v_mov_b32_e32 v7, v17
	v_mov_b32_e32 v8, v17
	v_mov_b32_e32 v9, v17
	v_mov_b32_e32 v10, v17
	v_mov_b32_e32 v11, v17
	v_mov_b32_e32 v12, v17
	v_mov_b32_e32 v13, v17
	v_mov_b32_e32 v14, v17
	v_mov_b32_e32 v15, v17
	v_mov_b32_e32 v16, v17
	v_mov_b32_e32 v1, v17
	v_mov_b32_e32 v2, v17
	v_mov_b32_e32 v3, v17
	v_mov_b32_e32 v4, v17
.LBB0_2:                                ; =>This Inner Loop Header: Depth=1
	;;#ASMSTART
	s_waitcnt vmcnt(0)
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	v_min_i32_e32 v66, s10, v65
	v_add_u32_e32 v66, v66, v63
	v_min_i32_e32 v66, s6, v66
	v_ashrrev_i32_e32 v67, 31, v66
	v_lshlrev_b32_e32 v70, 10, v66
	v_alignbit_b32 v71, v67, v66, 22
	v_mul_lo_u32 v68, v71, s14
	v_mul_lo_u32 v69, v70, s7
	v_mad_u64_u32 v[66:67], s[20:21], v70, s14, v[57:58]
	v_mmac_i32_16x16x32_i8 v[17:20], v[53:54], v[37:38], v[17:20]
	v_mmac_i32_16x16x32_i8 v[21:24], v[53:54], v[41:42], v[21:24]
	v_mmac_i32_16x16x32_i8 v[25:28], v[53:54], v[45:46], v[25:28]
	v_mmac_i32_16x16x32_i8 v[29:32], v[53:54], v[49:50], v[29:32]
	v_mmac_i32_16x16x32_i8 v[5:8], v[33:34], v[37:38], v[5:8]
	v_mmac_i32_16x16x32_i8 v[9:12], v[33:34], v[41:42], v[9:12]
	v_mmac_i32_16x16x32_i8 v[13:16], v[33:34], v[45:46], v[13:16]
	v_mmac_i32_16x16x32_i8 v[1:4], v[33:34], v[49:50], v[1:4]
	v_mmac_i32_16x16x32_i8 v[17:20], v[55:56], v[39:40], v[17:20]
	v_mmac_i32_16x16x32_i8 v[21:24], v[55:56], v[43:44], v[21:24]
	v_mmac_i32_16x16x32_i8 v[25:28], v[55:56], v[47:48], v[25:28]
	v_mmac_i32_16x16x32_i8 v[29:32], v[55:56], v[51:52], v[29:32]
	v_mmac_i32_16x16x32_i8 v[5:8], v[35:36], v[39:40], v[5:8]
	v_mmac_i32_16x16x32_i8 v[9:12], v[35:36], v[43:44], v[9:12]
	v_mmac_i32_16x16x32_i8 v[13:16], v[35:36], v[47:48], v[13:16]
	v_add3_u32 v67, v68, v67, v69
	v_mmac_i32_16x16x32_i8 v[1:4], v[35:36], v[51:52], v[1:4]
	;;#ASMSTART
	global_load_dwordx4 v[37:40], v[66:67], off
	;;#ASMEND
	v_add_co_u32_e32 v68, vcc, s15, v66
	v_addc_co_u32_e32 v69, vcc, 0, v67, vcc
	;;#ASMSTART
	global_load_dwordx4 v[41:44], v[68:69], off
	;;#ASMEND
	v_add_co_u32_e32 v68, vcc, s16, v66
	v_addc_co_u32_e32 v69, vcc, 0, v67, vcc
	;;#ASMSTART
	global_load_dwordx4 v[45:48], v[68:69], off
	;;#ASMEND
	v_add_co_u32_e32 v66, vcc, s17, v66
	v_addc_co_u32_e32 v67, vcc, 0, v67, vcc
	;;#ASMSTART
	global_load_dwordx4 v[49:52], v[66:67], off
	;;#ASMEND
	v_mul_lo_u32 v68, v71, s11
	v_mul_lo_u32 v69, v70, s18
	v_mad_u64_u32 v[66:67], s[20:21], v70, s11, v[59:60]
	v_add3_u32 v67, v68, v67, v69
	;;#ASMSTART
	global_load_dwordx4 v[53:56], v[66:67], off
	;;#ASMEND
	v_add_co_u32_e32 v66, vcc, s15, v66
	v_addc_co_u32_e32 v67, vcc, 0, v67, vcc
	;;#ASMSTART
	global_load_dwordx4 v[33:36], v[66:67], off
	;;#ASMEND
	s_add_i32 s10, s10, 1
	v_cmp_eq_u32_e32 vcc, s10, v64
	s_or_b64 s[2:3], vcc, s[2:3]
	s_andn2_b64 exec, exec, s[2:3]
	s_cbranch_execnz .LBB0_2
; %bb.3:
	s_or_b64 exec, exec, s[2:3]
	v_add_u32_e32 v66, -1, v64
.LBB0_4:
	s_or_b64 exec, exec, s[0:1]
	;;#ASMSTART
	s_waitcnt vmcnt(0)
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	v_cmp_lt_u32_e32 vcc, v66, v64
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB0_6
; %bb.5:
	v_mmac_i32_16x16x32_i8 v[17:20], v[53:54], v[37:38], v[17:20]
	v_mmac_i32_16x16x32_i8 v[21:24], v[53:54], v[41:42], v[21:24]
	v_mmac_i32_16x16x32_i8 v[25:28], v[53:54], v[45:46], v[25:28]
	v_mmac_i32_16x16x32_i8 v[29:32], v[53:54], v[49:50], v[29:32]
	v_mmac_i32_16x16x32_i8 v[5:8], v[33:34], v[37:38], v[5:8]
	v_mmac_i32_16x16x32_i8 v[9:12], v[33:34], v[41:42], v[9:12]
	v_mmac_i32_16x16x32_i8 v[13:16], v[33:34], v[45:46], v[13:16]
	v_mmac_i32_16x16x32_i8 v[1:4], v[33:34], v[49:50], v[1:4]
	v_mmac_i32_16x16x32_i8 v[17:20], v[55:56], v[39:40], v[17:20]
	v_mmac_i32_16x16x32_i8 v[21:24], v[55:56], v[43:44], v[21:24]
	v_mmac_i32_16x16x32_i8 v[25:28], v[55:56], v[47:48], v[25:28]
	v_mmac_i32_16x16x32_i8 v[29:32], v[55:56], v[51:52], v[29:32]
	v_mmac_i32_16x16x32_i8 v[5:8], v[35:36], v[39:40], v[5:8]
	v_mmac_i32_16x16x32_i8 v[9:12], v[35:36], v[43:44], v[9:12]
	v_mmac_i32_16x16x32_i8 v[13:16], v[35:36], v[47:48], v[13:16]
	v_mmac_i32_16x16x32_i8 v[1:4], v[35:36], v[51:52], v[1:4]
.LBB0_6:
	s_or_b64 exec, exec, s[0:1]
	;;#ASMSTART
	s_waitcnt vmcnt(0)
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	;;#ASMSTART
	;;#ASMEND
	v_cmp_eq_u32_e32 vcc, 0, v62
	v_cmp_ne_u32_e64 s[0:1], 0, v62
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_8
; %bb.7:
	v_lshlrev_b32_e32 v33, 9, v62
	v_or_b32_e32 v34, v33, v61
	v_lshlrev_b32_e32 v34, 4, v34
	v_add_u32_e32 v35, 0xffffe000, v34
	ds_write_b128 v35, v[17:20]
	v_add_u32_e32 v35, 0xffffe400, v34
	ds_write_b128 v35, v[21:24]
	v_add_u32_e32 v35, 0xffffe800, v34
	ds_write_b128 v35, v[25:28]
	v_add_u32_e32 v35, 0xffffec00, v34
	ds_write_b128 v35, v[29:32]
	v_add_u32_e32 v35, 0xfffff000, v34
	ds_write_b128 v35, v[5:8]
	v_add_u32_e32 v35, 0xfffff400, v34
	v_add_u32_e32 v34, 0xfffff800, v34
	ds_write_b128 v34, v[13:16]
	v_or_b32_e32 v34, 0xfffffc0, v0
	v_add_lshl_u32 v33, v33, v34, 4
	ds_write_b128 v35, v[9:12]
	ds_write_b128 v33, v[1:4]
.LBB0_8:
	s_or_b64 exec, exec, s[2:3]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB0_13
.globl audit_epilogue
audit_epilogue:
; %bb.9:
v_lshlrev_b32_e32 v65, 4, v61
ds_read_b128 v[33:36], v65 offset:0
ds_read_b128 v[37:40], v65 offset:1024
ds_read_b128 v[41:44], v65 offset:2048
ds_read_b128 v[45:48], v65 offset:3072
ds_read_b128 v[49:52], v65 offset:4096
ds_read_b128 v[53:56], v65 offset:5120
ds_read_b128 v[57:60], v65 offset:6144
ds_read_b128 v[61:64], v65 offset:7168
s_waitcnt lgkmcnt(0)
v_add_u32_e32 v17, v33, v17
v_add_u32_e32 v18, v34, v18
v_add_u32_e32 v19, v35, v19
v_add_u32_e32 v20, v36, v20
v_add_u32_e32 v21, v37, v21
v_add_u32_e32 v22, v38, v22
v_add_u32_e32 v23, v39, v23
v_add_u32_e32 v24, v40, v24
v_add_u32_e32 v25, v41, v25
v_add_u32_e32 v26, v42, v26
v_add_u32_e32 v27, v43, v27
v_add_u32_e32 v28, v44, v28
v_add_u32_e32 v29, v45, v29
v_add_u32_e32 v30, v46, v30
v_add_u32_e32 v31, v47, v31
v_add_u32_e32 v32, v48, v32
v_add_u32_e32 v5, v49, v5
v_add_u32_e32 v6, v50, v6
v_add_u32_e32 v7, v51, v7
v_add_u32_e32 v8, v52, v8
v_add_u32_e32 v9, v53, v9
v_add_u32_e32 v10, v54, v10
v_add_u32_e32 v11, v55, v11
v_add_u32_e32 v12, v56, v12
v_add_u32_e32 v13, v57, v13
v_add_u32_e32 v14, v58, v14
v_add_u32_e32 v15, v59, v15
v_add_u32_e32 v16, v60, v16
v_add_u32_e32 v1, v61, v1
v_add_u32_e32 v2, v62, v2
v_add_u32_e32 v3, v63, v3
v_add_u32_e32 v4, v64, v4
s_waitcnt vmcnt(0)
v_and_b32_e32 v51, 15, v0
v_lshrrev_b32_e32 v52, 4, v0
v_and_b32_e32 v52, 3, v52
v_lshlrev_b32_e32 v52, 2, v52
v_add_u32_e32 v51, s5, v51
v_add_u32_e32 v52, s4, v52
v_lshlrev_b32_e32 v53, 2, v52
global_load_dwordx4 v[33:36], v53, s[26:27] offset:0
global_load_dwordx4 v[37:40], v53, s[26:27] offset:64
global_load_dwordx4 v[41:44], v53, s[26:27] offset:128
global_load_dwordx4 v[45:48], v53, s[26:27] offset:192
v_cmp_gt_u32_e32 vcc, s8, v51
s_and_saveexec_b64 s[2:3], vcc
s_cbranch_execz .L_E030_bf16_skip_0
v_lshlrev_b32_e32 v56, 2, v51
global_load_dword v49, v56, s[24:25]
v_mul_u32_u24_e32 v56, 17408, v51
v_add_u32_e32 v56, v52, v56
v_lshlrev_b32_e32 v56, 1, v56
v_add_co_u32_e32 v54, vcc, s12, v56
v_mov_b32_e32 v55, s13
v_addc_co_u32_e32 v55, vcc, 0, v55, vcc
s_waitcnt vmcnt(0)
v_cvt_f32_i32 v17, v17
v_mul_f32_e32 v56, v49, v33
v_mul_f32_e32 v17, v56, v17
v_lshrrev_b32_e32 v56, 16, v17
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v17, 0x7fff, v17
v_add_u32_e32 v17, v56, v17
v_cvt_f32_i32 v18, v18
v_mul_f32_e32 v56, v49, v34
v_mul_f32_e32 v18, v56, v18
v_lshrrev_b32_e32 v56, 16, v18
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v18, 0x7fff, v18
v_add_u32_e32 v18, v56, v18
v_cvt_f32_i32 v19, v19
v_mul_f32_e32 v56, v49, v35
v_mul_f32_e32 v19, v56, v19
v_lshrrev_b32_e32 v56, 16, v19
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v19, 0x7fff, v19
v_add_u32_e32 v19, v56, v19
v_cvt_f32_i32 v20, v20
v_mul_f32_e32 v56, v49, v36
v_mul_f32_e32 v20, v56, v20
v_lshrrev_b32_e32 v56, 16, v20
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v20, 0x7fff, v20
v_add_u32_e32 v20, v56, v20
v_lshrrev_b32_e32 v17, 16, v17
v_and_b32_e32 v18, 0xffff0000, v18
v_or_b32_e32 v17, v17, v18
v_lshrrev_b32_e32 v19, 16, v19
v_and_b32_e32 v20, 0xffff0000, v20
v_or_b32_e32 v18, v19, v20
global_store_dwordx2 v[54:55], v[17:18], off offset:0 glc slc
v_cvt_f32_i32 v21, v21
v_mul_f32_e32 v56, v49, v37
v_mul_f32_e32 v21, v56, v21
v_lshrrev_b32_e32 v56, 16, v21
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v21, 0x7fff, v21
v_add_u32_e32 v21, v56, v21
v_cvt_f32_i32 v22, v22
v_mul_f32_e32 v56, v49, v38
v_mul_f32_e32 v22, v56, v22
v_lshrrev_b32_e32 v56, 16, v22
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v22, 0x7fff, v22
v_add_u32_e32 v22, v56, v22
v_cvt_f32_i32 v23, v23
v_mul_f32_e32 v56, v49, v39
v_mul_f32_e32 v23, v56, v23
v_lshrrev_b32_e32 v56, 16, v23
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v23, 0x7fff, v23
v_add_u32_e32 v23, v56, v23
v_cvt_f32_i32 v24, v24
v_mul_f32_e32 v56, v49, v40
v_mul_f32_e32 v24, v56, v24
v_lshrrev_b32_e32 v56, 16, v24
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v24, 0x7fff, v24
v_add_u32_e32 v24, v56, v24
v_lshrrev_b32_e32 v21, 16, v21
v_and_b32_e32 v22, 0xffff0000, v22
v_or_b32_e32 v21, v21, v22
v_lshrrev_b32_e32 v23, 16, v23
v_and_b32_e32 v24, 0xffff0000, v24
v_or_b32_e32 v22, v23, v24
global_store_dwordx2 v[54:55], v[21:22], off offset:32 glc slc
v_cvt_f32_i32 v25, v25
v_mul_f32_e32 v56, v49, v41
v_mul_f32_e32 v25, v56, v25
v_lshrrev_b32_e32 v56, 16, v25
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v25, 0x7fff, v25
v_add_u32_e32 v25, v56, v25
v_cvt_f32_i32 v26, v26
v_mul_f32_e32 v56, v49, v42
v_mul_f32_e32 v26, v56, v26
v_lshrrev_b32_e32 v56, 16, v26
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v26, 0x7fff, v26
v_add_u32_e32 v26, v56, v26
v_cvt_f32_i32 v27, v27
v_mul_f32_e32 v56, v49, v43
v_mul_f32_e32 v27, v56, v27
v_lshrrev_b32_e32 v56, 16, v27
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v27, 0x7fff, v27
v_add_u32_e32 v27, v56, v27
v_cvt_f32_i32 v28, v28
v_mul_f32_e32 v56, v49, v44
v_mul_f32_e32 v28, v56, v28
v_lshrrev_b32_e32 v56, 16, v28
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v28, 0x7fff, v28
v_add_u32_e32 v28, v56, v28
v_lshrrev_b32_e32 v25, 16, v25
v_and_b32_e32 v26, 0xffff0000, v26
v_or_b32_e32 v25, v25, v26
v_lshrrev_b32_e32 v27, 16, v27
v_and_b32_e32 v28, 0xffff0000, v28
v_or_b32_e32 v26, v27, v28
global_store_dwordx2 v[54:55], v[25:26], off offset:64 glc slc
v_cvt_f32_i32 v29, v29
v_mul_f32_e32 v56, v49, v45
v_mul_f32_e32 v29, v56, v29
v_lshrrev_b32_e32 v56, 16, v29
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v29, 0x7fff, v29
v_add_u32_e32 v29, v56, v29
v_cvt_f32_i32 v30, v30
v_mul_f32_e32 v56, v49, v46
v_mul_f32_e32 v30, v56, v30
v_lshrrev_b32_e32 v56, 16, v30
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v30, 0x7fff, v30
v_add_u32_e32 v30, v56, v30
v_cvt_f32_i32 v31, v31
v_mul_f32_e32 v56, v49, v47
v_mul_f32_e32 v31, v56, v31
v_lshrrev_b32_e32 v56, 16, v31
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v31, 0x7fff, v31
v_add_u32_e32 v31, v56, v31
v_cvt_f32_i32 v32, v32
v_mul_f32_e32 v56, v49, v48
v_mul_f32_e32 v32, v56, v32
v_lshrrev_b32_e32 v56, 16, v32
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v32, 0x7fff, v32
v_add_u32_e32 v32, v56, v32
v_lshrrev_b32_e32 v29, 16, v29
v_and_b32_e32 v30, 0xffff0000, v30
v_or_b32_e32 v29, v29, v30
v_lshrrev_b32_e32 v31, 16, v31
v_and_b32_e32 v32, 0xffff0000, v32
v_or_b32_e32 v30, v31, v32
global_store_dwordx2 v[54:55], v[29:30], off offset:96 glc slc
.L_E030_bf16_skip_0:
s_or_b64 exec, exec, s[2:3]
v_add_u32_e32 v51, 16, v51
v_cmp_gt_u32_e32 vcc, s8, v51
s_and_saveexec_b64 s[2:3], vcc
s_cbranch_execz .L_E030_bf16_skip_1
v_lshlrev_b32_e32 v56, 2, v51
global_load_dword v49, v56, s[24:25]
v_mul_u32_u24_e32 v56, 17408, v51
v_add_u32_e32 v56, v52, v56
v_lshlrev_b32_e32 v56, 1, v56
v_add_co_u32_e32 v54, vcc, s12, v56
v_mov_b32_e32 v55, s13
v_addc_co_u32_e32 v55, vcc, 0, v55, vcc
s_waitcnt vmcnt(0)
v_cvt_f32_i32 v5, v5
v_mul_f32_e32 v56, v49, v33
v_mul_f32_e32 v5, v56, v5
v_lshrrev_b32_e32 v56, 16, v5
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v5, 0x7fff, v5
v_add_u32_e32 v5, v56, v5
v_cvt_f32_i32 v6, v6
v_mul_f32_e32 v56, v49, v34
v_mul_f32_e32 v6, v56, v6
v_lshrrev_b32_e32 v56, 16, v6
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v6, 0x7fff, v6
v_add_u32_e32 v6, v56, v6
v_cvt_f32_i32 v7, v7
v_mul_f32_e32 v56, v49, v35
v_mul_f32_e32 v7, v56, v7
v_lshrrev_b32_e32 v56, 16, v7
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v7, 0x7fff, v7
v_add_u32_e32 v7, v56, v7
v_cvt_f32_i32 v8, v8
v_mul_f32_e32 v56, v49, v36
v_mul_f32_e32 v8, v56, v8
v_lshrrev_b32_e32 v56, 16, v8
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v8, 0x7fff, v8
v_add_u32_e32 v8, v56, v8
v_lshrrev_b32_e32 v5, 16, v5
v_and_b32_e32 v6, 0xffff0000, v6
v_or_b32_e32 v5, v5, v6
v_lshrrev_b32_e32 v7, 16, v7
v_and_b32_e32 v8, 0xffff0000, v8
v_or_b32_e32 v6, v7, v8
global_store_dwordx2 v[54:55], v[5:6], off offset:0 glc slc
v_cvt_f32_i32 v9, v9
v_mul_f32_e32 v56, v49, v37
v_mul_f32_e32 v9, v56, v9
v_lshrrev_b32_e32 v56, 16, v9
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v9, 0x7fff, v9
v_add_u32_e32 v9, v56, v9
v_cvt_f32_i32 v10, v10
v_mul_f32_e32 v56, v49, v38
v_mul_f32_e32 v10, v56, v10
v_lshrrev_b32_e32 v56, 16, v10
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v10, 0x7fff, v10
v_add_u32_e32 v10, v56, v10
v_cvt_f32_i32 v11, v11
v_mul_f32_e32 v56, v49, v39
v_mul_f32_e32 v11, v56, v11
v_lshrrev_b32_e32 v56, 16, v11
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v11, 0x7fff, v11
v_add_u32_e32 v11, v56, v11
v_cvt_f32_i32 v12, v12
v_mul_f32_e32 v56, v49, v40
v_mul_f32_e32 v12, v56, v12
v_lshrrev_b32_e32 v56, 16, v12
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v12, 0x7fff, v12
v_add_u32_e32 v12, v56, v12
v_lshrrev_b32_e32 v9, 16, v9
v_and_b32_e32 v10, 0xffff0000, v10
v_or_b32_e32 v9, v9, v10
v_lshrrev_b32_e32 v11, 16, v11
v_and_b32_e32 v12, 0xffff0000, v12
v_or_b32_e32 v10, v11, v12
global_store_dwordx2 v[54:55], v[9:10], off offset:32 glc slc
v_cvt_f32_i32 v13, v13
v_mul_f32_e32 v56, v49, v41
v_mul_f32_e32 v13, v56, v13
v_lshrrev_b32_e32 v56, 16, v13
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v13, 0x7fff, v13
v_add_u32_e32 v13, v56, v13
v_cvt_f32_i32 v14, v14
v_mul_f32_e32 v56, v49, v42
v_mul_f32_e32 v14, v56, v14
v_lshrrev_b32_e32 v56, 16, v14
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v14, 0x7fff, v14
v_add_u32_e32 v14, v56, v14
v_cvt_f32_i32 v15, v15
v_mul_f32_e32 v56, v49, v43
v_mul_f32_e32 v15, v56, v15
v_lshrrev_b32_e32 v56, 16, v15
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v15, 0x7fff, v15
v_add_u32_e32 v15, v56, v15
v_cvt_f32_i32 v16, v16
v_mul_f32_e32 v56, v49, v44
v_mul_f32_e32 v16, v56, v16
v_lshrrev_b32_e32 v56, 16, v16
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v16, 0x7fff, v16
v_add_u32_e32 v16, v56, v16
v_lshrrev_b32_e32 v13, 16, v13
v_and_b32_e32 v14, 0xffff0000, v14
v_or_b32_e32 v13, v13, v14
v_lshrrev_b32_e32 v15, 16, v15
v_and_b32_e32 v16, 0xffff0000, v16
v_or_b32_e32 v14, v15, v16
global_store_dwordx2 v[54:55], v[13:14], off offset:64 glc slc
v_cvt_f32_i32 v1, v1
v_mul_f32_e32 v56, v49, v45
v_mul_f32_e32 v1, v56, v1
v_lshrrev_b32_e32 v56, 16, v1
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v1, 0x7fff, v1
v_add_u32_e32 v1, v56, v1
v_cvt_f32_i32 v2, v2
v_mul_f32_e32 v56, v49, v46
v_mul_f32_e32 v2, v56, v2
v_lshrrev_b32_e32 v56, 16, v2
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v2, 0x7fff, v2
v_add_u32_e32 v2, v56, v2
v_cvt_f32_i32 v3, v3
v_mul_f32_e32 v56, v49, v47
v_mul_f32_e32 v3, v56, v3
v_lshrrev_b32_e32 v56, 16, v3
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v3, 0x7fff, v3
v_add_u32_e32 v3, v56, v3
v_cvt_f32_i32 v4, v4
v_mul_f32_e32 v56, v49, v48
v_mul_f32_e32 v4, v56, v4
v_lshrrev_b32_e32 v56, 16, v4
v_and_b32_e32 v56, 1, v56
v_add_u32_e32 v4, 0x7fff, v4
v_add_u32_e32 v4, v56, v4
v_lshrrev_b32_e32 v1, 16, v1
v_and_b32_e32 v2, 0xffff0000, v2
v_or_b32_e32 v1, v1, v2
v_lshrrev_b32_e32 v3, 16, v3
v_and_b32_e32 v4, 0xffff0000, v4
v_or_b32_e32 v2, v3, v4
global_store_dwordx2 v[54:55], v[1:2], off offset:96 glc slc
.L_E030_bf16_skip_1:
s_or_b64 exec, exec, s[2:3]
.LBB0_13:
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z8reg_E030PKaS0_Piiiii
		.amdhsa_group_segment_fixed_size 8192
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 56
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 72
		.amdhsa_next_free_sgpr 28
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z8reg_E030PKaS0_Piiiii, .Lfunc_end0-_Z8reg_E030PKaS0_Piiiii
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 1848
; NumSgprs: 26
; NumVgprs: 72
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 8192 bytes/workgroup (compile time only)
; SGPRBlocks: 3
; VGPRBlocks: 17
; NumSGPRsForWavesPerEU: 26
; NumVGPRsForWavesPerEU: 72
; Occupancy: 3
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0 (http://10.16.1.181/dcutoolkit/driverruntime/llvm-project.git b8c5e6d901d63a10d73acf48579414a1ea463c62)"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
- .args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .actual_access: write_only
    .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .fp64_status: 0
  .group_segment_fixed_size: 8192
  .kernarg_segment_align: 8
  .kernarg_segment_size: 56
  .language: OpenCL C
  .language_version:
  - 2
  - 0
  .max_flat_workgroup_size: 128
  .name: _Z8reg_E030PKaS0_Piiiii
  .private_segment_fixed_size: 0
  .sgpr_count: 32
  .sgpr_spill_count: 0
  .symbol: _Z8reg_E030PKaS0_Piiiii.kd
  .unfolded_args:
  - .address_space: global
    .offset: 0
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 8
    .size: 8
    .value_kind: global_buffer
  - .actual_access: write_only
    .address_space: global
    .offset: 16
    .size: 8
    .value_kind: global_buffer
  - .offset: 24
    .size: 4
    .value_kind: by_value
  - .offset: 28
    .size: 4
    .value_kind: by_value
  - .offset: 32
    .size: 4
    .value_kind: by_value
  - .offset: 36
    .size: 4
    .value_kind: by_value
  - .address_space: global
    .offset: 40
    .size: 8
    .value_kind: global_buffer
  - .address_space: global
    .offset: 48
    .size: 8
    .value_kind: global_buffer
  .uniform_work_group_size: 1
  .uses_dynamic_stack: false
  .vgpr_count: 72
  .vgpr_spill_count: 0
  .wavefront_size: 64
amdhsa.target: amdgcn-amd-amdhsa--gfx936:sramecc+
amdhsa.version:
- 1
- 2
...
.end_amdgpu_metadata
