import os
os.environ["HIP_VISIBLE_DEVICES"]="5"
for k in ["CUDA_VISIBLE_DEVICES","ROCR_VISIBLE_DEVICES","GPU_DEVICE_ORDINAL"]:os.environ.pop(k,None)
import torch,json,inspect
from pathlib import Path
R=Path(__file__).resolve().parent
torch.set_num_threads(8)
d={"torch":torch.__version__,"hip":torch.version.hip,"device":str(torch.cuda.get_device_properties(0))}
try:
 import aiter
 from aiter import silu_and_mul
 x=torch.randn((128,17408),device="cuda",dtype=torch.bfloat16)
 y=torch.empty((128,8704),device="cuda",dtype=torch.bfloat16)
 silu_and_mul(y,x);torch.cuda.synchronize()
 ref=(torch.nn.functional.silu(x[:,:8704].float())*x[:,8704:].float()).bfloat16()
 d.update(aiter_available=True,activation_file=inspect.getfile(silu_and_mul),max_abs=float((y.float()-ref.float()).abs().max().item()),bit_equal_fraction=float((y==ref).float().mean().item()))
except BaseException as e:
 import traceback
 d.update(aiter_available=False,error=str(e),traceback=traceback.format_exc())
(R/"activation-probe.json").write_text(json.dumps(d,indent=2)+"\n")
print(json.dumps(d,indent=2),flush=True)
